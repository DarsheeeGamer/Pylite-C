import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiRequest } from '../lib/queryClient';
import { useToast } from '../hooks/use-toast';

interface User {
  id: number;
  username: string;
  name: string;
  email: string;
}

interface UserContextType {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  register: (username: string, password: string, name: string, email: string) => Promise<boolean>;
  logout: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Check if user is already logged in on mount
    const checkAuthStatus = async () => {
      try {
        const userData = await apiRequest('/api/auth/user');
        setUser(userData);
      } catch (error) {
        // User is not logged in
        console.log('User not authenticated');
      } finally {
        setLoading(false);
      }
    };

    checkAuthStatus();
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    setLoading(true);
    try {
      const userData = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });

      setUser(userData);
      toast({
        title: 'Login Successful',
        description: `Welcome back, ${userData.name}!`,
        open: true
      });
      return true;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to login';
      toast({
        title: 'Login Failed',
        description: message,
        open: true
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const register = async (
    username: string,
    password: string,
    name: string,
    email: string
  ): Promise<boolean> => {
    setLoading(true);
    try {
      const userData = await apiRequest('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({ username, password, name, email }),
      });

      setUser(userData);
      toast({
        title: 'Registration Successful',
        description: `Welcome to Caddy, ${userData.name}!`,
        open: true
      });
      return true;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to register';
      toast({
        title: 'Registration Failed',
        description: message,
        open: true
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    // Since we're using session-based auth, we don't need to make an API call to logout
    toast({
      title: 'Logged Out',
      description: 'You have been successfully logged out.',
      open: true
    });
  };

  return (
    <UserContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUserContext = (): UserContextType => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUserContext must be used within a UserProvider');
  }
  return context;
};