import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import WelcomePage from "@/pages/welcome-page";
import AuthPage from "@/pages/auth-page";
import AiCharacterPage from "@/pages/ai-character-page";
import MarketplacePage from "@/pages/marketplace-page";
import EmailVerifiedPage from "@/pages/email-verified";
import OnboardingModal from "@/components/modals/OnboardingModal";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { AnimatePresence } from "framer-motion";
import { PageTransition } from "@/components/ui/animations";

function Router() {
  const [location] = useLocation();
  
  return (
    <AnimatePresence mode="wait">
      <PageTransition key={location}>
        <Switch>
          <Route path="/" component={WelcomePage} />
          <ProtectedRoute path="/dashboard" component={Home} />
          <ProtectedRoute path="/ai/:id" component={AiCharacterPage} />
          <Route path="/marketplace/ai/characters" component={MarketplacePage} />
          <Route path="/auth" component={AuthPage} />
          <Route path="/email-verified" component={EmailVerifiedPage} />
          <Route component={NotFound} />
        </Switch>
      </PageTransition>
    </AnimatePresence>
  );
}

function App() {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const hasVisitedBefore = localStorage.getItem("hasVisitedBefore");
    if (!hasVisitedBefore) {
      setShowOnboarding(true);
    }
  }, []);

  const handleOnboardingComplete = () => {
    localStorage.setItem("hasVisitedBefore", "true");
    setShowOnboarding(false);
    toast({
      title: "Welcome to AI Companion!",
      description: "Your AI companions are ready to chat with you.",
    });
  };

  const handleOnboardingSkip = () => {
    localStorage.setItem("hasVisitedBefore", "true");
    setShowOnboarding(false);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        {showOnboarding && (
          <OnboardingModal
            onComplete={handleOnboardingComplete}
            onSkip={handleOnboardingSkip}
          />
        )}
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
