import { useEffect, useRef, useState, useCallback } from 'react';

export interface WebSocketMessage {
  type: string;
  conversationId?: number;
  userId?: number;
  characterId?: number;
  content?: string;
  emotionLevel?: number;
  emotionIcon?: string;
  isUser?: boolean;
  gifQuery?: string;
}

interface UseWebSocketOptions {
  onMessage?: (message: WebSocketMessage) => void;
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (error: Event) => void;
  reconnectAttempts?: number;
  reconnectInterval?: number;
}

/**
 * Custom hook for WebSocket connections with auto-reconnect
 */
export function useWebSocket(url: string, options: UseWebSocketOptions = {}, userId?: number) {
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState<Event | null>(null);
  const socket = useRef<WebSocket | null>(null);
  
  const {
    onMessage,
    onOpen,
    onClose,
    onError,
    reconnectAttempts = 5,
    reconnectInterval = 3000,
  } = options;

  const reconnectTimeoutRef = useRef<number | null>(null);
  const reconnectAttemptsRef = useRef(0);
  const userIdRef = useRef<number|undefined>(userId);

  // Update userId ref when it changes
  useEffect(() => {
    userIdRef.current = userId;
  }, [userId]);

  // Connect to WebSocket
  const connect = useCallback(() => {
    if (socket.current?.readyState === WebSocket.OPEN) return;

    console.log(`Connecting to WebSocket: ${url}, userId: ${userIdRef.current}`);
    socket.current = new WebSocket(url);

    socket.current.onopen = () => {
      console.log('WebSocket connected');
      setConnected(true);
      setError(null);
      reconnectAttemptsRef.current = 0;
      if (onOpen) onOpen();
    };

    socket.current.onclose = (event) => {
      console.log('WebSocket disconnected');
      setConnected(false);
      if (onClose) onClose();

      // Try to reconnect if not closed cleanly
      if (!event.wasClean && reconnectAttemptsRef.current < reconnectAttempts) {
        reconnectAttemptsRef.current += 1;
        console.log(`Attempting to reconnect (${reconnectAttemptsRef.current}/${reconnectAttempts})...`);
        
        if (reconnectTimeoutRef.current) {
          window.clearTimeout(reconnectTimeoutRef.current);
        }
        
        reconnectTimeoutRef.current = window.setTimeout(() => {
          connect();
        }, reconnectInterval);
      }
    };

    socket.current.onerror = (event) => {
      console.error('WebSocket error:', event);
      setError(event);
      if (onError) onError(event);
    };

    socket.current.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data) as WebSocketMessage;
        
        // Dispatch a custom event so that other components can listen for WebSocket messages
        const customEvent = new CustomEvent('websocket-message', { detail: message });
        window.dispatchEvent(customEvent);
        
        if (onMessage) onMessage(message);
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
  }, [url, onOpen, onClose, onError, onMessage, reconnectAttempts, reconnectInterval]);

  // Send a message through the WebSocket
  const sendMessage = useCallback((message: WebSocketMessage) => {
    if (socket.current?.readyState === WebSocket.OPEN) {
      // Automatically include userId if available and not already set in the message
      const messageWithUserId = {
        ...message,
        userId: message.userId || userIdRef.current
      };
      socket.current.send(JSON.stringify(messageWithUserId));
      return true;
    }
    return false;
  }, []);

  // Close the WebSocket connection
  const disconnect = useCallback(() => {
    if (socket.current) {
      socket.current.close();
      socket.current = null;
      setConnected(false);
    }
    if (reconnectTimeoutRef.current) {
      window.clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
  }, []);

  // Initialize WebSocket connection
  useEffect(() => {
    connect();

    // Cleanup on unmount
    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  return {
    connected,
    error,
    sendMessage,
    disconnect,
    reconnect: connect,
  };
}