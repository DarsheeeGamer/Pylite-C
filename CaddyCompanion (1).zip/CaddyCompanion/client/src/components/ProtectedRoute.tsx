import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useUserContext } from '../contexts/UserContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const [, setLocation] = useLocation();
  const { user, loading } = useUserContext();

  useEffect(() => {
    if (!loading && !user) {
      // Redirect to login if not authenticated
      setLocation('/auth');
    }
  }, [user, loading, setLocation]);

  // Show loading state while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-50">
        <div className="text-center">
          <div className="typing-indicator mx-auto my-4">
            <span></span>
            <span></span>
            <span></span>
          </div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Render nothing if not authenticated (redirect will happen in useEffect)
  if (!user) {
    return null;
  }

  // Render children if authenticated
  return <>{children}</>;
};

export default ProtectedRoute;