import React, { ReactNode, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";

interface AnimationProps {
  children: ReactNode;
  delay?: number;
}

interface ScaleAnimationProps extends AnimationProps {
  scale?: number;
}

interface StaggeredListAnimationProps extends AnimationProps {
  staggerDelay?: number;
}

export const FadeAnimation = ({ children, delay = 0 }: AnimationProps) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay }}
    >
      {children}
    </motion.div>
  );
};

export const SlideUpAnimation = ({ children, delay = 0 }: AnimationProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        type: "spring", 
        stiffness: 300, 
        damping: 20, 
        delay 
      }}
    >
      {children}
    </motion.div>
  );
};

export const SlideInLeftAnimation = ({ children, delay = 0 }: AnimationProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ 
        type: "spring", 
        stiffness: 300, 
        damping: 20, 
        delay 
      }}
    >
      {children}
    </motion.div>
  );
};

export const SlideInRightAnimation = ({ children, delay = 0 }: AnimationProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ 
        type: "spring", 
        stiffness: 300, 
        damping: 20, 
        delay 
      }}
    >
      {children}
    </motion.div>
  );
};

export const ScaleAnimation = ({ 
  children, 
  delay = 0,
  scale = 1.05
}: ScaleAnimationProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ 
        type: "spring",
        stiffness: 300,
        damping: 20,
        delay 
      }}
    >
      {children}
    </motion.div>
  );
};

export const HoverScaleAnimation = ({ 
  children,
  scale = 1.05
}: ScaleAnimationProps) => {
  return (
    <motion.div
      whileHover={{ scale }}
      transition={{ 
        type: "spring",
        stiffness: 300,
        damping: 20
      }}
    >
      {children}
    </motion.div>
  );
};

export const PulseAnimation = ({ children, delay = 0 }: AnimationProps) => {
  return (
    <motion.div
      animate={{ 
        scale: [1, 1.02, 1],
        opacity: [0.9, 1, 0.9]
      }}
      transition={{ 
        repeat: Infinity,
        duration: 2,
        delay 
      }}
    >
      {children}
    </motion.div>
  );
};

export const StaggeredListAnimation = ({ 
  children,
  delay = 0,
  staggerDelay = 0.1
}: StaggeredListAnimationProps) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: staggerDelay,
        delayChildren: delay
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="show"
    >
      {Array.isArray(children) ? 
        children.map((child, index) => (
          <motion.div key={index} variants={itemVariants}>
            {child}
          </motion.div>
        )) : 
        <motion.div variants={itemVariants}>
          {children}
        </motion.div>
      }
    </motion.div>
  );
};

// Page transition animation component
interface PageTransitionProps {
  children: ReactNode;
}

export const PageTransition = ({ children }: PageTransitionProps) => {
  const [location] = useLocation();
  const locationRef = useRef(location);
  
  // Store whether this is an initial render
  const isFirstRender = useRef(true);
  
  // Use different animations for initial render vs navigation
  const variants = {
    initial: isFirstRender.current 
      ? { opacity: 0 }
      : { opacity: 0, x: location !== locationRef.current ? 20 : -20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: location !== locationRef.current ? -20 : 20 },
  };
  
  // After first render, update ref
  if (isFirstRender.current) {
    isFirstRender.current = false;
  }
  
  // Update location ref when it changes
  if (location !== locationRef.current) {
    locationRef.current = location;
  }
  
  return (
    <AnimatePresence mode="wait" initial={true}>
      <motion.div
        key={location}
        initial="initial"
        animate="animate"
        exit="exit"
        variants={variants}
        transition={{
          type: "spring",
          stiffness: 260,
          damping: 20,
        }}
        className="w-full"
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
};