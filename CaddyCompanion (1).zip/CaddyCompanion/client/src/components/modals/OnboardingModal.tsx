import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScaleAnimation, SlideInRightAnimation, FadeAnimation } from "@/components/ui/animations";

interface OnboardingModalProps {
  onComplete: () => void;
  onSkip: () => void;
}

const OnboardingModal = ({ onComplete, onSkip }: OnboardingModalProps) => {
  const [step, setStep] = useState(1);
  const [preferences, setPreferences] = useState({
    conversationStyle: "",
    personalityType: "",
    interestArea: "",
  });
  const [showTeaserChat, setShowTeaserChat] = useState(false);

  const totalSteps = 3;

  const handlePreferenceChange = (key: keyof typeof preferences, value: string) => {
    setPreferences((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      setShowTeaserChat(true);
    }
  };

  const handleComplete = () => {
    // Save preferences to localStorage
    localStorage.setItem("userPreferences", JSON.stringify(preferences));
    onComplete();
  };

  // Sample AI characters for the teaser
  const sampleCharacters = [
    {
      id: 1,
      name: "Aria",
      description: "Witty literature PhD student, expert in 19th-century Romanticism with strong opinions on modern writing.",
      avatar: null,
      previewMessage: "Hey there! I was just taking a break from my dissertation on Romantic poetry. Tell me, have you read any good books lately? And please don't say anything with vampires that sparkle...",
      personality: "Intellectually confident but secretly insecure. Brilliant, passionate about literature, slightly judgemental of 'lesser' works."
    },
    {
      id: 2,
      name: "Jake",
      description: "Outdoor adventure guide with a philosophical bent and stories from around the world.",
      avatar: null,
      previewMessage: "Nice to meet you! Just got back from leading a trek in the Himalayas. There's something about high altitudes that gets people talking about the meaning of life, you know?",
      personality: "Thoughtful, grounded, quietly wise. Balances physical capability with intellectual curiosity."
    }
  ];

  // Get character that best matches preferences
  const getMatchedCharacter = () => {
    // In a real app, this would use an algorithm to match preferences
    // For now, just return Aria as she's our primary character example
    return sampleCharacters[0];
  };

  const matchedCharacter = getMatchedCharacter();

  return (
    <Dialog open={true}>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden bg-white rounded-xl">
        <AnimatePresence mode="wait">
          {!showTeaserChat ? (
            <motion.div
              key="preferences"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <DialogHeader className="px-6 pt-6 pb-2">
                <DialogTitle className="text-2xl font-bold text-center">Welcome to Caddy!</DialogTitle>
                <DialogDescription className="text-center text-base">
                  Let's get to know you a bit better to match you with the perfect AI companions.
                </DialogDescription>
                <div className="flex justify-center mt-2 gap-1.5">
                  {Array.from({ length: totalSteps }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-1.5 rounded-full transition-all duration-300 ${
                        i + 1 === step ? "w-8 bg-primary" : "w-4 bg-gray-200"
                      }`}
                    />
                  ))}
                </div>
              </DialogHeader>

              <div className="p-6">
                {step === 1 && (
                  <ScaleAnimation>
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">How do you prefer your conversations?</h3>
                      <RadioGroup
                        value={preferences.conversationStyle}
                        onValueChange={(value) => handlePreferenceChange("conversationStyle", value)}
                        className="grid grid-cols-2 gap-4"
                      >
                        <Label
                          htmlFor="flirty"
                          className={`flex flex-col items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all ${
                            preferences.conversationStyle === "flirty"
                              ? "border-primary bg-primary/5"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          <RadioGroupItem value="flirty" id="flirty" className="sr-only" />
                          <div className="text-3xl mb-2">✨</div>
                          <div className="font-medium">Flirty & Fun</div>
                          <div className="text-xs text-gray-500 text-center mt-1">Playful banter and lighthearted interactions</div>
                        </Label>
                        <Label
                          htmlFor="deep"
                          className={`flex flex-col items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all ${
                            preferences.conversationStyle === "deep"
                              ? "border-primary bg-primary/5"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          <RadioGroupItem value="deep" id="deep" className="sr-only" />
                          <div className="text-3xl mb-2">🧠</div>
                          <div className="font-medium">Deep & Meaningful</div>
                          <div className="text-xs text-gray-500 text-center mt-1">Intellectual conversations with substance</div>
                        </Label>
                      </RadioGroup>
                    </div>
                  </ScaleAnimation>
                )}

                {step === 2 && (
                  <ScaleAnimation>
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">What personality type do you connect with?</h3>
                      <RadioGroup
                        value={preferences.personalityType}
                        onValueChange={(value) => handlePreferenceChange("personalityType", value)}
                        className="grid grid-cols-2 gap-4"
                      >
                        <Label
                          htmlFor="bold"
                          className={`flex flex-col items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all ${
                            preferences.personalityType === "bold"
                              ? "border-primary bg-primary/5"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          <RadioGroupItem value="bold" id="bold" className="sr-only" />
                          <div className="text-3xl mb-2">🔥</div>
                          <div className="font-medium">Bold & Assertive</div>
                          <div className="text-xs text-gray-500 text-center mt-1">Strong opinions and confident perspectives</div>
                        </Label>
                        <Label
                          htmlFor="gentle"
                          className={`flex flex-col items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all ${
                            preferences.personalityType === "gentle"
                              ? "border-primary bg-primary/5"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          <RadioGroupItem value="gentle" id="gentle" className="sr-only" />
                          <div className="text-3xl mb-2">🌸</div>
                          <div className="font-medium">Gentle & Supportive</div>
                          <div className="text-xs text-gray-500 text-center mt-1">Nurturing and understanding approach</div>
                        </Label>
                      </RadioGroup>
                    </div>
                  </ScaleAnimation>
                )}

                {step === 3 && (
                  <ScaleAnimation>
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">What topics interest you most?</h3>
                      <RadioGroup
                        value={preferences.interestArea}
                        onValueChange={(value) => handlePreferenceChange("interestArea", value)}
                        className="grid grid-cols-2 gap-4"
                      >
                        <Label
                          htmlFor="arts"
                          className={`flex flex-col items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all ${
                            preferences.interestArea === "arts"
                              ? "border-primary bg-primary/5"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          <RadioGroupItem value="arts" id="arts" className="sr-only" />
                          <div className="text-3xl mb-2">🎭</div>
                          <div className="font-medium">Arts & Culture</div>
                          <div className="text-xs text-gray-500 text-center mt-1">Literature, film, music, and creativity</div>
                        </Label>
                        <Label
                          htmlFor="tech"
                          className={`flex flex-col items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all ${
                            preferences.interestArea === "tech"
                              ? "border-primary bg-primary/5"
                              : "border-gray-200 hover:border-gray-300"
                          }`}
                        >
                          <RadioGroupItem value="tech" id="tech" className="sr-only" />
                          <div className="text-3xl mb-2">💻</div>
                          <div className="font-medium">Tech & Science</div>
                          <div className="text-xs text-gray-500 text-center mt-1">Innovation, discoveries, and analytical thinking</div>
                        </Label>
                      </RadioGroup>
                    </div>
                  </ScaleAnimation>
                )}
              </div>

              <DialogFooter className="px-6 pb-6 pt-2 flex flex-col sm:flex-row gap-3">
                <Button
                  variant="outline"
                  onClick={onSkip}
                  className="sm:flex-1"
                >
                  Skip
                </Button>
                <Button
                  onClick={handleNext}
                  disabled={
                    (step === 1 && !preferences.conversationStyle) ||
                    (step === 2 && !preferences.personalityType) ||
                    (step === 3 && !preferences.interestArea)
                  }
                  className="sm:flex-1"
                >
                  {step < totalSteps ? "Next" : "See Your Match"}
                </Button>
              </DialogFooter>
            </motion.div>
          ) : (
            <motion.div
              key="teaserChat"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              <DialogHeader className="px-6 pt-6 pb-2 border-b">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10 border shadow-sm">
                    {matchedCharacter.avatar ? (
                      <AvatarImage src={matchedCharacter.avatar} alt={matchedCharacter.name} />
                    ) : (
                      <AvatarFallback className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                        {matchedCharacter.name.substring(0, 2)}
                      </AvatarFallback>
                    )}
                  </Avatar>
                  <div>
                    <DialogTitle className="text-lg font-semibold">{matchedCharacter.name}</DialogTitle>
                    <DialogDescription className="text-xs">
                      {matchedCharacter.description}
                    </DialogDescription>
                  </div>
                </div>
              </DialogHeader>

              <div className="px-6 py-4 h-[300px] overflow-y-auto">
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <Avatar className="h-8 w-8 border shadow-sm flex-shrink-0">
                      {matchedCharacter.avatar ? (
                        <AvatarImage src={matchedCharacter.avatar} alt={matchedCharacter.name} />
                      ) : (
                        <AvatarFallback className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                          {matchedCharacter.name.substring(0, 2)}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    <SlideInRightAnimation>
                      <div className="bg-gray-100 rounded-2xl p-3 rounded-tl-none max-w-[80%]">
                        <p className="text-sm">{matchedCharacter.previewMessage}</p>
                      </div>
                    </SlideInRightAnimation>
                  </div>
                  
                  <FadeAnimation delay={1}>
                    <div className="bg-gray-100 rounded-xl p-4 border border-gray-200">
                      <h4 className="text-sm font-medium mb-2">About {matchedCharacter.name}</h4>
                      <p className="text-xs text-gray-600">{matchedCharacter.personality}</p>
                    </div>
                  </FadeAnimation>

                  <FadeAnimation delay={1.5}>
                    <div className="text-center text-sm text-gray-500">
                      <p>This is just a preview! Visit the Marketplace to find your perfect match.</p>
                    </div>
                  </FadeAnimation>
                </div>
              </div>

              <DialogFooter className="px-6 pb-6 pt-2 border-t">
                <Button onClick={handleComplete} className="w-full">
                  Explore AI Companions
                </Button>
              </DialogFooter>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
};

export default OnboardingModal;