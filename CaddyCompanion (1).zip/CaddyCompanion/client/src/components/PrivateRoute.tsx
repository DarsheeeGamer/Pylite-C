import React from 'react';
import { Redirect } from 'wouter';
import { useUserContext } from '../contexts/UserContext';

interface PrivateRouteProps {
  component?: React.ComponentType<any>;
  children?: React.ReactNode;
}

/**
 * PrivateRoute component - redirects to login if not authenticated
 * Can be used either with a component prop or with children
 */
const PrivateRoute: React.FC<PrivateRouteProps> = ({ component: Component, children }) => {
  const { user, loading } = useUserContext();

  // Show loading state while checking authentication
  if (loading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }

  // Redirect to login if not authenticated
  if (!user) {
    return <Redirect to="/auth" />;
  }

  // Render the protected component or children
  return Component ? <Component /> : <>{children}</>;
};

export default PrivateRoute;