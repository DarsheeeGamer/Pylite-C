import React, { useState, useEffect, useRef } from 'react';
import { useRoute, useLocation } from 'wouter';
import { useUserContext } from '../contexts/UserContext';
import { apiRequest } from '../lib/queryClient';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '../hooks/use-toast';
import { useWebSocket, WebSocketMessage } from '../hooks/use-websocket';

interface Message {
  id: number;
  content: string;
  isUser: boolean;
  emotionLevel?: number | null;
  emotionIcon?: string | null;
  createdAt: string;
}

interface Character {
  id: number;
  name: string;
  avatar: string | null;
}

interface Conversation {
  id: number;
  title: string;
  characterId: number;
  userId: number;
  character: Character;
}

const ChatPage: React.FC = () => {
  const [match, params] = useRoute<{ id: string }>('/chat/:id');
  const [, setLocation] = useLocation();
  const { user } = useUserContext();
  const { toast } = useToast();
  const [messageInput, setMessageInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const conversationId = parseInt(params?.id || '0', 10);
  
  // WebSocket connection
  const { connected, sendMessage } = useWebSocket(
    `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}/ws`,
    {}, // Options
    user?.id // Pass userId to WebSocket hook
  );

  // Fetch conversation data
  const { 
    data: conversation,
    isLoading: conversationLoading,
    error: conversationError 
  } = useQuery({
    queryKey: ['/api/conversations', conversationId],
    queryFn: () => apiRequest(`/api/conversations/${conversationId}`),
    enabled: !!conversationId,
  });
  
  // Fetch messages
  const { 
    data: messages, 
    isLoading: messagesLoading,
    error: messagesError,
    refetch: refetchMessages
  } = useQuery({
    queryKey: ['/api/conversations', conversationId, 'messages'],
    queryFn: () => apiRequest(`/api/conversations/${conversationId}/messages`),
    enabled: !!conversationId,
  });

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle WebSocket messages
  useEffect(() => {
    // Create a custom event handler
    const handleWebSocketEvent = (e: CustomEvent<WebSocketMessage>) => {
      const message = e.detail;
      if (message.conversationId === conversationId) {
        if (message.type === 'typing') {
          setIsTyping(true);
        } else if (message.type === 'message') {
          setIsTyping(false);
          refetchMessages();
        }
      }
    };

    // Add event listener typecasted as EventListener
    window.addEventListener('websocket-message', handleWebSocketEvent as EventListener);

    // Clean up
    return () => {
      window.removeEventListener('websocket-message', handleWebSocketEvent as EventListener);
    };
  }, [conversationId, refetchMessages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!messageInput.trim()) return;
    
    if (!user || !user.id) {
      toast({
        title: 'Authentication Required',
        description: 'You need to be logged in to send messages',
        open: true,
      });
      return;
    }
    
    try {
      // Send message through WebSocket
      sendMessage({
        type: 'message',
        conversationId,
        userId: user.id,
        content: messageInput,
        isUser: true
      });
      
      // Clear input immediately for better UX
      setMessageInput('');

      // Post to API
      await apiRequest(`/api/conversations/${conversationId}/messages`, {
        method: 'POST',
        body: JSON.stringify({
          content: messageInput,
          isUser: true
        }),
      });
      
      // Refetch messages (the AI response will come through WebSocket)
      refetchMessages();
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: 'Error',
        description: 'Failed to send message',
        open: true,
      });
    }
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Loading state
  if (conversationLoading || messagesLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="text-center">
          <div className="typing-indicator mx-auto my-4">
            <span></span>
            <span></span>
            <span></span>
          </div>
          <p className="text-gray-600">Loading conversation...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (conversationError || messagesError) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="text-center">
          <p className="text-red-500 mb-4">Failed to load the conversation</p>
          <button 
            className="ios-button mr-2"
            onClick={() => window.location.reload()}
          >
            Try Again
          </button>
          <button 
            className="ios-button-secondary"
            onClick={() => setLocation('/conversations')}
          >
            Back to Conversations
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm py-4 px-4">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <button 
              className="mr-4 text-gray-600"
              onClick={() => setLocation('/conversations')}
            >
              ← Back
            </button>
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden mr-3">
                {conversation?.character?.avatar ? (
                  <img 
                    src={conversation.character.avatar} 
                    alt={conversation.character.name}
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-primary text-white font-bold">
                    {conversation?.character?.name.charAt(0)}
                  </div>
                )}
              </div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">
                  {conversation?.character?.name || 'AI Companion'}
                </h1>
                <p className="text-xs text-gray-500">
                  {connected ? (
                    <span className="text-green-500">Connected</span>
                  ) : (
                    <span className="text-red-500">Disconnected</span>
                  )}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>
      
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 pb-4 bg-gray-50">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages && messages.length > 0 ? (
            messages.map((message: Message) => (
              <div 
                key={message.id} 
                className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                    message.isUser 
                      ? 'bg-primary text-white rounded-tr-none' 
                      : 'bg-white text-gray-800 rounded-tl-none shadow-sm'
                  }`}
                >
                  <div className="text-sm">
                    {message.content}
                  </div>
                  <div 
                    className={`text-xs mt-1 ${
                      message.isUser ? 'text-blue-100' : 'text-gray-500'
                    }`}
                  >
                    {formatTime(message.createdAt)}
                    {!message.isUser && message.emotionIcon && (
                      <span className="ml-2">{message.emotionIcon}</span>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">No messages yet. Start the conversation!</p>
            </div>
          )}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white text-gray-800 rounded-2xl rounded-tl-none shadow-sm px-4 py-3">
                <div className="typing-indicator">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      {/* Message input */}
      <div className="bg-white border-t border-gray-200 p-4">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSendMessage} className="flex items-center">
            <input
              type="text"
              className="ios-input flex-1 mr-2"
              placeholder="Type a message..."
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
            />
            <button
              type="submit"
              className="ios-button"
              disabled={!messageInput.trim() || !connected}
            >
              Send
            </button>
          </form>
          {!connected && (
            <p className="text-xs text-red-500 mt-1">
              Connection lost. Please refresh the page.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatPage;