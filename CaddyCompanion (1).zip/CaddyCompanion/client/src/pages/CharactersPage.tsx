import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useUserContext } from '../contexts/UserContext';
import { apiRequest } from '../lib/queryClient';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '../hooks/use-toast';

interface Character {
  id: number;
  name: string;
  description: string;
  avatar: string | null;
  background: string | null;
  traits: string[] | null;
  interests: string[] | null;
  tags: string;
  emotionLevel: number | null;
}

const CharactersPage: React.FC = () => {
  const { user } = useUserContext();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Fetch characters
  const { data: characters, isLoading, error } = useQuery({
    queryKey: ['/api/characters'],
    queryFn: () => apiRequest('/api/characters'),
  });

  const handleError = (error: any) => {
    console.error('Error creating conversation:', error);
    // Try to extract more detailed error information
    let errorMessage = 'An unexpected error occurred';
    
    if (error instanceof Error) {
      errorMessage = error.message;
    } else if (error.response && error.response.data) {
      // For axios-style errors
      errorMessage = error.response.data.error || error.response.data.message || JSON.stringify(error.response.data);
    } else if (typeof error === 'object') {
      errorMessage = JSON.stringify(error);
    }
    
    toast({
      title: 'Error',
      description: errorMessage,
      open: true,
    });
  };

  const handleStartChat = async (characterId: number) => {
    try {
      if (!user || !user.id) {
        toast({
          title: 'Authentication Required',
          description: 'You need to be logged in to start a conversation',
          open: true,
        });
        // Redirect to login page if needed
        // setLocation('/login');
        return;
      }
      
      // Create a new conversation with this character
      const conversation = await apiRequest('/api/conversations', {
        method: 'POST',
        body: JSON.stringify({
          userId: user.id,
          characterId,
          title: `Chat with ${characters?.find((c: {id: number, name: string}) => c.id === characterId)?.name}`,
        }),
      });
      
      // Redirect to the chat page with this conversation
      setLocation(`/chat/${conversation.id}`);
    } catch (error) {
      handleError(error);
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="text-center">
          <div className="typing-indicator mx-auto my-4">
            <span></span>
            <span></span>
            <span></span>
          </div>
          <p className="text-gray-600">Loading companions...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    toast({
      title: 'Error',
      description: 'Failed to load AI companions',
      open: true,
    });
    
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="text-center">
          <p className="text-red-500 mb-2">Failed to load AI companions</p>
          <button 
            className="ios-button"
            onClick={() => window.location.reload()}
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Caddy</h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              {user?.name}
            </span>
            <button 
              className="text-gray-600 hover:text-gray-800"
              onClick={() => setLocation('/conversations')}
            >
              Conversations
            </button>
          </div>
        </div>
      </header>
      
      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">AI Companions</h2>
          <p className="text-gray-600">
            Choose an AI companion to start a conversation
          </p>
        </div>
        
        {/* Characters grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {characters?.map((character: Character) => (
            <div 
              key={character.id} 
              className="ios-card overflow-hidden flex flex-col"
            >
              <div 
                className="h-40 bg-cover bg-center" 
                style={{ 
                  backgroundImage: character.background 
                    ? `url(${character.background})` 
                    : 'linear-gradient(to right, #4facfe, #00f2fe)'
                }}
              />
              
              <div className="p-5 flex-1 flex flex-col">
                <div className="flex items-center mb-4">
                  <div 
                    className="w-16 h-16 rounded-full bg-gray-200 -mt-12 border-4 border-white overflow-hidden"
                  >
                    {character.avatar ? (
                      <img 
                        src={character.avatar} 
                        alt={character.name} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-primary text-white text-xl font-bold">
                        {character.name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <div className="ml-3">
                    <h3 className="text-lg font-semibold text-gray-800">{character.name}</h3>
                    <div className="text-sm text-gray-500">
                      {character.tags && character.tags.split(',').map((tag, index) => (
                        <span key={index} className="inline-block bg-gray-100 rounded-full px-2 py-0.5 mr-1 mb-1">
                          {tag.trim()}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                
                <p className="text-gray-600 mb-4 flex-1">
                  {character.description.length > 120 
                    ? `${character.description.slice(0, 120)}...` 
                    : character.description}
                </p>
                
                <button
                  onClick={() => handleStartChat(character.id)}
                  className="ios-button w-full"
                >
                  Start Conversation
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default CharactersPage;