import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useUserContext } from '../contexts/UserContext';
import { useToast } from '../hooks/use-toast';
import { apiRequest } from '../lib/queryClient';
import { PersonalityPreference, InterestFocus, ConversationDepth } from '../../../shared/schema';
import { motion, AnimatePresence } from 'framer-motion';

const OnboardingPage: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const { user } = useUserContext();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Preferences state
  const [personalityPreference, setPersonalityPreference] = useState(PersonalityPreference.BALANCED);
  const [interestFocus, setInterestFocus] = useState(InterestFocus.GENERAL);
  const [conversationDepth, setConversationDepth] = useState(ConversationDepth.MODERATE);

  const totalSteps = 3;

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    } else {
      completeOnboarding();
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const completeOnboarding = async () => {
    if (!user) {
      toast({
        title: 'Authentication Error',
        description: 'You need to be logged in to complete onboarding',
        open: true,
      });
      setLocation('/');
      return;
    }

    setIsSubmitting(true);
    try {
      await apiRequest(`/api/users/${user.id}/preferences`, {
        method: 'POST',
        body: JSON.stringify({
          personalityPreference,
          interestFocus,
          conversationDepth,
          onboardingCompleted: true,
        }),
      });

      toast({
        title: 'Onboarding Complete',
        description: 'Your preferences have been saved!',
        open: true,
      });

      // Redirect to teaser chat
      setLocation('/teaser-chat');
    } catch (error) {
      console.error('Error saving preferences:', error);
      toast({
        title: 'Error',
        description: 'Failed to save your preferences. Please try again.',
        open: true,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Determine which option box is selected
  const isSelected = (
    type: 'personality' | 'interest' | 'depth',
    value: string
  ) => {
    switch (type) {
      case 'personality':
        return personalityPreference === value;
      case 'interest':
        return interestFocus === value;
      case 'depth':
        return conversationDepth === value;
      default:
        return false;
    }
  };

  // Option box component
  const OptionBox = ({
    type,
    value,
    label,
    description,
    emoji,
    index = 0
  }: {
    type: 'personality' | 'interest' | 'depth';
    value: string;
    label: string;
    description: string;
    emoji: string;
    index?: number;
  }) => {
    const selected = isSelected(type, value);

    const handleSelect = () => {
      switch (type) {
        case 'personality':
          setPersonalityPreference(value);
          break;
        case 'interest':
          setInterestFocus(value);
          break;
        case 'depth':
          setConversationDepth(value);
          break;
      }
    };

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 * index }}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className={`backdrop-blur-sm rounded-xl cursor-pointer transition-all duration-200
          ${
            selected
              ? 'bg-gradient-to-r from-blue-600/80 to-purple-600/80 text-white shadow-lg shadow-blue-600/20 border border-blue-400/30'
              : 'bg-white/10 border border-white/10 hover:bg-white/20 text-blue-100'
          }`}
        onClick={handleSelect}
      >
        <div className="p-5">
          <div className="flex items-center mb-3">
            <div className={`text-2xl mr-3 ${selected ? 'text-white' : ''}`}>{emoji}</div>
            <h3 className="font-semibold text-lg">{label}</h3>
            {selected && (
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="ml-auto bg-white/20 rounded-full p-1 flex items-center justify-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </motion.div>
            )}
          </div>
          <p className={`text-sm ${selected ? 'text-blue-100' : 'text-blue-200/80'}`}>{description}</p>
        </div>
      </motion.div>
    );
  };

  // Progress bar
  const ProgressBar = () => (
    <motion.div 
      className="w-full bg-gray-800/50 rounded-full h-2 mb-8 overflow-hidden"
      initial={{ opacity: 0, width: 0 }}
      animate={{ opacity: 1, width: '100%' }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        className="bg-gradient-to-r from-blue-500 to-purple-600 h-2 rounded-full"
        initial={{ width: 0 }}
        animate={{ width: `${(currentStep / totalSteps) * 100}%` }}
        transition={{ duration: 0.5, ease: "easeInOut" }}
      />
    </motion.div>
  );

  // Render step content
  const renderStepContent = () => {
    return (
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4 }}
        >
          {(() => {
            switch (currentStep) {
              case 1:
                return (
                  <>
                    <motion.h2 
                      className="text-2xl font-bold mb-3 text-blue-100"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                    >
                      What personality do you prefer?
                    </motion.h2>
                    <motion.p 
                      className="text-blue-200/80 mb-8"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                    >
                      This helps us match you with AI companions that fit your style
                    </motion.p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <OptionBox
                        type="personality"
                        value={PersonalityPreference.FLIRTY}
                        label="Flirty"
                        description="Playful, charming and a little bit romantic"
                        emoji="💕"
                        index={0}
                      />
                      <OptionBox
                        type="personality"
                        value={PersonalityPreference.CHILL}
                        label="Chill"
                        description="Relaxed, easy-going and down to earth"
                        emoji="😌"
                        index={1}
                      />
                      <OptionBox
                        type="personality"
                        value={PersonalityPreference.BOLD}
                        label="Bold"
                        description="Confident, direct and adventurous"
                        emoji="💪"
                        index={2}
                      />
                      <OptionBox
                        type="personality"
                        value={PersonalityPreference.SWEET}
                        label="Sweet"
                        description="Kind, supportive and nurturing"
                        emoji="🍭"
                        index={3}
                      />
                    </div>
                  </>
                );
              case 2:
                return (
                  <>
                    <motion.h2 
                      className="text-2xl font-bold mb-3 text-blue-100"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                    >
                      What topics interest you most?
                    </motion.h2>
                    <motion.p 
                      className="text-blue-200/80 mb-8"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                    >
                      We'll find companions who share your interests
                    </motion.p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <OptionBox
                        type="interest"
                        value={InterestFocus.LITERATURE}
                        label="Literature"
                        description="Books, poetry, and the written word"
                        emoji="📚"
                        index={0}
                      />
                      <OptionBox
                        type="interest"
                        value={InterestFocus.TECH}
                        label="Technology"
                        description="AI, coding, and all things tech"
                        emoji="💻"
                        index={1}
                      />
                      <OptionBox
                        type="interest"
                        value={InterestFocus.PHILOSOPHY}
                        label="Philosophy"
                        description="Deep thoughts and life's big questions"
                        emoji="🧠"
                        index={2}
                      />
                      <OptionBox
                        type="interest"
                        value={InterestFocus.ART}
                        label="Art"
                        description="Visual arts, music, and creativity"
                        emoji="🎨"
                        index={3}
                      />
                    </div>
                  </>
                );
              case 3:
                return (
                  <>
                    <motion.h2 
                      className="text-2xl font-bold mb-3 text-blue-100"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                    >
                      How deep do you want conversations to go?
                    </motion.h2>
                    <motion.p 
                      className="text-blue-200/80 mb-8"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                    >
                      This helps tailor the experience to your preferences
                    </motion.p>
                    <div className="grid grid-cols-1 gap-4">
                      <OptionBox
                        type="depth"
                        value={ConversationDepth.CASUAL}
                        label="Light & Casual"
                        description="Fun, light-hearted chats with no pressure"
                        emoji="☀️"
                        index={0}
                      />
                      <OptionBox
                        type="depth"
                        value={ConversationDepth.MODERATE}
                        label="Balanced"
                        description="Mix of light topics and deeper discussions"
                        emoji="⚖️"
                        index={1}
                      />
                      <OptionBox
                        type="depth"
                        value={ConversationDepth.DEEP}
                        label="Deep & Meaningful"
                        description="Philosophical conversations with substance"
                        emoji="🌊"
                        index={2}
                      />
                    </div>
                  </>
                );
              default:
                return null;
            }
          })()}
        </motion.div>
      </AnimatePresence>
    );
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/50 to-black"></div>
        <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-purple-700/20 via-transparent to-transparent"></div>
        <div className="absolute top-1/3 left-1/4 w-64 h-64 rounded-full bg-blue-600/10 blur-3xl animate-float delay-200"></div>
        <div className="absolute bottom-1/4 right-1/3 w-96 h-96 rounded-full bg-purple-600/10 blur-3xl animate-float"></div>
      </div>
      
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="w-full max-w-xl mx-auto px-8 py-10 rounded-3xl backdrop-blur-lg border border-white/10 bg-black/40 shadow-2xl shadow-blue-900/20"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="text-center mb-10"
          >
            <h1 className="text-3xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">
              Welcome to Cady
            </h1>
            <p className="text-blue-200 opacity-80">
              Let's customize your experience in a few steps
            </p>
          </motion.div>

          <ProgressBar />
          {renderStepContent()}

          <motion.div 
            className="flex justify-between mt-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            {currentStep > 1 ? (
              <motion.button 
                onClick={prevStep}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 rounded-lg bg-gray-800/50 text-blue-100 border border-gray-700/50 hover:bg-gray-700/50 transition-all"
                disabled={isSubmitting}
              >
                Back
              </motion.button>
            ) : (
              <div></div> // Empty div for spacing
            )}
            
            <motion.button
              onClick={nextStep}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium rounded-lg shadow-lg shadow-blue-700/30 focus:outline-none"
              disabled={isSubmitting}
            >
              {currentStep === totalSteps ? (
                isSubmitting ? (
                  <div className="flex items-center">
                    <div className="typing-indicator">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                    <span className="ml-2">Saving...</span>
                  </div>
                ) : 'Complete'
              ) : 'Continue'}
            </motion.button>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default OnboardingPage;