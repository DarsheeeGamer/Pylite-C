import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, Filter, Star, ArrowLeft, Heart, Shield } from "lucide-react";
import { Character } from "@shared/schema";
import { motion } from "framer-motion";
import { 
  FadeAnimation, 
  SlideUpAnimation, 
  SlideInLeftAnimation, 
  HoverScaleAnimation,
  ScaleAnimation,
  StaggeredListAnimation
} from "@/components/ui/animations";

const MarketplacePage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("popular");
  
  // Update page title
  useEffect(() => {
    document.title = "Caddy - Character Marketplace";
    return () => {
      document.title = "Caddy - AI Companion Chat";
    };
  }, []);

  // Fetch all characters
  const { data: characters = [], isLoading } = useQuery<Character[]>({
    queryKey: ["/api/characters"],
  });

  // Filter and sort characters
  const filteredCharacters = characters.filter(character => {
    // Search filter
    const matchesSearch = character.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         character.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Category filter
    const matchesCategory = category === "all" || character.category === category;
    
    return matchesSearch && matchesCategory;
  }).sort((a, b) => {
    // Sorting
    if (sortBy === "newest") {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    } else if (sortBy === "oldest") {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    } else if (sortBy === "popular") {
      // Assuming characters have a popularity or messageCount field
      // If not, we'll just use ID as a fallback
      return (b.messageCount || b.id) - (a.messageCount || a.id);
    } else if (sortBy === "alphabetical") {
      return a.name.localeCompare(b.name);
    }
    return 0;
  });

  // Get unique categories
  const categories = ["all", ...new Set(characters.map(char => char.category))].filter(Boolean);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-purple-700 to-indigo-700 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center">
            <div>
              <Link href="/">
                <Button variant="ghost" className="mb-4 md:mb-0 p-0 text-white hover:bg-white/10">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Home
                </Button>
              </Link>
              <h1 className="text-3xl font-bold mb-2">Caddy Character Marketplace</h1>
              <p className="text-gray-100 mb-4 max-w-2xl">
                Discover a diverse collection of AI companions created by our community. Find your perfect Caddy character.
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Search and Filter Bar */}
      <div className="sticky top-0 z-10 bg-white border-b shadow-sm py-3">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search characters..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="flex gap-3">
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat === "all" ? "All Categories" : cat.charAt(0).toUpperCase() + cat.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="popular">Most Popular</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="alphabetical">A-Z</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="all" className="mb-8">
          <TabsList className="mb-6">
            <TabsTrigger value="all">All Characters</TabsTrigger>
            <TabsTrigger value="trending">Trending</TabsTrigger>
            <TabsTrigger value="new">New Arrivals</TabsTrigger>
            <TabsTrigger value="premium">Premium</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-0">
            {isLoading ? (
              <div className="flex justify-center my-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredCharacters.length === 0 ? (
              <div className="text-center my-16">
                <div className="text-4xl mb-4">🔍</div>
                <h3 className="text-xl font-bold mb-2">No characters found</h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your search or filter criteria.
                </p>
                <Button onClick={() => {setSearchTerm(""); setCategory("all");}}>
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredCharacters.map((character) => (
                  <CharacterCard key={character.id} character={character} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="trending" className="mt-0">
            {isLoading ? (
              <div className="flex justify-center my-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {characters
                  .sort((a, b) => (b.messageCount || 0) - (a.messageCount || 0))
                  .slice(0, 8)
                  .map((character) => (
                    <CharacterCard key={character.id} character={character} />
                  ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="new" className="mt-0">
            {isLoading ? (
              <div className="flex justify-center my-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {characters
                  .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                  .slice(0, 8)
                  .map((character) => (
                    <CharacterCard key={character.id} character={character} />
                  ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="premium" className="mt-0">
            {isLoading ? (
              <div className="flex justify-center my-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {characters
                  .filter(char => char.isPremium)
                  .map((character) => (
                    <CharacterCard key={character.id} character={character} />
                  ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Create Your Own Character CTA */}
        <div className="mt-12 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-6 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h3 className="text-xl font-bold mb-2">Create Your Own Character</h3>
              <p className="text-gray-600 max-w-2xl">
                Have a unique character in mind? Create and customize your own AI companion and share it with the community.
              </p>
            </div>
            <Link href="/create-character">
              <Button className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto bg-gray-100 border-t py-6">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© {new Date().getFullYear()} Caddy AI Companion. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

const CharacterCard = ({ character }: { character: Character }) => {
  const getGradientClass = () => {
    return character.backgroundGradient || "bg-gradient-to-r from-purple-600 to-blue-600";
  };

  return (
    <HoverScaleAnimation scale={1.03}>
      <Card className="overflow-hidden shadow-md hover:shadow-xl transition-all bg-white border-0">
        <div className={`h-28 ${getGradientClass()} relative flex items-end`}>
          <motion.div 
            initial={{ opacity: 0, y: -10 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ delay: 0.2 }}
            className="absolute top-3 right-3 flex gap-2"
          >
            {character.isPremium && (
              <Badge className="bg-yellow-500 hover:bg-yellow-600 shadow-sm">
                <Shield className="h-3 w-3 mr-1" /> Premium
              </Badge>
            )}
            {character.isVerified && (
              <Badge className="bg-green-500 hover:bg-green-600 shadow-sm">
                Verified
              </Badge>
            )}
          </motion.div>
          
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.1 }}
          >
            <Avatar className="absolute bottom-0 translate-y-1/2 left-4 h-16 w-16 border-4 border-white shadow-md">
              {character.imageUrl ? (
                <AvatarImage src={character.imageUrl} alt={character.name} />
              ) : (
                <AvatarFallback className="bg-white text-primary">
                  {character.name.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              )}
            </Avatar>
          </motion.div>
        </div>
        
        <CardContent className="pt-12 pb-4">
          <div className="flex justify-between items-start mb-2">
            <motion.h3 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              transition={{ delay: 0.2 }}
              className="font-bold text-lg"
            >
              {character.name}
            </motion.h3>
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }} 
              transition={{ delay: 0.3 }}
              className="flex items-center"
            >
              <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 mr-1" />
              <span className="text-sm font-medium">
                {character.rating || "4.8"}
              </span>
            </motion.div>
          </div>
          
          <motion.p 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            transition={{ delay: 0.3 }}
            className="text-gray-600 text-sm mb-3 line-clamp-2"
          >
            {character.description}
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 10 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ delay: 0.4 }}
            className="flex flex-wrap gap-2"
          >
            {character.tags?.slice(0, 3).map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs shadow-sm">
                {tag}
              </Badge>
            ))}
          </motion.div>
        </CardContent>
        
        <CardFooter className="pt-0 flex justify-between">
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            transition={{ delay: 0.4 }}
            className="text-xs text-gray-500"
          >
            Created {new Date(character.createdAt).toLocaleDateString()}
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, type: "spring" }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Link href={`/ai/${character.id}`}>
              <Button size="sm" className="shadow-md bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700">
                Chat Now
              </Button>
            </Link>
          </motion.div>
        </CardFooter>
      </Card>
    </HoverScaleAnimation>
  );
};

export default MarketplacePage;