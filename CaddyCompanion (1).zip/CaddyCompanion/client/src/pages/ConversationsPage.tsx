import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useUserContext } from '../contexts/UserContext';
import { apiRequest } from '../lib/queryClient';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useToast } from '../hooks/use-toast';

interface Conversation {
  id: number;
  title: string;
  characterId: number;
  userId: number;
  createdAt: string;
  updatedAt: string;
  character: {
    id: number;
    name: string;
    avatar: string | null;
  };
}

const ConversationsPage: React.FC = () => {
  const { user } = useUserContext();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch conversations
  const { data: conversations, isLoading, error } = useQuery({
    queryKey: ['/api/conversations'],
    queryFn: () => apiRequest('/api/conversations'),
  });

  const handleConversationClick = (id: number) => {
    setLocation(`/chat/${id}`);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
    }).format(date);
  };

  // Error notification
  useEffect(() => {
    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to load conversations',
        open: true,
      });
    }
  }, [error, toast]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Caddy</h1>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              {user?.name}
            </span>
            <button 
              className="text-gray-600 hover:text-gray-800"
              onClick={() => setLocation('/characters')}
            >
              Characters
            </button>
          </div>
        </div>
      </header>
      
      {/* Main content */}
      <main className="max-w-3xl mx-auto px-4 py-8 sm:px-6">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Your Conversations</h2>
            <p className="text-gray-600">
              Continue your chats with AI companions
            </p>
          </div>
          <button 
            className="ios-button"
            onClick={() => setLocation('/characters')}
          >
            New Conversation
          </button>
        </div>
        
        {isLoading ? (
          <div className="text-center py-12">
            <div className="typing-indicator mx-auto my-4">
              <span></span>
              <span></span>
              <span></span>
            </div>
            <p className="text-gray-600">Loading conversations...</p>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-500 mb-4">Failed to load your conversations</p>
            <button 
              className="ios-button"
              onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/conversations'] })}
            >
              Try Again
            </button>
          </div>
        ) : conversations && conversations.length > 0 ? (
          <div className="ios-card divide-y">
            {conversations.map((conversation: Conversation) => (
              <div 
                key={conversation.id} 
                className="p-4 flex items-center hover:bg-gray-50 cursor-pointer transition-colors"
                onClick={() => handleConversationClick(conversation.id)}
              >
                <div className="mr-4">
                  <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden">
                    {conversation.character.avatar ? (
                      <img 
                        src={conversation.character.avatar} 
                        alt={conversation.character.name} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-primary text-white font-bold">
                        {conversation.character.name.charAt(0)}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg font-medium text-gray-900 truncate">
                    {conversation.title}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {conversation.character.name}
                  </p>
                </div>
                <div className="text-right text-sm text-gray-500">
                  {formatDate(conversation.updatedAt)}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <p className="text-gray-600 mb-4">You don't have any conversations yet</p>
            <button 
              className="ios-button"
              onClick={() => setLocation('/characters')}
            >
              Start a Conversation
            </button>
          </div>
        )}
      </main>
    </div>
  );
};

export default ConversationsPage;