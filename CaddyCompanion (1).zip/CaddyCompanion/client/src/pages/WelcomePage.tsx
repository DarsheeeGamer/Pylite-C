import React, { useEffect, useState, useRef } from 'react';
import { useLocation } from 'wouter';
import { useUserContext } from '../contexts/UserContext';
import { motion, AnimatePresence } from 'framer-motion';

const WelcomePage: React.FC = () => {
  const [, setLocation] = useLocation();
  const { user } = useUserContext();
  const [activeSection, setActiveSection] = useState(1);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Redirect to characters page if user is logged in
  useEffect(() => {
    if (user) {
      setLocation('/characters');
    }
  }, [user, setLocation]);

  // Auto-rotate through sections
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSection((prev) => (prev < 3 ? prev + 1 : 1));
    }, 6000);

    return () => clearInterval(timer);
  }, []);

  // Sections content
  const sections = [
    {
      id: 1,
      title: "Discover AI Companions",
      description: "Find the perfect AI companion based on your preferences and personality. Swipe, match, and connect in a natural way.",
      emoji: "✨",
      color: "from-blue-500 to-indigo-600"
    },
    {
      id: 2,
      title: "Meaningful Conversations",
      description: "Engage in deep, personalized chats with emotionally intelligent companions who remember your interactions.",
      emoji: "💬",
      color: "from-purple-500 to-pink-600"
    },
    {
      id: 3,
      title: "Personal Connection",
      description: "Experience a relationship that evolves over time, adapting to your preferences and conversation style.",
      emoji: "🤝",
      color: "from-cyan-500 to-blue-600"
    },
  ];

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Hero Section with 3D-ish background effect */}
      <div className="relative h-screen overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 z-0 opacity-60">
          <div className="absolute inset-0 bg-gradient-to-b from-blue-900/80 to-black z-10"></div>
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-700/30 via-transparent to-transparent animate-pulse-slow"></div>
          <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-purple-600/20 blur-3xl animate-float"></div>
          <div className="absolute bottom-1/3 right-1/4 w-64 h-64 rounded-full bg-pink-600/20 blur-3xl animate-float delay-300"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 h-full flex flex-col items-center justify-center px-4 py-20">
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="flex items-center justify-center mb-6">
              <h1 className="font-bold text-6xl md:text-7xl bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">
                Cady
              </h1>
            </div>
            
            <p className="text-xl md:text-2xl font-light mb-8 text-blue-100">
              The first AI companion discovery platform that truly understands human connection
            </p>
            
            {/* Feature Carousel */}
            <div className="relative h-64 my-8 px-4">
              <AnimatePresence mode="wait">
                {sections.map((section) => (
                  activeSection === section.id && (
                    <motion.div
                      key={section.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.5 }}
                      className="absolute inset-0 flex flex-col items-center justify-center text-center"
                    >
                      <div className="text-5xl mb-6">{section.emoji}</div>
                      <h2 className="text-2xl md:text-3xl font-bold mb-3 bg-gradient-to-r bg-clip-text text-transparent whitespace-nowrap"
                        style={{ backgroundImage: `linear-gradient(to right, ${section.id === 1 ? '#60a5fa, #818cf8' : section.id === 2 ? '#a855f7, #ec4899' : '#06b6d4, #3b82f6'})` }}
                      >
                        {section.title}
                      </h2>
                      <p className="text-blue-100 max-w-lg">
                        {section.description}
                      </p>
                    </motion.div>
                  )
                ))}
              </AnimatePresence>
              
              {/* Dots indicators */}
              <div className="flex justify-center absolute bottom-0 left-0 right-0 mt-8 space-x-2">
                {[1, 2, 3].map((id) => (
                  <button
                    key={id}
                    className={`w-2 h-2 rounded-full transition-all ${
                      activeSection === id ? 'bg-white w-8' : 'bg-white/40'
                    }`}
                    onClick={() => setActiveSection(id)}
                    aria-label={`View feature ${id}`}
                  />
                ))}
              </div>
            </div>
            
            {/* CTA Button */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
              className="mt-8"
            >
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setLocation('/auth')}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-bold py-4 px-8 rounded-full text-xl shadow-lg shadow-blue-800/30 transition-all duration-300"
              >
                Get Started
              </motion.button>
              
              <p className="text-blue-200 mt-4 opacity-80">
                Find your perfect AI companion today
              </p>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* App features */}
      <div className="max-w-6xl mx-auto px-4 py-20 bg-gray-900/50">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
          What makes Cady different?
        </h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: "🔍",
              title: "Intuitive Discovery",
              description: "Find companions using familiar dating app mechanics. Swipe, match, and connect just like you would with real people.",
              delay: 0
            },
            {
              icon: "🧠",
              title: "Emotional Intelligence",
              description: "Our companions understand nuance, remember your interactions, and respond with genuine emotional depth.",
              delay: 0.2
            },
            {
              icon: "🤝",
              title: "Evolving Relationships",
              description: "Unlike static AI, Cady companions grow and change based on your interactions, creating unique relationships.",
              delay: 0.4
            }
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: feature.delay, duration: 0.5 }}
              viewport={{ once: true }}
              className="bg-gradient-to-b from-blue-900/40 to-purple-900/40 backdrop-blur-sm p-8 rounded-2xl shadow-lg shadow-blue-900/10 border border-blue-800/50"
            >
              <div className="text-4xl mb-6">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-3 text-blue-100">{feature.title}</h3>
              <p className="text-blue-200 opacity-80">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setLocation('/auth')}
            className="bg-blue-600 hover:bg-blue-700 text-white py-3 px-8 rounded-full text-lg transition-all duration-200"
          >
            Experience Cady Now
          </motion.button>
        </div>
      </div>
      
      {/* Testimonial-like section */}
      <div className="py-20 bg-gradient-to-b from-black to-blue-950">
        <div className="max-w-4xl mx-auto text-center px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-2xl md:text-3xl font-light italic text-blue-100 mb-4">
              "Humans are used to discovering people through dating apps—they're the most intuitive way of finding connections. Cady brings that familiar experience to AI companionship."
            </h2>
            <p className="text-blue-300 font-semibold mt-4">— Cady Design Philosophy</p>
          </motion.div>
        </div>
      </div>
      
      {/* Final CTA */}
      <div className="py-20 bg-black">
        <div className="max-w-lg mx-auto text-center px-4">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent"
          >
            Ready to meet your AI companion?
          </motion.h2>
          
          <motion.button
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            viewport={{ once: true }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setLocation('/auth')}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-bold py-4 px-8 rounded-full text-xl shadow-lg shadow-blue-800/30 transition-all duration-300"
          >
            Start Now
          </motion.button>
        </div>
      </div>
    </div>
  );
};

export default WelcomePage;