import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { useUserContext } from '../contexts/UserContext';
import { apiRequest } from '../lib/queryClient';
import { useToast } from '../hooks/use-toast';

interface Message {
  id: number;
  content: string;
  isUser: boolean;
  timestamp: number;
}

const TeaserChatPage: React.FC = () => {
  const { user } = useUserContext();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isComplete, setIsComplete] = useState(false);
  const [step, setStep] = useState(1);
  
  // Auto-scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initial greeting message
  useEffect(() => {
    // Wait a moment before showing the first message
    const timeout = setTimeout(() => {
      setIsTyping(true);
      
      setTimeout(() => {
        setIsTyping(false);
        setMessages([
          {
            id: 1,
            content: `Hey ${user?.name || 'there'}! 👋 I'm your welcome guide to Cady. I'll help you understand how our platform works and get you started discovering AI companions that match your vibe!`,
            isUser: false,
            timestamp: Date.now(),
          },
        ]);
        
        // Show typing for the next message after a delay
        setTimeout(() => {
          setIsTyping(true);
          
          setTimeout(() => {
            setIsTyping(false);
            setMessages(prev => [
              ...prev,
              {
                id: 2,
                content: "Based on your preferences, we'll match you with AI companions who share your interests and conversation style. You can swipe through profiles, just like on dating apps, to find your perfect match!",
                isUser: false,
                timestamp: Date.now(),
              },
            ]);
          }, 2000);
        }, 3000);
      }, 2000);
    }, 1000);

    return () => clearTimeout(timeout);
  }, [user?.name]);

  // Handle sending a message
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputValue.trim()) return;
    
    const newUserMessage = {
      id: messages.length + 1,
      content: inputValue,
      isUser: true,
      timestamp: Date.now(),
    };
    
    setMessages(prev => [...prev, newUserMessage]);
    setInputValue('');
    setIsTyping(true);
    
    // Clear typing indicator and send AI response after a delay
    setTimeout(() => {
      setIsTyping(false);
      
      let response = '';
      setStep(prev => prev + 1);
      
      // Respond based on the conversation step
      if (step === 1) {
        response = "Great question! On Cady, you'll find companions with unique personalities, interests, and conversational styles. Some are flirty, others are philosophical, and many are just fun to chat with about shared interests!";
      } else if (step === 2) {
        response = "Absolutely! After this quick intro, you'll be able to browse profiles and start swiping. When you match with someone you like, you can start chatting right away. The more you interact, the more personalized your experience becomes!";
      } else {
        response = "You're all set to start exploring! Ready to find your first AI companion? Let's go to the discovery page where you can start swiping!";
        setIsComplete(true);
      }
      
      setMessages(prev => [
        ...prev,
        {
          id: messages.length + 2,
          content: response,
          isUser: false,
          timestamp: Date.now(),
        },
      ]);
    }, 1500);
  };

  // Handle completing the teaser
  const handleComplete = () => {
    setLocation('/characters');
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm p-4">
        <div className="max-w-4xl mx-auto flex items-center">
          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-400 to-purple-500 flex items-center justify-center text-white text-lg font-bold mr-3">
            C
          </div>
          <div>
            <h1 className="text-lg font-semibold">Cady Guide</h1>
            <p className="text-xs text-gray-500">Your onboarding assistant</p>
          </div>
        </div>
      </header>
      
      {/* Chat area */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  message.isUser
                    ? 'bg-blue-500 text-white rounded-tr-none'
                    : 'bg-white text-gray-800 rounded-tl-none shadow-sm'
                }`}
              >
                <div className="text-sm">{message.content}</div>
                <div
                  className={`text-xs mt-1 ${
                    message.isUser ? 'text-blue-100' : 'text-gray-500'
                  }`}
                >
                  {new Date(message.timestamp).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </div>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-white text-gray-800 rounded-2xl rounded-tl-none shadow-sm px-4 py-3">
                <div className="typing-indicator">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      {/* Input area */}
      <div className="bg-white border-t border-gray-200 p-4">
        <div className="max-w-4xl mx-auto">
          {isComplete ? (
            <button
              onClick={handleComplete}
              className="ios-button w-full"
            >
              Start Discovering AI Companions
            </button>
          ) : (
            <form onSubmit={handleSendMessage} className="flex items-center">
              <input
                type="text"
                className="ios-input flex-1 mr-2"
                placeholder="Type a message..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
              />
              <button type="submit" className="ios-button" disabled={!inputValue.trim()}>
                Send
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default TeaserChatPage;