import React, { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { motion } from 'framer-motion';

export default function EmailVerifiedPage() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [isSuccess, setIsSuccess] = useState<boolean | null>(null);

  useEffect(() => {
    // Check if URL has success parameter
    const searchParams = new URLSearchParams(window.location.search);
    const success = searchParams.get('success');
    
    if (success === 'true') {
      setIsSuccess(true);
      toast({
        title: 'Email Verified',
        description: 'Your email address has been successfully verified.',
        variant: 'default',
      });
    } else {
      setIsSuccess(false);
    }
  }, [toast]);

  // Redirect to login after 5 seconds on success
  useEffect(() => {
    if (isSuccess) {
      const timer = setTimeout(() => {
        navigate('/auth');
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, [isSuccess, navigate]);

  if (isSuccess === null) {
    return <div className="flex justify-center items-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-background to-background/80 p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="w-[350px] md:w-[450px] shadow-lg">
          <CardHeader className="text-center">
            {isSuccess ? (
              <CheckCircle className="text-green-500 w-16 h-16 mx-auto mb-2" />
            ) : (
              <XCircle className="text-red-500 w-16 h-16 mx-auto mb-2" />
            )}
            <CardTitle className="text-2xl">
              {isSuccess ? 'Email Verified!' : 'Verification Failed'}
            </CardTitle>
            <CardDescription>
              {isSuccess 
                ? 'Your email has been successfully verified.' 
                : 'There was a problem verifying your email.'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-center text-muted-foreground">
              {isSuccess 
                ? 'You can now enjoy all features of Cady.social. Redirecting you to login page in a few seconds...' 
                : 'The verification link may be invalid or expired. Please request a new verification email.'}
            </p>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button 
              onClick={() => navigate('/auth')} 
              variant={isSuccess ? "outline" : "default"}
            >
              {isSuccess ? 'Go to Login Now' : 'Back to Login'}
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
}