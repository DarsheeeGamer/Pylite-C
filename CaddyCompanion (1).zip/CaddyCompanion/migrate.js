// Database migration script
import pg from 'pg';
import dotenv from 'dotenv';

const { Pool } = pg;
dotenv.config();

async function main() {
  console.log('Starting database migration...');
  
  try {
    // Connect to the database
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL
    });
    
    console.log('Connected to database. Creating tables...');
    
    // Create tables
    try {
      // Create users table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS users (
          id SERIAL PRIMARY KEY,
          username TEXT NOT NULL UNIQUE,
          password TEXT NOT NULL,
          display_name TEXT,
          email TEXT NOT NULL UNIQUE,
          role TEXT DEFAULT 'user',
          profile_picture TEXT,
          preferences JSONB,
          last_active TIMESTAMP,
          is_verified BOOLEAN DEFAULT FALSE,
          verification_token TEXT,
          verification_token_expiry TIMESTAMP,
          reset_password_token TEXT,
          reset_password_token_expiry TIMESTAMP,
          created_at TIMESTAMP NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        );
      `);
      console.log('Users table created.');
      
      // Create characters table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS characters (
          id SERIAL PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT NOT NULL,
          system_prompt TEXT NOT NULL,
          image_url TEXT,
          background_gradient TEXT,
          tags TEXT[],
          category TEXT,
          is_default BOOLEAN DEFAULT FALSE,
          is_premium BOOLEAN DEFAULT FALSE,
          is_verified BOOLEAN DEFAULT FALSE,
          rating TEXT,
          message_count INTEGER DEFAULT 0,
          creator_id INTEGER REFERENCES users(id),
          customizations JSONB,
          created_at TIMESTAMP NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        );
      `);
      console.log('Characters table created.');
      
      // Create conversations table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS conversations (
          id SERIAL PRIMARY KEY,
          user_id INTEGER REFERENCES users(id),
          character_id INTEGER REFERENCES characters(id),
          title TEXT DEFAULT 'New Conversation',
          created_at TIMESTAMP NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        );
      `);
      console.log('Conversations table created.');
      
      // Create messages table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS messages (
          id SERIAL PRIMARY KEY,
          conversation_id INTEGER REFERENCES conversations(id),
          content TEXT NOT NULL,
          role TEXT NOT NULL,
          timestamp TIMESTAMP DEFAULT NOW()
        );
      `);
      console.log('Messages table created.');
      
      // Create memories table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS memories (
          id SERIAL PRIMARY KEY,
          character_id INTEGER REFERENCES characters(id),
          user_id INTEGER REFERENCES users(id),
          content TEXT NOT NULL,
          importance DOUBLE PRECISION DEFAULT 0.5,
          tags TEXT[],
          embedding TEXT,
          created_at TIMESTAMP DEFAULT NOW(),
          updated_at TIMESTAMP
        );
      `);
      console.log('Memories table created.');
      
      console.log('All tables created successfully.');

      // Check if tables were created successfully
      const tablesResult = await pool.query(`
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public'
      `);
      
      console.log('Tables in database:');
      tablesResult.rows.forEach(row => {
        console.log(`- ${row.table_name}`);
      });
      
    } catch (error) {
      console.error('Error creating tables:', error);
      throw error;
    }
    
    console.log('Database migration completed successfully!');
    
    // Close pool
    await pool.end();
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

main().catch(console.error);