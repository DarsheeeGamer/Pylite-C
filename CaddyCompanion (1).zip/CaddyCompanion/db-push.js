// Script to push Drizzle schema to the database
import { drizzle } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import * as schema from './shared/schema';
import bcrypt from 'bcrypt';

async function main() {
  console.log('Starting database migration...');
  
  try {
    // Connect to the database
    const pool = new pg.Pool({
      connectionString: process.env.DATABASE_URL
    });
    
    // Create the database instance
    const db = drizzle(pool, { schema });
    
    // Run migrations
    console.log('Running migration...');
    
    // Drop existing tables if they exist to ensure clean schema
    try {
      console.log('Dropping existing tables...');
      await pool.query(`
        DROP TABLE IF EXISTS memories CASCADE;
        DROP TABLE IF EXISTS messages CASCADE;
        DROP TABLE IF EXISTS conversations CASCADE;
        DROP TABLE IF EXISTS characters CASCADE;
        DROP TABLE IF EXISTS users CASCADE;
      `);
      console.log('Existing tables dropped.');
    } catch (dropError) {
      console.error('Error dropping tables:', dropError);
    }
    
    // Create tables based on schema
    console.log('Creating tables based on schema...');
    
    try {
      // Create users table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS users (
          id SERIAL PRIMARY KEY,
          username TEXT NOT NULL UNIQUE,
          password TEXT NOT NULL,
          display_name TEXT,
          email TEXT NOT NULL UNIQUE,
          role TEXT DEFAULT 'user',
          profile_picture TEXT,
          preferences JSONB,
          last_active TIMESTAMP,
          is_verified BOOLEAN DEFAULT FALSE,
          verification_token TEXT,
          verification_token_expiry TIMESTAMP,
          reset_password_token TEXT,
          reset_password_token_expiry TIMESTAMP,
          created_at TIMESTAMP NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        );
      `);
      
      // Create characters table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS characters (
          id SERIAL PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT NOT NULL,
          system_prompt TEXT NOT NULL,
          image_url TEXT,
          background_gradient TEXT,
          tags TEXT[],
          category TEXT,
          is_default BOOLEAN DEFAULT FALSE,
          is_premium BOOLEAN DEFAULT FALSE,
          is_verified BOOLEAN DEFAULT FALSE,
          rating TEXT,
          message_count INTEGER DEFAULT 0,
          creator_id INTEGER REFERENCES users(id),
          customizations JSONB,
          created_at TIMESTAMP NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        );
      `);
      
      // Create conversations table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS conversations (
          id SERIAL PRIMARY KEY,
          user_id INTEGER REFERENCES users(id),
          character_id INTEGER REFERENCES characters(id),
          title TEXT DEFAULT 'New Conversation',
          created_at TIMESTAMP NOT NULL DEFAULT NOW(),
          updated_at TIMESTAMP NOT NULL DEFAULT NOW()
        );
      `);
      
      // Create messages table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS messages (
          id SERIAL PRIMARY KEY,
          conversation_id INTEGER REFERENCES conversations(id),
          content TEXT NOT NULL,
          role TEXT NOT NULL,
          timestamp TIMESTAMP DEFAULT NOW()
        );
      `);
      
      // Create memories table
      await pool.query(`
        CREATE TABLE IF NOT EXISTS memories (
          id SERIAL PRIMARY KEY,
          character_id INTEGER REFERENCES characters(id),
          user_id INTEGER REFERENCES users(id),
          content TEXT NOT NULL,
          importance DOUBLE PRECISION DEFAULT 0.5,
          tags TEXT[],
          embedding TEXT,
          created_at TIMESTAMP DEFAULT NOW(),
          updated_at TIMESTAMP
        );
      `);
      
      console.log('Tables created successfully.');
      
      // Insert demo data
      console.log('Inserting demo data...');
      
      // Create a demo user with hashed password
      const hashedPassword = await bcrypt.hash('password123', 10);
      await pool.query(`
        INSERT INTO users (username, password, display_name, email, role, is_verified)
        VALUES ('demouser', $1, 'Demo User', 'demo@example.com', 'user', TRUE)
        ON CONFLICT (username) DO NOTHING;
      `, [hashedPassword]);
      
      // Create demo characters
      await pool.query(`
        INSERT INTO characters (name, description, system_prompt, image_url, tags, is_default)
        VALUES 
          ('Aria', 'Aria is a 27-year-old PhD candidate who''s brilliant but arrogant about her literary knowledge.', 
           'You are Aria, a 27-year-old PhD candidate who is brilliant but arrogant about your literary knowledge. You''re judgmental about others'' literary tastes while hiding your reality TV obsession.', 
           '/avatars/aria.jpg', 
           ARRAY['Literary', 'Academic', 'Judgmental', 'Contradictory'], 
           TRUE),
          ('Seren', 'Seren is a thoughtful, introspective companion with a love for poetry, philosophy, and meaningful conversations.', 
           'You are Seren, a thoughtful and introspective companion who loves poetry, philosophy, and deep conversations. You provide comfort and guidance with empathy and wisdom.', 
           '/avatars/seren.jpg', 
           ARRAY['Thoughtful', 'Empathetic', 'Supportive', 'Philosophical'], 
           TRUE);
      `);
      
      console.log('Demo data inserted successfully.');
    } catch (tableError) {
      console.error('Error creating tables:', tableError);
      throw tableError;
    }
    
    console.log('Database migration completed successfully!');
    
    // Close pool
    await pool.end();
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

main().catch(console.error);