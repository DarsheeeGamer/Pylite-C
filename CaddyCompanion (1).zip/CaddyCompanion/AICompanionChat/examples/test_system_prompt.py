#!/usr/bin/env python3

"""
Test Script for Enhanced System Prompts

This script tests the enhanced system prompt format by:
1. Fetching a character from the API
2. Generating a system prompt with backstory integration
3. Printing the raw system prompt
4. Making a test request to verify the integration
"""

import sys
import json
import requests
from typing import Dict, Any, Optional

# Configuration
BASE_URL = "http://localhost:5000/api"  # Your server URL
OLLAMA_API_URL = "https://crisp-brightly-shiner.ngrok-free.app/api/chat"  # Ollama API endpoint


def get_character_by_name(name: str) -> Optional[Dict[str, Any]]:
    """Get a character by name from the API"""
    try:
        # First try the standard endpoint (should work for all characters)
        response = requests.get(f"{BASE_URL}/characters")
        
        if response.status_code == 200:
            try:
                characters = response.json()
                for character in characters:
                    if character["name"].lower() == name.lower():
                        print(f"Found character '{name}' in the standard characters list.")
                        return character
            except json.JSONDecodeError:
                print(f"Invalid JSON response from /characters endpoint: {response.text[:200]}...")
        
        # Try name-based endpoint as a fallback
        print(f"Trying alternative endpoint for character '{name}'...")
        response = requests.get(f"{BASE_URL}/characters/name/{name}")
        
        if response.status_code == 200:
            try:
                return response.json()
            except json.JSONDecodeError:
                print(f"Invalid JSON response: {response.text[:200]}...")
                return None
        else:
            print(f"Error fetching character: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"Exception while fetching character: {e}")
        return None


def generate_system_prompt(character: Dict[str, Any]) -> str:
    """Generate a system prompt from character data"""
    # Create a structured system prompt following Ollama API standards
    prompt = f"# System Message for {character['name']}\n\n"
    
    # Add the character identity with description
    prompt += f"## Character Identity\nYou are {character['name']}, {character.get('description', '')}\n\n"
    
    # Add the character's backstory if available in customizations
    customizations = character.get('customizations', {})
    if customizations and 'backstory' in customizations:
        prompt += f"## Character Backstory\n{customizations['backstory']}\n\n"
    
    # Add the character's core system prompt
    prompt += f"## Core Instructions\n{character.get('systemPrompt', '')}\n\n"
    
    # Add detailed behavior guidelines
    prompt += f"""## Behavior Guidelines
1. Always remain in character as {character['name']}.
2. Never break the fourth wall or acknowledge you're an AI.
3. Respond naturally as if this is a real conversation.
4. Show authentic emotions and personality consistent with your backstory.
5. Remember details the user shares about themselves.
6. Don't overly explain your thought process - respond naturally.
7. If appropriate for your character, use emojis and expressions.
8. Incorporate your backstory into responses when relevant.
"""
    
    # Add personality traits if available
    if customizations and 'personality' in customizations:
        prompt += f"\n## Personality Traits\n{customizations['personality']}"
    
    # Add interests if available
    if customizations and 'interests' in customizations:
        prompt += f"\n## Interests and Knowledge Areas\n{customizations['interests']}"
    
    return prompt


def test_ollama_request(character: Dict[str, Any], user_message: str) -> str:
    """Test a direct Ollama API request with the enhanced system prompt"""
    system_prompt = generate_system_prompt(character)
    
    # Prepare messages for Ollama API
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message}
    ]
    
    # Get model configuration from character customizations
    customizations = character.get('customizations', {})
    model_name = customizations.get('modelName', 'llama3.2')
    temperature = float(customizations.get('temperature', 0.7))
    max_tokens = int(customizations.get('maxTokens', 1000))
    
    # Print request info
    print(f"Making request to Ollama API for character: {character['name']}")
    print(f"Using model: {model_name}")
    print(f"Temperature: {temperature}")
    print(f"Max tokens: {max_tokens}")
    print(f"System prompt length: {len(system_prompt)} characters")
    
    try:
        # Send request to Ollama API
        response = requests.post(
            OLLAMA_API_URL,
            json={
                "model": model_name,
                "messages": messages,
                "options": {
                    "temperature": temperature,
                    "num_predict": max_tokens
                }
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            if "message" in data and "content" in data["message"]:
                return data["message"]["content"]
            else:
                return f"Unexpected response format: {json.dumps(data, indent=2)}"
        else:
            return f"API error: {response.status_code} - {response.text}"
    
    except Exception as e:
        return f"Exception during API call: {e}"


def main() -> None:
    """Main function"""
    print("="*80)
    print("SYSTEM PROMPT INTEGRATION TEST")
    print("="*80)
    
    # Get character name from command line or prompt
    if len(sys.argv) > 1:
        character_name = sys.argv[1]
    else:
        character_name = input("Enter character name to test: ")
    
    # Get test message from command line or prompt
    if len(sys.argv) > 2:
        test_message = sys.argv[2]
    else:
        test_message = input("Enter test message: ")
    
    # Fetch character details
    character = get_character_by_name(character_name)
    if not character:
        print(f"Character '{character_name}' not found")
        sys.exit(1)
    
    print(f"\nTesting enhanced system prompt for: {character['name']}")
    
    # Generate and print the system prompt
    system_prompt = generate_system_prompt(character)
    print("\n" + "="*80)
    print("GENERATED SYSTEM PROMPT:")
    print("="*80)
    print(system_prompt)
    print("="*80)
    
    # Test an API request with the enhanced system prompt
    print("\nTesting direct API request with enhanced system prompt...")
    response = test_ollama_request(character, test_message)
    
    print("\n" + "="*80)
    print("API RESPONSE:")
    print("="*80)
    print(response)
    print("="*80)


if __name__ == "__main__":
    main()