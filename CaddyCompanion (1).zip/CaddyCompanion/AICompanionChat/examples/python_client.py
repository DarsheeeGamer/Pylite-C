"""
Character.AI-style API Python Client

This sample script demonstrates how to interact with the character-based API
using Python requests library. It supports both ID-based and name-based character access.
"""

import requests
import json
import time
import sys

BASE_URL = "http://localhost:5000/api"  # Change to your server address if different
AUTH_TOKEN = None  # Will be set after login


def login(username, password):
    """Log in to get auth token"""
    response = requests.post(
        f"{BASE_URL}/login",
        json={"username": username, "password": password}
    )
    
    if response.status_code != 200:
        print(f"Login failed: {response.text}")
        return False
    
    global AUTH_TOKEN
    AUTH_TOKEN = response.cookies.get("connect.sid")  # For cookie-based auth
    # If using JWT:
    # AUTH_TOKEN = response.json().get("token")
    
    print(f"Successfully logged in as {username}")
    return True


def get_headers():
    """Get headers with auth token"""
    headers = {"Content-Type": "application/json"}
    if AUTH_TOKEN:
        # For cookie-based auth:
        headers["Cookie"] = f"connect.sid={AUTH_TOKEN}"
        # For JWT:
        # headers["Authorization"] = f"Bearer {AUTH_TOKEN}"
    return headers


def get_characters():
    """Get all available characters"""
    response = requests.get(f"{BASE_URL}/characters", headers=get_headers())
    
    if response.status_code != 200:
        print(f"Failed to get characters: {response.text}")
        return []
    
    characters = response.json()
    return characters


def get_character_by_name(name):
    """Get a character by name"""
    characters = get_characters()
    for character in characters:
        if character["name"].lower() == name.lower():
            return character
    return None


def send_message(character_name, message):
    """Send a message to a character by name"""
    print(f"Sending message to {character_name}: {message}")
    
    response = requests.post(
        f"{BASE_URL}/messages",
        headers=get_headers(),
        json={"character": character_name, "content": message}
    )
    
    if response.status_code != 202:
        print(f"Failed to send message: {response.text}")
        return None
    
    print("Message sent successfully! Waiting for response...")
    return True


def get_messages(character_name):
    """Get conversation history with a character by name"""
    response = requests.get(
        f"{BASE_URL}/messages?character={character_name}",
        headers=get_headers()
    )
    
    if response.status_code != 200:
        print(f"Failed to get messages: {response.text}")
        return []
    
    messages = response.json()
    return messages


def chat_with_character(character_name, message, max_wait=30):
    """Send a message and wait for the response"""
    # Send the message
    if not send_message(character_name, message):
        return
    
    # Get the initial messages to find the latest ID
    initial_messages = get_messages(character_name)
    initial_count = len(initial_messages)
    
    # Wait for the response by polling
    start_time = time.time()
    while time.time() - start_time < max_wait:
        time.sleep(1)  # Check every second
        
        current_messages = get_messages(character_name)
        if len(current_messages) > initial_count:
            # New message received
            ai_response = current_messages[-1]["content"]
            print(f"\n{character_name}: {ai_response}")
            return ai_response
        
        sys.stdout.write(".")
        sys.stdout.flush()
    
    print("\nTimed out waiting for response.")
    return None


def stream_response(character_name, message):
    """Use streaming API to get response in real-time"""
    # First send the message in background
    send_message(character_name, message)
    
    # Connect to stream endpoint (SSE)
    # Note: Python's requests doesn't natively support SSE
    # For real SSE, you'd need a library like sseclient or asyncio
    print(f"Streaming response from {character_name}...")
    print("This is a placeholder for streaming. In a real implementation, you would use:")
    print("- SSE client for JavaScript/browser")
    print("- sseclient-py or aiohttp for Python async streaming")
    
    # Instead of real streaming, get the full response
    time.sleep(2)  # Give time for the message to be processed
    messages = get_messages(character_name)
    if messages and len(messages) > 0:
        ai_response = messages[-1]["content"]
        print(f"\n{character_name}: {ai_response}")
        return ai_response
    
    return None


def main():
    """Main function to run the demo"""
    # Replace with your credentials
    # If guest mode is enabled, you can skip login
    username = "user"  # Replace with your username
    password = "password"  # Replace with your password
    
    # Login (optional if guest mode is enabled)
    login(username, password)
    
    # Get all characters
    print("Available characters:")
    characters = get_characters()
    for idx, character in enumerate(characters):
        print(f"{idx+1}. {character['name']} - {character['description']}")
    
    # Select a character
    character_name = input("\nEnter character name to chat with: ")
    
    # Start chatting
    print(f"\nStarting chat with {character_name}. Type 'exit' to quit.")
    while True:
        message = input("\nYou: ")
        if message.lower() == 'exit':
            break
        
        # Use streaming for a better experience
        stream_response(character_name, message)


if __name__ == "__main__":
    main()