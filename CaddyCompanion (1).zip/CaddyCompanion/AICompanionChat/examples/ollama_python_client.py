"""
Character.AI API Integration with Ollama Python Client

This script demonstrates how to use the Ollama Python client to directly interact with
character AI models, using character backstories and system prompts.
"""

import os
import sys
import json
import time
import requests

# Install Ollama Python client if not already installed
try:
    import ollama
except ImportError:
    print("Ollama Python client not found. Installing...")
    os.system("pip install ollama")
    import ollama

# ===== Configuration =====
BASE_URL = "http://localhost:5000/api"  # Your Character.AI server URL
AUTH_TOKEN = None  # Will be set after login
OLLAMA_BASE_URL = "https://crisp-brightly-shiner.ngrok-free.app"  # Update to your Ollama endpoint


# ===== Server Authentication Functions =====
def login(username, password):
    """Log in to the Character.AI server"""
    response = requests.post(
        f"{BASE_URL}/login",
        json={"username": username, "password": password}
    )
    
    if response.status_code != 200:
        print(f"Login failed: {response.text}")
        return False
    
    global AUTH_TOKEN
    AUTH_TOKEN = response.cookies.get("connect.sid")  # For cookie-based auth
    # If using JWT:
    # AUTH_TOKEN = response.json().get("token")
    
    print(f"Successfully logged in as {username}")
    return True


def get_headers():
    """Get headers with auth token"""
    headers = {"Content-Type": "application/json"}
    if AUTH_TOKEN:
        # For cookie-based auth:
        headers["Cookie"] = f"connect.sid={AUTH_TOKEN}"
        # For JWT:
        # headers["Authorization"] = f"Bearer {AUTH_TOKEN}"
    return headers


def get_characters():
    """Get all available characters from the server"""
    response = requests.get(f"{BASE_URL}/characters", headers=get_headers())
    
    if response.status_code != 200:
        print(f"Failed to get characters: {response.text}")
        return []
    
    characters = response.json()
    return characters


def get_character_by_name(name):
    """Get a character by name from the server"""
    characters = get_characters()
    for character in characters:
        if character["name"].lower() == name.lower():
            return character
    return None


# ===== Direct Ollama Integration =====
def setup_ollama_client():
    """Configure the Ollama client"""
    # Configure the client to use the specified URL
    ollama_client = ollama.Client(host=OLLAMA_BASE_URL)
    return ollama_client


def chat_with_ollama(character_name, user_message, history=None):
    """Chat directly with Ollama using character system prompts"""
    # Set up the client
    client = setup_ollama_client()
    
    # Get character details from server
    character = get_character_by_name(character_name)
    if not character:
        print(f"Character '{character_name}' not found")
        return None
    
    # Extract character information
    system_prompt = character.get("systemPrompt", "")
    backstory = character.get("backstory", "")
    
    # If backstory exists but isn't in the system prompt, append it
    if backstory and backstory not in system_prompt:
        enhanced_system_prompt = f"{system_prompt}\n\nCharacter Backstory: {backstory}"
    else:
        enhanced_system_prompt = system_prompt
    
    # Prepare messages with system prompt
    messages = [
        {"role": "system", "content": enhanced_system_prompt}
    ]
    
    # Add history if provided
    if history:
        messages.extend(history)
    
    # Add the user's message
    messages.append({"role": "user", "content": user_message})
    
    print(f"Sending request to Ollama with {len(messages)} messages...")
    
    try:
        # Use the model from character settings or default to llama3.2
        model_name = character.get("customizations", {}).get("modelName", "llama3.2")
        temperature = float(character.get("customizations", {}).get("temperature", 0.7))
        max_tokens = int(character.get("customizations", {}).get("maxTokens", 1000))
        
        print(f"Using model: {model_name}, temperature: {temperature}, max_tokens: {max_tokens}")
        
        # Option 1: Non-streaming response
        response = client.chat(
            model=model_name,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens
        )
        
        return response["message"]["content"]
        
    except Exception as e:
        print(f"Error communicating with Ollama: {e}")
        return f"I'm sorry, I encountered an error: {str(e)}"


def stream_chat_with_ollama(character_name, user_message, history=None):
    """Chat with Ollama using streaming for real-time responses"""
    # Set up the client
    client = setup_ollama_client()
    
    # Get character details
    character = get_character_by_name(character_name)
    if not character:
        print(f"Character '{character_name}' not found")
        return None
    
    # Extract character information
    system_prompt = character.get("systemPrompt", "")
    backstory = character.get("backstory", "")
    
    # If backstory exists but isn't in the system prompt, append it
    if backstory and backstory not in system_prompt:
        enhanced_system_prompt = f"{system_prompt}\n\nCharacter Backstory: {backstory}"
    else:
        enhanced_system_prompt = system_prompt
    
    # Prepare messages with system prompt
    messages = [
        {"role": "system", "content": enhanced_system_prompt}
    ]
    
    # Add history if provided
    if history:
        messages.extend(history)
    
    # Add the user's message
    messages.append({"role": "user", "content": user_message})
    
    try:
        # Get model settings from character customizations
        model_name = character.get("customizations", {}).get("modelName", "llama3.2")
        temperature = float(character.get("customizations", {}).get("temperature", 0.7))
        max_tokens = int(character.get("customizations", {}).get("maxTokens", 1000))
        
        print(f"\n{character_name} is typing...", end="")
        sys.stdout.flush()
        
        # Stream the response
        full_response = ""
        for chunk in client.chat(
            model=model_name,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True
        ):
            content = chunk["message"]["content"]
            print(content, end="")
            sys.stdout.flush()
            full_response += content
        
        print("\n")  # End with a newline
        return full_response
        
    except Exception as e:
        print(f"\nError communicating with Ollama: {e}")
        return f"I'm sorry, I encountered an error: {str(e)}"


def interactive_chat(character_name):
    """Start an interactive chat session with the character"""
    print(f"\nStarting chat with {character_name}...")
    print("Type 'exit' to quit, 'clear' to start a new conversation.")
    
    history = []
    character = get_character_by_name(character_name)
    if not character:
        print(f"Character '{character_name}' not found")
        return
    
    print(f"Character: {character['name']}")
    print(f"Description: {character['description']}")
    
    while True:
        user_input = input("\nYou: ")
        
        if user_input.lower() == "exit":
            break
        
        if user_input.lower() == "clear":
            history = []
            print("Conversation history cleared.")
            continue
        
        # Call Ollama with streaming
        response = stream_chat_with_ollama(character_name, user_input, history)
        
        # Add to history
        history.append({"role": "user", "content": user_input})
        history.append({"role": "assistant", "content": response})


def main():
    """Main function"""
    # Example of using the script
    print("Character.AI with Ollama Python Client")
    print("======================================\n")
    
    # Login is optional if you're only using direct Ollama communication
    # login("username", "password")
    
    # Get available characters
    print("Fetching available characters...")
    characters = get_characters()
    
    if not characters:
        print("No characters found or couldn't connect to server.")
        return
    
    print("\nAvailable characters:")
    for idx, character in enumerate(characters):
        print(f"{idx+1}. {character['name']} - {character['description']}")
    
    # Select a character
    selection = input("\nEnter character number to chat with: ")
    try:
        idx = int(selection) - 1
        if 0 <= idx < len(characters):
            character = characters[idx]
            interactive_chat(character["name"])
        else:
            print("Invalid selection.")
    except ValueError:
        # Try as a character name
        interactive_chat(selection)


if __name__ == "__main__":
    main()