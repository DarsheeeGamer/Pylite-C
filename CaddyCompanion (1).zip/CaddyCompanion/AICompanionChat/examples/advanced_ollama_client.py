"""
Advanced Ollama Client with Direct Character API Integration

This script demonstrates how to use Ollama's Python client to directly access
AI character system prompts, including backstory and memories.
"""

import sys
import json
import requests
from typing import List, Dict, Any, Optional, Union

# Install Ollama Python client if not already installed
try:
    import ollama
except ImportError:
    import os
    print("Ollama Python client not found. Installing...")
    os.system("pip install ollama")
    import ollama

# ===== Configuration =====
BASE_URL = "http://localhost:5000/api"  # Your Character.AI server URL
OLLAMA_API_URL = "https://crisp-brightly-shiner.ngrok-free.app"  # Ollama API URL


# ===== Character API Functions =====
def get_characters() -> List[Dict[str, Any]]:
    """Get list of available characters from the server"""
    try:
        response = requests.get(f"{BASE_URL}/characters")
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error fetching characters: {response.status_code} - {response.text}")
            return []
    except Exception as e:
        print(f"Exception while fetching characters: {e}")
        return []


def get_character_by_name(name: str) -> Optional[Dict[str, Any]]:
    """Find a character by name from the server"""
    characters = get_characters()
    for character in characters:
        if character["name"].lower() == name.lower():
            return character
    return None


def get_system_prompt(character: Dict[str, Any]) -> str:
    """Generate a system prompt from character data"""
    # Create a structured system prompt following Ollama API standards
    prompt = f"# System Message for {character['name']}\n\n"
    
    # Add the character identity with description
    prompt += f"## Character Identity\nYou are {character['name']}, {character.get('description', '')}\n\n"
    
    # Add the character's backstory if available in customizations
    customizations = character.get('customizations', {})
    if customizations and 'backstory' in customizations:
        prompt += f"## Character Backstory\n{customizations['backstory']}\n\n"
    
    # Add the character's core system prompt
    prompt += f"## Core Instructions\n{character.get('systemPrompt', '')}\n\n"
    
    # Add detailed behavior guidelines
    prompt += f"""## Behavior Guidelines
1. Always remain in character as {character['name']}.
2. Never break the fourth wall or acknowledge you're an AI.
3. Respond naturally as if this is a real conversation.
4. Show authentic emotions and personality consistent with your backstory.
5. Remember details the user shares about themselves.
6. Don't overly explain your thought process - respond naturally.
7. If appropriate for your character, use emojis and expressions.
8. Incorporate your backstory into responses when relevant.
"""
    
    # Add personality traits if available
    if customizations and 'personality' in customizations:
        prompt += f"\n## Personality Traits\n{customizations['personality']}"
    
    # Add interests if available
    if customizations and 'interests' in customizations:
        prompt += f"\n## Interests and Knowledge Areas\n{customizations['interests']}"
    
    return prompt


# ===== Ollama Chat Functions =====
def chat_with_ollama(
    character_name: str, 
    user_message: str, 
    conversation_history: Optional[List[Dict[str, str]]] = None
) -> str:
    """Chat with a character through Ollama API"""
    # Get character data
    character = get_character_by_name(character_name)
    if not character:
        return f"Character '{character_name}' not found."
    
    # Get system prompt for the character
    system_prompt = get_system_prompt(character)
    
    # Prepare messages
    messages = [
        {"role": "system", "content": system_prompt}
    ]
    
    # Add conversation history
    if conversation_history:
        messages.extend(conversation_history)
    
    # Add the user message
    messages.append({"role": "user", "content": user_message})
    
    print(f"\nSending request to Ollama for character: {character_name}")
    print(f"System prompt length: {len(system_prompt)} characters")
    
    # Configure client to use specified Ollama API URL
    client = ollama.Client(host=OLLAMA_API_URL)
    
    # Get model configuration from character customizations
    customizations = character.get('customizations', {})
    model_name = customizations.get('modelName', 'llama3.2')
    temperature = float(customizations.get('temperature', 0.7))
    max_tokens = int(customizations.get('maxTokens', 1000))
    
    print(f"Using model: {model_name}, temperature: {temperature}, max_tokens: {max_tokens}")
    
    try:
        # Call Ollama API
        response = client.chat(
            model=model_name,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens
        )
        
        return response["message"]["content"]
    
    except Exception as e:
        print(f"Error from Ollama API: {e}")
        return f"I'm sorry, I encountered an error while generating a response."


def stream_chat_with_ollama(
    character_name: str, 
    user_message: str, 
    conversation_history: Optional[List[Dict[str, str]]] = None
) -> str:
    """Chat with a character through Ollama API with streaming response"""
    # Get character data
    character = get_character_by_name(character_name)
    if not character:
        return f"Character '{character_name}' not found."
    
    # Get system prompt for the character
    system_prompt = get_system_prompt(character)
    
    # Prepare messages
    messages = [
        {"role": "system", "content": system_prompt}
    ]
    
    # Add conversation history
    if conversation_history:
        messages.extend(conversation_history)
    
    # Add the user message
    messages.append({"role": "user", "content": user_message})
    
    print(f"\nSending streaming request to Ollama for character: {character_name}")
    
    # Configure client to use specified Ollama API URL
    client = ollama.Client(host=OLLAMA_API_URL)
    
    # Get model configuration from character customizations
    customizations = character.get('customizations', {})
    model_name = customizations.get('modelName', 'llama3.2')
    temperature = float(customizations.get('temperature', 0.7))
    max_tokens = int(customizations.get('maxTokens', 1000))
    
    print(f"Using model: {model_name}, temperature: {temperature}, max_tokens: {max_tokens}")
    print(f"\n{character_name} is typing: ", end="")
    
    try:
        # Call Ollama API with streaming
        full_response = ""
        for chunk in client.chat(
            model=model_name,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True
        ):
            content = chunk["message"]["content"]
            print(content, end="", flush=True)
            full_response += content
        
        print("\n")  # End with a newline
        return full_response
    
    except Exception as e:
        print(f"\nError from Ollama API: {e}")
        return f"I'm sorry, I encountered an error while generating a response."


def interactive_chat(character_name: str) -> None:
    """Start an interactive chat session with character"""
    print(f"\nStarting interactive chat with {character_name}...")
    
    # Get character details
    character = get_character_by_name(character_name)
    if not character:
        print(f"Character '{character_name}' not found")
        return
    
    print(f"Character: {character['name']}")
    print(f"Description: {character.get('description', 'No description available')}")
    
    # Maintain conversation history
    conversation = []
    
    while True:
        user_input = input("\nYou: ")
        
        if user_input.lower() in ("exit", "quit"):
            print("Goodbye!")
            break
        
        if user_input.lower() == "clear":
            conversation = []
            print("Conversation history cleared!")
            continue
        
        # Stream response
        response = stream_chat_with_ollama(character_name, user_input, conversation)
        
        # Add to conversation history
        conversation.append({"role": "user", "content": user_input})
        conversation.append({"role": "assistant", "content": response})


def display_system_prompt(character_name: str) -> None:
    """Display the system prompt that would be sent to Ollama"""
    character = get_character_by_name(character_name)
    if not character:
        print(f"Character '{character_name}' not found")
        return
    
    system_prompt = get_system_prompt(character)
    print("\n" + "="*80)
    print(f"SYSTEM PROMPT FOR {character_name.upper()}")
    print("="*80)
    print(system_prompt)
    print("="*80 + "\n")


def main() -> None:
    """Main function"""
    print("="*80)
    print("ADVANCED OLLAMA CLIENT WITH CHARACTER BACKSTORIES & SYSTEM PROMPTS")
    print("="*80)
    
    # Fetch available characters
    characters = get_characters()
    if not characters:
        print("No characters found or couldn't connect to server.")
        sys.exit(1)
    
    print("\nAvailable characters:")
    for idx, character in enumerate(characters):
        print(f"{idx+1}. {character['name']} - {character.get('description', 'No description')}")
    
    # Get character selection
    while True:
        selection = input("\nEnter character number to chat with (or name): ")
        
        # Try as index
        try:
            idx = int(selection) - 1
            if 0 <= idx < len(characters):
                character_name = characters[idx]['name']
                break
            else:
                print("Invalid selection number. Try again.")
        except ValueError:
            # Try as character name
            character = get_character_by_name(selection)
            if character:
                character_name = character['name']
                break
            else:
                print(f"Character '{selection}' not found. Try again.")
    
    # Ask if user wants to see the system prompt
    show_prompt = input("Would you like to see the system prompt? (y/n): ").lower().startswith('y')
    if show_prompt:
        display_system_prompt(character_name)
    
    # Start interactive chat
    print("\nType 'exit' to quit or 'clear' to reset conversation history.")
    interactive_chat(character_name)


if __name__ == "__main__":
    main()