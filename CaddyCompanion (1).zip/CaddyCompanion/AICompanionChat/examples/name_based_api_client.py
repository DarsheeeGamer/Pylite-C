"""
Character.AI-style API Python Client with Name-Based Routing

This Python client demonstrates how to interact with the character-based API
using name-based routing ('/api/characters/:name') instead of ID-based routes.
"""

import sys
import json
import time
import requests
from typing import List, Dict, Any, Optional

# Configuration
BASE_URL = "http://localhost:5000/api"  # Your server URL
auth_token = None


def login(username: str, password: str) -> bool:
    """Log in to get auth token"""
    global auth_token
    
    try:
        response = requests.post(
            f"{BASE_URL}/login",
            json={"username": username, "password": password}
        )
        
        if response.status_code == 200:
            auth_data = response.json()
            auth_token = auth_data.get("token")
            print(f"Logged in successfully as {username}")
            return True
        else:
            print(f"Login failed: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        print(f"Error during login: {e}")
        return False


def get_headers() -> Dict[str, str]:
    """Get headers with auth token"""
    headers = {"Content-Type": "application/json"}
    if auth_token:
        headers["Authorization"] = f"Bearer {auth_token}"
    return headers


def get_characters() -> List[Dict[str, Any]]:
    """Get all available characters"""
    try:
        response = requests.get(
            f"{BASE_URL}/characters",
            headers=get_headers()
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error fetching characters: {response.status_code} - {response.text}")
            return []
    except Exception as e:
        print(f"Exception while fetching characters: {e}")
        return []


def get_character_by_name(name: str) -> Optional[Dict[str, Any]]:
    """Get a character by name"""
    try:
        # Using name-based routing
        response = requests.get(
            f"{BASE_URL}/characters/name/{name}",
            headers=get_headers()
        )
        
        if response.status_code == 200:
            return response.json()
        elif response.status_code == 404:
            print(f"Character '{name}' not found")
            return None
        else:
            print(f"Error fetching character: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"Exception while fetching character: {e}")
        return None


def send_message(character_name: str, message: str) -> Optional[Dict[str, Any]]:
    """Send a message to a character by name"""
    try:
        # Note that we're using the character_name in the URL directly
        response = requests.post(
            f"{BASE_URL}/AI/{character_name}/messages",
            headers=get_headers(),
            json={"content": message}
        )
        
        if response.status_code == 201:
            return response.json()
        else:
            print(f"Error sending message: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"Exception while sending message: {e}")
        return None


def get_messages(character_name: str) -> List[Dict[str, Any]]:
    """Get conversation history with a character by name"""
    try:
        # Using name-based routing for messages
        response = requests.get(
            f"{BASE_URL}/AI/{character_name}/messages",
            headers=get_headers()
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Error fetching messages: {response.status_code} - {response.text}")
            return []
    except Exception as e:
        print(f"Exception while fetching messages: {e}")
        return []


def chat_with_character(character_name: str, message: str, max_wait: int = 30) -> Optional[str]:
    """Send a message and wait for the response"""
    sent_message = send_message(character_name, message)
    if not sent_message:
        return None
    
    print(f"Message sent to {character_name}, waiting for response...")
    
    # Wait for response
    start_time = time.time()
    while time.time() - start_time < max_wait:
        messages = get_messages(character_name)
        
        # Sort messages by timestamp to get the most recent ones first
        messages.sort(key=lambda x: x.get("timestamp", 0), reverse=True)
        
        # Look for the most recent assistant message
        for msg in messages:
            if msg.get("role") == "assistant" and msg.get("timestamp", 0) > sent_message.get("timestamp", 0):
                return msg.get("content")
        
        # Wait a bit before trying again
        time.sleep(1)
    
    return "Timeout waiting for response"


def stream_response(character_name: str, message: str) -> None:
    """Use streaming API to get response in real-time"""
    try:
        # First, send the message
        sent_message = send_message(character_name, message)
        if not sent_message:
            print("Failed to send message")
            return
        
        # Now connect to streaming endpoint
        print(f"\n{character_name} is typing: ", end="", flush=True)
        
        response = requests.get(
            f"{BASE_URL}/AI/{character_name}/stream",
            headers=get_headers(),
            stream=True
        )
        
        if response.status_code != 200:
            print(f"\nError connecting to stream: {response.status_code} - {response.text}")
            return
        
        # Stream the response
        for line in response.iter_lines():
            if line:
                # SSE format is "data: {...}"
                line_str = line.decode('utf-8')
                if line_str.startswith('data:'):
                    data_json = line_str[5:].strip()
                    try:
                        data = json.loads(data_json)
                        
                        if data.get('type') == 'content_chunk':
                            # Content chunk - print it
                            chunk = data.get('chunk', '')
                            print(chunk, end="", flush=True)
                        
                        elif data.get('type') == 'typing_end':
                            # End of typing - break the stream
                            print("\n")
                            break
                        
                        elif data.get('type') == 'error':
                            # Error
                            print(f"\nError: {data.get('error')}")
                            break
                    except json.JSONDecodeError:
                        continue
    except Exception as e:
        print(f"\nError in streaming: {e}")


def main() -> None:
    """Main function to run the demo"""
    print("="*80)
    print("CHARACTER AI STYLE API CLIENT WITH NAME-BASED ROUTING")
    print("="*80)
    
    # Ask for login credentials if needed
    username = input("Username (or press Enter to skip login): ")
    if username:
        password = input("Password: ")
        if not login(username, password):
            print("Proceeding without authentication. Some features may be limited.")
    
    # Fetch available characters
    characters = get_characters()
    if not characters:
        print("No characters found or couldn't connect to server.")
        sys.exit(1)
    
    print("\nAvailable characters:")
    for idx, character in enumerate(characters):
        print(f"{idx+1}. {character['name']} - {character.get('description', 'No description')}")
    
    # Get character selection
    while True:
        selection = input("\nEnter character number to chat with (or name): ")
        
        # Try as index
        try:
            idx = int(selection) - 1
            if 0 <= idx < len(characters):
                character_name = characters[idx]['name']
                break
            else:
                print("Invalid selection number. Try again.")
        except ValueError:
            # Try as character name
            matching_characters = [c for c in characters if c["name"].lower() == selection.lower()]
            if matching_characters:
                character_name = matching_characters[0]['name']
                break
            else:
                print(f"Character '{selection}' not found. Try again.")
    
    print(f"\nStarting interactive chat with {character_name}...")
    print("Type 'exit' to quit, 'stream' to toggle streaming mode")
    
    # Begin chat loop
    streaming_mode = True  # Default to streaming mode
    
    while True:
        user_input = input("\nYou: ")
        
        if user_input.lower() in ("exit", "quit"):
            print("Goodbye!")
            break
        
        if user_input.lower() == "stream":
            streaming_mode = not streaming_mode
            print(f"Streaming mode: {'ON' if streaming_mode else 'OFF'}")
            continue
        
        if streaming_mode:
            stream_response(character_name, user_input)
        else:
            response = chat_with_character(character_name, user_input)
            if response:
                print(f"\n{character_name}: {response}")
            else:
                print("\nNo response received")


if __name__ == "__main__":
    main()