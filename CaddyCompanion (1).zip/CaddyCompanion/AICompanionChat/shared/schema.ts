import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(), // Hashed password
  displayName: text("display_name"),
  email: text("email").notNull().unique(),
  role: text("role").default("user"),
  profilePicture: text("profile_picture"),
  preferences: jsonb("preferences"),
  lastActive: timestamp("last_active"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Include password in the InsertUserSchema but not in the return type
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  email: true,
  role: true,
  profilePicture: true,
  preferences: true,
});

// Character schema
export const characters = pgTable("characters", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  systemPrompt: text("system_prompt").notNull(),
  imageUrl: text("image_url"),
  backgroundGradient: text("background_gradient"),
  tags: text("tags").array(),
  category: text("category"),
  isDefault: boolean("is_default").default(false),
  isPremium: boolean("is_premium").default(false),
  isVerified: boolean("is_verified").default(false),
  rating: text("rating"),
  messageCount: integer("message_count").default(0),
  creatorId: integer("creator_id").references(() => users.id),
  customizations: jsonb("customizations"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCharacterSchema = createInsertSchema(characters).pick({
  name: true,
  description: true,
  systemPrompt: true,
  imageUrl: true,
  backgroundGradient: true,
  tags: true,
  category: true,
  isDefault: true,
  isPremium: true,
  isVerified: true,
  rating: true,
  messageCount: true,
  creatorId: true,
  customizations: true,
  createdAt: true,
  updatedAt: true,
});

// Conversation schema
export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  characterId: integer("character_id").references(() => characters.id),
  title: text("title").default("New Conversation"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  userId: true,
  characterId: true,
  title: true,
});

// Message schema
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").references(() => conversations.id),
  content: text("content").notNull(),
  role: text("role").notNull(), // 'user' or 'assistant'
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  conversationId: true,
  content: true,
  role: true,
});

// Memory schema
export const memories = pgTable("memories", {
  id: serial("id").primaryKey(),
  characterId: integer("character_id").references(() => characters.id),
  userId: integer("user_id").references(() => users.id),
  content: text("content").notNull(),
  embedding: text("embedding"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMemorySchema = createInsertSchema(memories).pick({
  characterId: true,
  userId: true,
  content: true,
  embedding: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Character Customizations Type
export interface CharacterCustomizations {
  communicationStyle?: string;
  responseLength?: string;
  temperature?: string | number;
  typingSpeed?: string | number;
  personality?: string;
  interests?: string;
  backstory?: string;
  [key: string]: any; // Allow other customization properties
}

export type Character = Omit<typeof characters.$inferSelect, 'customizations'> & {
  customizations?: CharacterCustomizations;
};
export type InsertCharacter = z.infer<typeof insertCharacterSchema>;

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

export type Memory = typeof memories.$inferSelect;
export type InsertMemory = z.infer<typeof insertMemorySchema>;
