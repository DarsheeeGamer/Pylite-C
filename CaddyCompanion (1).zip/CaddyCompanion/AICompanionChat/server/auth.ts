import { Express, Request, Response, NextFunction } from "express";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { storage } from "./storage";
import { User, InsertUser } from "@shared/schema";
import * as bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import session from "express-session";

declare global {
  namespace Express {
    // Extend Express.User with our User type without circular reference
    interface User {
      id: number;
      username: string;
      password?: string;
      displayName?: string;
      email: string;
      role?: string;
      profilePicture?: string;
      preferences?: any;
      lastActive?: Date;
      createdAt?: Date;
      updatedAt?: Date;
    }
  }
}

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const JWT_EXPIRY = "7d"; // Token expiry time

// Create authentication middleware
export function setupAuth(app: Express) {
  // Configure session
  app.use(session({
    secret: process.env.SESSION_SECRET || "session-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 7 // 1 week
    }
  }));

  // Initialize Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure Passport Local Strategy for username/password auth
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // Get user from storage
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username or password" });
        }

        // Verify password directly from DB
        const isValid = await bcrypt.compare(password, user.password as string);
        if (!isValid) {
          return done(null, false, { message: "Incorrect username or password" });
        }

        // Update last active in database
        try {
          await storage.updateUserLastActive(user.id, new Date());
        } catch (err) {
          // Just log the error but continue authentication
          console.error("Failed to update last active timestamp:", err);
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );

  // Serialize and deserialize user
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Generate JWT token
  const generateToken = (user: User): string => {
    return jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRY }
    );
  };

  // Authentication routes
  app.post("/api/register", async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create user
      const user = await storage.createUser(req.body as InsertUser);

      // Generate token
      const token = generateToken(user);

      // Login user
      req.login(user, (err) => {
        if (err) return next(err);
        
        // Return user info and token
        return res.status(201).json({
          message: "User registered successfully",
          user: {
            id: user.id,
            username: user.username,
            displayName: user.displayName,
            email: user.email,
            role: user.role
          },
          token
        });
      });
    } catch (error) {
      return res.status(500).json({ message: "Error registering user", error: error.message });
    }
  });

  app.post("/api/login", (req: Request, res: Response, next: NextFunction) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ message: info?.message || "Authentication failed" });

      req.login(user, (err) => {
        if (err) return next(err);

        // Generate token
        const token = generateToken(user);

        return res.json({
          message: "Login successful",
          user: {
            id: user.id,
            username: user.username,
            displayName: user.displayName,
            email: user.email,
            role: user.role
          },
          token
        });
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req: Request, res: Response) => {
    req.logout((err) => {
      if (err) return res.status(500).json({ message: "Error logging out" });
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/user", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = req.user as User;
    return res.json({
      id: user.id,
      username: user.username,
      displayName: user.displayName,
      email: user.email,
      role: user.role
    });
  });

  // JWT Verification middleware
  const verifyJWT = (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.split(" ")[1]; // Extract token from "Bearer TOKEN"
    if (!token) {
      return res.status(401).json({ message: "Invalid token format" });
    }

    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded as Express.User;
      next();
    } catch (error) {
      return res.status(401).json({ message: "Invalid token" });
    }
  };

  // Role-based auth middleware
  const requireRole = (role: string) => {
    return (req: Request, res: Response, next: NextFunction) => {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      if ((req.user as User).role !== role) {
        return res.status(403).json({ message: "Access denied" });
      }

      next();
    };
  };

  return {
    verifyJWT,
    requireRole
  };
}