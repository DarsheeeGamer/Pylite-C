import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./custom-storage";
// Use hybrid storage instead of PostgreSQL
import { z } from "zod";
import { 
  insertUserSchema, 
  insertCharacterSchema, 
  insertConversationSchema, 
  insertMessageSchema,
  User
} from "@shared/schema";
import { chatWithCharacter, generateStreamResponse } from "./services/ollama";
import { storeMemory, getRelevantMemories } from "./services/memory";
import { setupAuth } from "./auth";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import cookieParser from "cookie-parser";

export async function registerRoutes(app: Express): Promise<Server> {
  // Security middleware
  app.use(helmet({
    contentSecurityPolicy: process.env.NODE_ENV === "production" ? undefined : false
  }));
  
  // Rate limiting
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per window
    standardHeaders: true,
    legacyHeaders: false,
    message: "Too many requests from this IP, please try again later"
  });
  app.use("/api/", apiLimiter);
  
  // Cookie parser
  app.use(cookieParser());
  
  // Setup authentication
  const { verifyJWT, requireRole } = setupAuth(app);
  
  // User profile routes
  app.patch("/api/user/profile", verifyJWT, async (req: Request, res: Response) => {
    try {
      const userId = req.user?.id;
      if (!userId) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      // Only allow specific fields to be updated
      const updateData: Partial<User> = {};
      
      // Type-safe way to handle allowed fields
      if (req.body.displayName !== undefined) updateData.displayName = req.body.displayName;
      if (req.body.email !== undefined) updateData.email = req.body.email;
      if (req.body.profilePicture !== undefined) updateData.profilePicture = req.body.profilePicture;
      if (req.body.preferences !== undefined) updateData.preferences = req.body.preferences;
      
      const updatedUser = await storage.updateUser(userId, updateData);
      
      // Create a new object without password for the response
      const userForResponse = { ...updatedUser };
      if ('password' in userForResponse) {
        // @ts-ignore: Intentionally removing password from response
        delete userForResponse.password;
      }
      
      res.json(userForResponse);
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      res.status(500).json({ 
        message: "Error updating user profile", 
        error: errorMessage 
      });
    }
  });
  // Characters routes
  app.get("/api/characters", async (req, res) => {
    try {
      const category = req.query.category ? req.query.category.toString() : undefined;
      const sortBy = req.query.sortBy ? req.query.sortBy.toString() : undefined;
      const search = req.query.search ? req.query.search.toString() : undefined;
      const premium = req.query.premium === 'true';
      
      let characters = await storage.getAllCharacters();
      
      // Apply filters if provided
      if (category && category !== 'all') {
        characters = characters.filter(char => char.category === category);
      }
      
      if (search) {
        const searchLower = search.toLowerCase();
        characters = characters.filter(
          char => char.name.toLowerCase().includes(searchLower) || 
                 char.description.toLowerCase().includes(searchLower)
        );
      }
      
      if (premium) {
        characters = characters.filter(char => char.isPremium);
      }
      
      // Apply sorting
      if (sortBy) {
        switch (sortBy) {
          case 'newest':
            characters.sort((a, b) => {
              const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
              const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
              return dateB - dateA;
            });
            break;
          case 'oldest':
            characters.sort((a, b) => {
              const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
              const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
              return dateA - dateB;
            });
            break;
          case 'popular':
            characters.sort((a, b) => (b.messageCount || 0) - (a.messageCount || 0));
            break;
          case 'alphabetical':
            characters.sort((a, b) => a.name.localeCompare(b.name));
            break;
        }
      }
      
      res.json(characters);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch characters" });
    }
  });

  app.get("/api/characters/:id", async (req, res) => {
    try {
      const characterId = parseInt(req.params.id);
      const character = await storage.getCharacter(characterId);
      
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      
      res.json(character);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch character" });
    }
  });

  app.post("/api/characters", async (req, res) => {
    try {
      const parsedData = insertCharacterSchema.parse(req.body);
      const character = await storage.createCharacter(parsedData);
      res.status(201).json(character);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid character data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create character" });
    }
  });

  app.patch("/api/characters/:id/customizations", async (req, res) => {
    try {
      const characterId = parseInt(req.params.id);
      const customizations = req.body;
      
      const character = await storage.getCharacter(characterId);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      
      const updatedCharacter = await storage.updateCharacterCustomizations(characterId, customizations);
      res.json(updatedCharacter);
    } catch (error) {
      res.status(500).json({ message: "Failed to update character customizations" });
    }
  });

  // Add endpoint to increment a character's message count
  app.patch("/api/characters/:id/message-count", verifyJWT, async (req: Request, res: Response) => {
    try {
      const characterId = parseInt(req.params.id);
      
      const character = await storage.getCharacter(characterId);
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      
      // Increment message count
      const currentCount = character.messageCount || 0;
      const updatedCharacter = await storage.updateCharacterCustomizations(
        characterId, 
        { ...character.customizations, messageCount: currentCount + 1 }
      );
      
      res.json({ success: true, messageCount: currentCount + 1 });
    } catch (error) {
      res.status(500).json({ message: "Failed to update character message count" });
    }
  });

  // Conversations routes
  app.get("/api/conversations", verifyJWT, async (req: Request, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      const userId = req.user.id;
      const conversations = await storage.getConversationsByUserId(userId);
      res.json(conversations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch conversations" });
    }
  });

  app.post("/api/conversations", verifyJWT, async (req: Request, res: Response) => {
    try {
      const { characterId, character: characterName, title } = req.body;
      
      if (!characterId && !characterName) {
        return res.status(400).json({ message: "Either character ID or name is required" });
      }
      
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      const userId = req.user.id;
      
      // Get character by ID or name
      let character;
      if (characterId) {
        character = await storage.getCharacter(characterId);
      } else if (characterName) {
        character = await storage.getCharacterByName(characterName);
      }
      
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      
      // Check if a conversation already exists
      const existingConversation = await storage.getConversationByUserAndCharacter(userId, character.id);
      if (existingConversation) {
        return res.status(200).json({
          ...existingConversation,
          message: "Conversation already exists"
        });
      }
      
      const conversationData = {
        userId,
        characterId: character.id,
        title: title || `Conversation with ${character.name}`
      };
      
      // Create the conversation
      try {
        const conversation = await storage.createConversation(conversationData);
        console.log(`[API] Created conversation with ${character.name} (ID: ${character.id}) for user ${userId}`);
        res.status(201).json(conversation);
      } catch (validationError) {
        console.error("[API] Validation error:", validationError);
        res.status(400).json({ message: "Invalid conversation data", error: validationError });
      }
    } catch (error) {
      console.error("[API] Error creating conversation:", error);
      res.status(500).json({ message: "Failed to create conversation" });
    }
  });

  // Messages routes - Support for both ID and name-based character access
  app.get("/api/messages", verifyJWT, async (req: Request, res: Response) => {
    try {
      let character;
      const characterId = req.query.characterId ? parseInt(req.query.characterId as string) : undefined;
      const characterName = req.query.character ? req.query.character as string : undefined;
      
      // Get character by ID or name
      if (characterId) {
        character = await storage.getCharacter(characterId);
      } else if (characterName) {
        character = await storage.getCharacterByName(characterName);
      }
      
      if (!character) {
        return res.status(400).json({ message: "Character not found. Provide either character ID or name." });
      }
      
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      const userId = req.user.id;
      
      // First, find or create a conversation for this user and character
      let conversation = await storage.getConversationByUserAndCharacter(userId, character.id);
      
      if (!conversation) {
        conversation = await storage.createConversation({
          userId,
          characterId: character.id,
          title: `Conversation with ${character.name}`
        });
      }
      
      const messages = await storage.getMessagesByConversationId(conversation.id);
      res.json(messages);
    } catch (error) {
      console.error("[API] Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/messages", verifyJWT, async (req: Request, res: Response) => {
    try {
      const { characterId, character: characterName, content } = req.body;
      
      if ((!characterId && !characterName) || !content) {
        return res.status(400).json({ message: "Either character ID or name, and content are required" });
      }
      
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      const userId = req.user.id;
      
      // Get character by ID or name
      let character;
      if (characterId) {
        character = await storage.getCharacter(characterId);
      } else if (characterName) {
        character = await storage.getCharacterByName(characterName);
      }
      
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      
      // Find or create a conversation
      let conversation = await storage.getConversationByUserAndCharacter(userId, character.id);
      
      if (!conversation) {
        conversation = await storage.createConversation({
          userId,
          characterId: character.id,
          title: `Conversation with ${character.name}`
        });
      }
      
      // Save user message
      const userMessage = await storage.createMessage({
        conversationId: conversation.id,
        content,
        role: "user"
      });
      
      // Get conversation history
      const messages = await storage.getMessagesByConversationId(conversation.id);
      
      // Get relevant memories
      const memories = await getRelevantMemories(character.id, userId, content);
      
      // Log which character is being used
      console.log(`[API] Sending message to ${character.name} (ID: ${character.id})`);
      
      // Generate AI response (but don't wait for it)
      chatWithCharacter(character, messages, memories, content)
        .then(async (aiResponse) => {
          // Save AI message
          await storage.createMessage({
            conversationId: conversation.id,
            content: aiResponse,
            role: "assistant"
          });
          
          // Store memory of this interaction
          await storeMemory(character.id, userId, `User: ${content}\n${character.name}: ${aiResponse}`);
          
          // Increment message count
          try {
            const currentCount = character.messageCount || 0;
            await storage.updateCharacterCustomizations(
              character.id,
              { ...character.customizations, messageCount: currentCount + 1 }
            );
          } catch (error) {
            console.error("Error updating message count:", error);
          }
        })
        .catch((error) => {
          console.error("Error generating AI response:", error);
        });
      
      res.status(202).json({ success: true, message: "Message received and processing" });
    } catch (error) {
      console.error("[API] Error processing message:", error);
      res.status(500).json({ message: "Failed to process message" });
    }
  });

  // Streaming endpoint - Support for both ID and name-based character access
  app.get("/api/stream", verifyJWT, async (req: Request, res: Response) => {
    try {
      let character;
      const characterId = req.query.characterId ? parseInt(req.query.characterId as string) : undefined;
      const characterName = req.query.character ? req.query.character as string : undefined;
      
      // Validate we have a way to identify the character
      if (!characterId && !characterName) {
        return res.status(400).json({ message: "Either character ID or character name is required" });
      }
      
      if (!req.user) {
        return res.status(401).json({ message: "User not authenticated" });
      }
      
      // Get character by ID or name
      if (characterId) {
        character = await storage.getCharacter(characterId);
      } else if (characterName) {
        character = await storage.getCharacterByName(characterName);
      }
      
      if (!character) {
        return res.status(404).json({ message: "Character not found" });
      }
      
      // Log model assignment for debugging purposes
      console.log(`[API] Streaming connection established for ${character.name} (ID: ${character.id})`);
      console.log(`[API] Character customizations: ${JSON.stringify(character.customizations || {})}`);
      
      // Set up SSE
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      
      // Create a unique client ID
      const clientId = Date.now();
      
      // Add this client to the clients map in the generateStreamResponse function
      const cleanup = generateStreamResponse(clientId, res);
      
      // Handle client disconnect
      req.on("close", () => {
        cleanup();
      });
    } catch (error) {
      console.error("[API] Error in streaming endpoint:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
