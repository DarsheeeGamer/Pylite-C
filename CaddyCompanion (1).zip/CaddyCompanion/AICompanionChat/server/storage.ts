import { 
  User, 
  InsertUser, 
  Character, 
  InsertCharacter, 
  Conversation, 
  InsertConversation, 
  Message, 
  InsertMessage, 
  Memory, 
  InsertMemory,
  users,
  characters,
  conversations,
  messages,
  memories
} from "@shared/schema";
import { DEFAULT_CHARACTERS } from "../client/src/lib/constants";
import { drizzle } from "drizzle-orm/node-postgres";
import { eq, and, sql } from "drizzle-orm";
import pg from "pg";
import * as bcrypt from "bcrypt";
import session from "express-session";
import createMemoryStore from "memorystore";

const { Pool } = pg;

// PostgreSQL connection setup
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// Initialize Drizzle ORM
const db = drizzle(pool);

// Memory store for sessions (simpler for development)
const MemoryStore = createMemoryStore(session);

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // Session management
  sessionStore: session.Store;
  
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLastActive(id: number, date: Date): Promise<void>;
  updateUser(id: number, userData: Partial<User>): Promise<User>; // New method for updating user profiles
  
  // Characters
  getAllCharacters(): Promise<Character[]>;
  getCharacter(id: number): Promise<Character | undefined>;
  getCharacterByName(name: string): Promise<Character | undefined>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacterCustomizations(id: number, customizations: any): Promise<Character>;
  
  // Conversations
  getConversationsByUserId(userId: number): Promise<Conversation[]>;
  getConversationByUserAndCharacter(userId: number, characterId: number): Promise<Conversation | undefined>;
  getConversation(id: number): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  
  // Messages
  getMessagesByConversationId(conversationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Memories
  getMemoriesByCharacterAndUser(characterId: number, userId: number): Promise<Memory[]>;
  createMemory(memory: InsertMemory): Promise<Memory>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private characters: Map<number, Character>;
  private conversations: Map<number, Conversation>;
  private messages: Map<number, Message>;
  private memories: Map<number, Memory>;
  
  sessionStore: session.Store;
  currentUserId: number;
  currentCharacterId: number;
  currentConversationId: number;
  currentMessageId: number;
  currentMemoryId: number;

  constructor() {
    this.users = new Map();
    this.characters = new Map();
    this.conversations = new Map();
    this.messages = new Map();
    this.memories = new Map();
    
    // Set up memory session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });
    
    this.currentUserId = 1;
    this.currentCharacterId = 5; // Start after default characters
    this.currentConversationId = 1;
    this.currentMessageId = 1;
    this.currentMemoryId = 1;
    
    // Initialize with default characters
    DEFAULT_CHARACTERS.forEach(character => {
      this.characters.set(character.id, character);
    });
    
    // Create a default user
    this.users.set(1, {
      id: 1,
      username: "user",
      password: "password",
      displayName: "Default User",
      createdAt: new Date().toISOString()
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser,
      id,
      createdAt: new Date().toISOString()
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserLastActive(id: number, date: Date): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      user.lastActive = date;
      this.users.set(id, user);
    }
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    // Update user data
    const updatedUser = {
      ...user,
      ...userData,
      updatedAt: new Date().toISOString()
    };
    
    // Save to storage
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Character methods
  async getAllCharacters(): Promise<Character[]> {
    return Array.from(this.characters.values());
  }
  
  async getCharacter(id: number): Promise<Character | undefined> {
    return this.characters.get(id);
  }
  
  async getCharacterByName(name: string): Promise<Character | undefined> {
    // Case-insensitive search for character by name
    return Array.from(this.characters.values()).find(
      (character) => character.name.toLowerCase() === name.toLowerCase()
    );
  }
  
  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const id = this.currentCharacterId++;
    const character: Character = {
      ...insertCharacter,
      id
    };
    this.characters.set(id, character);
    return character;
  }
  
  async updateCharacterCustomizations(id: number, customizations: any): Promise<Character> {
    const character = this.characters.get(id);
    
    if (!character) {
      throw new Error("Character not found");
    }
    
    const updatedCharacter: Character = {
      ...character,
      customizations: {
        ...character.customizations,
        ...customizations
      }
    };
    
    this.characters.set(id, updatedCharacter);
    return updatedCharacter;
  }
  
  // Conversation methods
  async getConversationsByUserId(userId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      (conversation) => conversation.userId === userId
    );
  }
  
  async getConversationByUserAndCharacter(
    userId: number,
    characterId: number
  ): Promise<Conversation | undefined> {
    return Array.from(this.conversations.values()).find(
      (conversation) => 
        conversation.userId === userId && 
        conversation.characterId === characterId
    );
  }
  
  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }
  
  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = this.currentConversationId++;
    const now = new Date().toISOString();
    
    const conversation: Conversation = {
      ...insertConversation,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.conversations.set(id, conversation);
    return conversation;
  }
  
  // Message methods
  async getMessagesByConversationId(conversationId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((message) => message.conversationId === conversationId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }
  
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    
    const message: Message = {
      ...insertMessage,
      id,
      timestamp: new Date().toISOString()
    };
    
    this.messages.set(id, message);
    
    // Update conversation's updatedAt timestamp
    const conversation = this.conversations.get(insertMessage.conversationId);
    if (conversation) {
      conversation.updatedAt = new Date().toISOString();
      this.conversations.set(conversation.id, conversation);
    }
    
    return message;
  }
  
  // Memory methods
  async getMemoriesByCharacterAndUser(characterId: number, userId: number): Promise<Memory[]> {
    return Array.from(this.memories.values()).filter(
      (memory) => memory.characterId === characterId && memory.userId === userId
    );
  }
  
  async createMemory(insertMemory: InsertMemory): Promise<Memory> {
    const id = this.currentMemoryId++;
    
    const memory: Memory = {
      ...insertMemory,
      id,
      createdAt: new Date().toISOString()
    };
    
    this.memories.set(id, memory);
    return memory;
  }
}

// Use a dynamic import for connect-pg-simple in ESM
import connectPgSimple from 'connect-pg-simple';

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  // Session store for authentication
  sessionStore: session.Store;

  constructor() {
    // Set up PostgreSQL session store
    const PostgresStore = connectPgSimple(session);
    this.sessionStore = new PostgresStore({
      pool: pool,
      tableName: 'session',
      createTableIfMissing: true
    });
    
    // Initialize database with default characters if needed
    this.initDefaultCharacters();
  }

  private async initDefaultCharacters() {
    try {
      // Check if characters exist
      const existingCharacters = await db.select().from(characters);
      
      if (existingCharacters.length === 0) {
        // Insert default characters
        const now = new Date();
        for (const character of DEFAULT_CHARACTERS) {
          await db.insert(characters).values({
            id: character.id,
            name: character.name,
            description: character.description,
            systemPrompt: character.systemPrompt,
            imageUrl: character.imageUrl,
            backgroundGradient: character.backgroundGradient,
            tags: character.tags,
            category: character.category,
            isDefault: true,
            isPremium: false, // Default characters are not premium
            customizations: character.customizations,
            createdAt: now,
            updatedAt: now
          });
        }
        console.log("Default characters initialized");
      }
    } catch (error) {
      console.error("Error initializing default characters:", error);
    }
  }

  // User related methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Hash the password before storing
    const password = insertUser.password;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const now = new Date();
    
    // Update the insertUser object with the hashed password and timestamps
    const userToInsert = {
      ...insertUser,
      password: hashedPassword,
      createdAt: now,
      updatedAt: now
    };
    
    // Insert user with hashed password into PostgreSQL
    const [user] = await db.insert(users).values(userToInsert).returning();
    
    return user;
  }
  
  async updateUserLastActive(id: number, date: Date): Promise<void> {
    await db
      .update(users)
      .set({ lastActive: date })
      .where(eq(users.id, id));
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    // Get existing user
    const existingUser = await this.getUser(id);
    if (!existingUser) {
      throw new Error("User not found");
    }
    
    // Update the user with new data
    const now = new Date();
    const [updatedUser] = await db
      .update(users)
      .set({ 
        ...userData,
        updatedAt: now
      })
      .where(eq(users.id, id))
      .returning();
      
    return updatedUser;
  }

  // Character methods
  async getAllCharacters(): Promise<Character[]> {
    return db.select().from(characters);
  }
  
  async getCharacter(id: number): Promise<Character | undefined> {
    const result = await db.select().from(characters).where(eq(characters.id, id));
    return result[0];
  }
  
  async getCharacterByName(name: string): Promise<Character | undefined> {
    // SQL 'ILIKE' for case-insensitive search in PostgreSQL
    const result = await db.select().from(characters).where(
      sql`LOWER(${characters.name}) = LOWER(${name})`
    );
    return result[0];
  }
  
  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const now = new Date();
    const characterToInsert = {
      ...insertCharacter,
      createdAt: now,
      updatedAt: now
    };
    const [character] = await db.insert(characters).values(characterToInsert).returning();
    return character;
  }
  
  async updateCharacterCustomizations(id: number, customizations: any): Promise<Character> {
    // Get existing character
    const existingCharacter = await this.getCharacter(id);
    if (!existingCharacter) {
      throw new Error("Character not found");
    }
    
    // Merge customizations
    const updatedCustomizations = {
      ...existingCharacter.customizations,
      ...customizations
    };
    
    // Update the character
    const [updatedCharacter] = await db
      .update(characters)
      .set({ customizations: updatedCustomizations })
      .where(eq(characters.id, id))
      .returning();
      
    return updatedCharacter;
  }
  
  // Conversation methods
  async getConversationsByUserId(userId: number): Promise<Conversation[]> {
    return db.select().from(conversations).where(eq(conversations.userId, userId));
  }
  
  async getConversationByUserAndCharacter(userId: number, characterId: number): Promise<Conversation | undefined> {
    const result = await db
      .select()
      .from(conversations)
      .where(
        and(
          eq(conversations.userId, userId),
          eq(conversations.characterId, characterId)
        )
      );
    return result[0];
  }
  
  async getConversation(id: number): Promise<Conversation | undefined> {
    const result = await db.select().from(conversations).where(eq(conversations.id, id));
    return result[0];
  }
  
  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const now = new Date();
    const conversationToInsert = {
      ...insertConversation,
      createdAt: now,
      updatedAt: now
    };
    const [conversation] = await db.insert(conversations).values(conversationToInsert).returning();
    return conversation;
  }
  
  // Message methods
  async getMessagesByConversationId(conversationId: number): Promise<Message[]> {
    return db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, conversationId))
      .orderBy(messages.timestamp);
  }
  
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(insertMessage).returning();
    
    // Update conversation's updatedAt timestamp
    await db
      .update(conversations)
      .set({ updatedAt: new Date() })
      .where(eq(conversations.id, insertMessage.conversationId));
      
    return message;
  }
  
  // Memory methods
  async getMemoriesByCharacterAndUser(characterId: number, userId: number): Promise<Memory[]> {
    return db
      .select()
      .from(memories)
      .where(
        and(
          eq(memories.characterId, characterId),
          eq(memories.userId, userId)
        )
      );
  }
  
  async createMemory(insertMemory: InsertMemory): Promise<Memory> {
    const now = new Date();
    const memoryToInsert = {
      ...insertMemory,
      createdAt: now
    };
    const [memory] = await db.insert(memories).values(memoryToInsert).returning();
    return memory;
  }
}

// Export database storage instance
export const storage = new DatabaseStorage();
