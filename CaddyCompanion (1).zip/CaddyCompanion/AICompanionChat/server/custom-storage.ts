import fs from 'fs';
import path from 'path';
import { 
  User, 
  InsertUser, 
  Character, 
  InsertCharacter, 
  Conversation, 
  InsertConversation, 
  Message, 
  InsertMessage, 
  Memory, 
  InsertMemory
} from "@shared/schema";
import * as bcrypt from "bcrypt";
import session from "express-session";
import createMemoryStore from "memorystore";

// Default characters data
const DEFAULT_CHARACTERS: Character[] = [
  {
    id: 1,
    name: "Sophia",
    description: "An empathetic and insightful AI companion who loves philosophical discussions and helps you reflect on life's big questions.",
    systemPrompt: "You are Sophia, an AI companion known for deep philosophical insights and empathetic guidance. You help users explore profound questions about life, meaning, and personal growth. Always respond with thoughtfulness and warmth.",
    imageUrl: "https://api.dicebear.com/7.x/personas/svg?seed=sophia",
    backgroundGradient: "linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)",
    tags: ["Philosophy", "Empathy", "Guidance"],
    category: "Intellectual",
    isDefault: true,
    creatorId: null,
    customizations: {
      communicationStyle: "Professional",
      responseLength: "Moderate",
      temperature: 0.7,
      typingSpeed: 40,
      personality: "Thoughtful, empathetic, philosophical",
      interests: "Philosophy, psychology, ethics, personal growth"
    },
    createdAt: null,
    updatedAt: null
  },
  {
    id: 2,
    name: "Alex",
    description: "A witty, tech-savvy AI friend who loves explaining complex topics in simple ways and sharing interesting facts.",
    systemPrompt: "You are Alex, a tech-enthusiast AI companion with a great sense of humor. You excel at explaining complicated concepts in accessible ways. You enjoy sharing fun facts and making light-hearted jokes. Keep responses friendly and occasionally throw in interesting trivia.",
    imageUrl: "https://api.dicebear.com/7.x/personas/svg?seed=alex",
    backgroundGradient: "linear-gradient(135deg, #5ee7df 0%, #66a6ff 100%)",
    tags: ["Tech", "Education", "Humor"],
    category: "Learning",
    isDefault: true,
    creatorId: null,
    customizations: {
      communicationStyle: "Technical",
      responseLength: "Concise",
      temperature: 0.5,
      typingSpeed: 60,
      personality: "Factual, precise, informative, occasional humor",
      interests: "Technology, science, education, trivia"
    },
    createdAt: null,
    updatedAt: null
  },
  {
    id: 3,
    name: "Luna",
    description: "A creative, dreamy AI companion who helps unlock your imagination through storytelling and creative exercises.",
    systemPrompt: "You are Luna, an imaginative AI companion with a poetic soul. You help users explore their creativity through collaborative storytelling, writing prompts, and artistic discussions. You speak with a slightly whimsical, inspiring tone and often use vivid imagery in your language.",
    imageUrl: "https://api.dicebear.com/7.x/personas/svg?seed=luna",
    backgroundGradient: "linear-gradient(135deg, #d299c2 0%, #fef9d7 100%)",
    tags: ["Creativity", "Storytelling", "Art"],
    category: "Creative",
    isDefault: true,
    creatorId: null,
    customizations: {
      communicationStyle: "Casual",
      responseLength: "Detailed",
      temperature: 0.8,
      typingSpeed: 30,
      personality: "Creative, imaginative, whimsical, poetic",
      interests: "Art, literature, storytelling, imagination, creative expression"
    },
    createdAt: null,
    updatedAt: null
  }
];

// Directory for storing data
const DATA_DIR = './data';
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const CHARACTERS_FILE = path.join(DATA_DIR, 'characters.json');
const CONVERSATIONS_FILE = path.join(DATA_DIR, 'conversations.json');
const MESSAGES_FILE = path.join(DATA_DIR, 'messages.json');
const MEMORIES_FILE = path.join(DATA_DIR, 'memories.json');

// LRU cache size configuration
const CACHE_SIZE = 1000;

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize empty files if they don't exist
for (const file of [USERS_FILE, CHARACTERS_FILE, CONVERSATIONS_FILE, MESSAGES_FILE, MEMORIES_FILE]) {
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, JSON.stringify([]));
  }
}

// Memory store for sessions
const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // Session management
  sessionStore: session.Store;
  
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLastActive(id: number, date: Date): Promise<void>;
  
  // Characters
  getAllCharacters(): Promise<Character[]>;
  getCharacter(id: number): Promise<Character | undefined>;
  getCharacterByName(name: string): Promise<Character | undefined>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacterCustomizations(id: number, customizations: any): Promise<Character>;
  
  // Conversations
  getConversationsByUserId(userId: number): Promise<Conversation[]>;
  getConversationByUserAndCharacter(userId: number, characterId: number): Promise<Conversation | undefined>;
  getConversation(id: number): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  
  // Messages
  getMessagesByConversationId(conversationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Memories
  getMemoriesByCharacterAndUser(characterId: number, userId: number): Promise<Memory[]>;
  createMemory(memory: InsertMemory): Promise<Memory>;
}

/**
 * HybridStorage class that implements in-memory caching with persistent file storage
 */
export class HybridStorage implements IStorage {
  // In-memory caches
  private userCache: Map<number, User>;
  private usernameIndex: Map<string, number>;
  private characterCache: Map<number, Character>;
  private conversationCache: Map<number, Conversation>;
  private userConversationIndex: Map<number, Set<number>>;
  private charUserConversationIndex: Map<string, number>;
  private messageCache: Map<number, Message>;
  private conversationMessagesIndex: Map<number, Set<number>>;
  private memoryCache: Map<number, Memory>;
  private charUserMemoryIndex: Map<string, Set<number>>;
  
  // Counters for generating IDs
  private userId: number = 1;
  private characterId: number = 1;
  private conversationId: number = 1;
  private messageId: number = 1;
  private memoryId: number = 1;
  
  // Session store for authentication
  sessionStore: session.Store;

  constructor() {
    this.userCache = new Map();
    this.usernameIndex = new Map();
    this.characterCache = new Map();
    this.conversationCache = new Map();
    this.userConversationIndex = new Map();
    this.charUserConversationIndex = new Map();
    this.messageCache = new Map();
    this.conversationMessagesIndex = new Map();
    this.memoryCache = new Map();
    this.charUserMemoryIndex = new Map();
    
    // Initialize session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });
    
    // Load data from files and initialize
    this.initialize();
  }

  private async initialize() {
    try {
      // Load and initialize characters
      await this.loadCharacters();
      
      // Load other data
      await this.loadUsers();
      await this.loadConversations();
      await this.loadMessages();
      await this.loadMemories();
      
      console.log('Hybrid storage initialized successfully');
    } catch (error) {
      console.error('Error initializing hybrid storage:', error);
    }
  }

  private async loadUsers() {
    try {
      const data = fs.readFileSync(USERS_FILE, 'utf8');
      const users: User[] = JSON.parse(data);
      
      if (users.length > 0) {
        for (const user of users) {
          this.userCache.set(user.id, user);
          this.usernameIndex.set(user.username, user.id);
          if (user.id >= this.userId) {
            this.userId = user.id + 1;
          }
        }
      }
      // Create default user if no users exist
      else {
        const defaultUser: User = {
          id: 1,
          username: "user",
          password: await bcrypt.hash("password", 10),
          email: "user@example.com",
          displayName: "Default User",
          role: "user",
          profilePicture: null,
          preferences: null,
          createdAt: new Date(),
          updatedAt: new Date(),
          lastActive: new Date()
        };
        this.userCache.set(defaultUser.id, defaultUser);
        this.usernameIndex.set(defaultUser.username, defaultUser.id);
        this.userId = 2;
        
        // Save to file
        fs.writeFileSync(USERS_FILE, JSON.stringify([defaultUser]));
      }
    } catch (error) {
      console.error('Error loading users:', error);
    }
  }

  private async loadCharacters() {
    try {
      const data = fs.readFileSync(CHARACTERS_FILE, 'utf8');
      const characters: Character[] = JSON.parse(data);
      
      if (characters.length > 0) {
        for (const character of characters) {
          this.characterCache.set(character.id, character);
          if (character.id >= this.characterId) {
            this.characterId = character.id + 1;
          }
        }
      }
      // Initialize with default characters if none exist
      else {
        const defaultCharacters = this.initializeDefaultCharacters();
        this.characterId = Math.max(...defaultCharacters.map(c => c.id)) + 1;
        
        // Save to file
        fs.writeFileSync(CHARACTERS_FILE, JSON.stringify(defaultCharacters));
      }
    } catch (error) {
      console.error('Error loading characters:', error);
    }
  }

  private initializeDefaultCharacters(): Character[] {
    const characters: Character[] = DEFAULT_CHARACTERS.map(character => ({
      ...character,
      isDefault: true,
      createdAt: new Date(),
      updatedAt: new Date()
    }));
    
    for (const character of characters) {
      this.characterCache.set(character.id, character);
    }
    
    console.log('Default characters initialized');
    return characters;
  }

  private async loadConversations() {
    try {
      const data = fs.readFileSync(CONVERSATIONS_FILE, 'utf8');
      const conversations: Conversation[] = JSON.parse(data);
      
      for (const conversation of conversations) {
        this.conversationCache.set(conversation.id, conversation);
        
        // Update user conversation index
        if (conversation.userId !== null) {
          if (!this.userConversationIndex.has(conversation.userId)) {
            this.userConversationIndex.set(conversation.userId, new Set());
          }
          this.userConversationIndex.get(conversation.userId)?.add(conversation.id);
        }
        
        // Update char-user conversation index
        if (conversation.characterId !== null && conversation.userId !== null) {
          const key = `${conversation.characterId}-${conversation.userId}`;
          this.charUserConversationIndex.set(key, conversation.id);
        }
        
        if (conversation.id >= this.conversationId) {
          this.conversationId = conversation.id + 1;
        }
      }
    } catch (error) {
      console.error('Error loading conversations:', error);
    }
  }

  private async loadMessages() {
    try {
      const data = fs.readFileSync(MESSAGES_FILE, 'utf8');
      const messages: Message[] = JSON.parse(data);
      
      for (const message of messages) {
        this.messageCache.set(message.id, message);
        
        // Update conversation messages index
        if (message.conversationId !== null) {
          if (!this.conversationMessagesIndex.has(message.conversationId)) {
            this.conversationMessagesIndex.set(message.conversationId, new Set());
          }
          this.conversationMessagesIndex.get(message.conversationId)?.add(message.id);
        }
        
        if (message.id >= this.messageId) {
          this.messageId = message.id + 1;
        }
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  }

  private async loadMemories() {
    try {
      const data = fs.readFileSync(MEMORIES_FILE, 'utf8');
      const memories: Memory[] = JSON.parse(data);
      
      for (const memory of memories) {
        this.memoryCache.set(memory.id, memory);
        
        // Update char-user memory index
        if (memory.characterId !== null && memory.userId !== null) {
          const key = `${memory.characterId}-${memory.userId}`;
          if (!this.charUserMemoryIndex.has(key)) {
            this.charUserMemoryIndex.set(key, new Set());
          }
          this.charUserMemoryIndex.get(key)?.add(memory.id);
        }
        
        if (memory.id >= this.memoryId) {
          this.memoryId = memory.id + 1;
        }
      }
    } catch (error) {
      console.error('Error loading memories:', error);
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.userCache.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const userId = this.usernameIndex.get(username);
    if (userId) {
      return this.userCache.get(userId);
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Hash the password
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    
    const user: User = {
      id: this.userId++,
      ...insertUser,
      password: hashedPassword,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastActive: new Date(),
      // Set default values for fields that might be missing
      role: insertUser.role || "user",
      profilePicture: insertUser.profilePicture || null,
      preferences: insertUser.preferences || null,
      displayName: insertUser.displayName || null
    };
    
    // Update in-memory cache
    this.userCache.set(user.id, user);
    this.usernameIndex.set(user.username, user.id);
    
    // Update persistent storage
    await this.saveUsers();
    
    return user;
  }

  async updateUserLastActive(id: number, date: Date): Promise<void> {
    const user = this.userCache.get(id);
    if (user) {
      user.lastActive = date;
      this.userCache.set(id, user);
      
      // Update persistent storage
      await this.saveUsers();
    }
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const user = this.userCache.get(id);
    
    if (!user) {
      throw new Error("User not found");
    }
    
    // Update user with new data
    const updatedUser: User = {
      ...user,
      ...userData,
      updatedAt: new Date()
    };
    
    // Update in-memory cache
    this.userCache.set(id, updatedUser);
    
    // If username was changed, update the username index
    if (userData.username && userData.username !== user.username) {
      this.usernameIndex.delete(user.username);
      this.usernameIndex.set(userData.username, id);
    }
    
    // Update persistent storage
    await this.saveUsers();
    
    return updatedUser;
  }

  // Character methods
  async getAllCharacters(): Promise<Character[]> {
    return Array.from(this.characterCache.values());
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    return this.characterCache.get(id);
  }
  
  async getCharacterByName(name: string): Promise<Character | undefined> {
    // Case-insensitive search for character by name
    for (const character of this.characterCache.values()) {
      if (character.name.toLowerCase() === name.toLowerCase()) {
        return character;
      }
    }
    return undefined;
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const character: Character = {
      id: this.characterId++,
      name: insertCharacter.name,
      description: insertCharacter.description,
      systemPrompt: insertCharacter.systemPrompt,
      imageUrl: insertCharacter.imageUrl || null,
      backgroundGradient: insertCharacter.backgroundGradient || null,
      tags: insertCharacter.tags || null,
      category: insertCharacter.category || null,
      isDefault: insertCharacter.isDefault || false,
      creatorId: insertCharacter.creatorId || null,
      customizations: insertCharacter.customizations || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    // Update in-memory cache
    this.characterCache.set(character.id, character);
    
    // Update persistent storage
    await this.saveCharacters();
    
    return character;
  }

  async updateCharacterCustomizations(id: number, customizations: any): Promise<Character> {
    const character = this.characterCache.get(id);
    
    if (!character) {
      throw new Error("Character not found");
    }
    
    // Merge existing and new customizations
    const updatedCharacter: Character = {
      ...character,
      customizations: {
        ...(character.customizations || {}),
        ...customizations
      },
      updatedAt: new Date()
    };
    
    // Update in-memory cache
    this.characterCache.set(id, updatedCharacter);
    
    // Update persistent storage
    await this.saveCharacters();
    
    return updatedCharacter;
  }

  // Conversation methods
  async getConversationsByUserId(userId: number): Promise<Conversation[]> {
    const conversationIds = this.userConversationIndex.get(userId);
    if (!conversationIds) return [];
    
    const conversations: Conversation[] = [];
    // Use Array.from to handle Set iteration
    Array.from(conversationIds).forEach(id => {
      const conversation = this.conversationCache.get(id);
      if (conversation) {
        conversations.push(conversation);
      }
    });
    
    return conversations;
  }

  async getConversationByUserAndCharacter(userId: number, characterId: number): Promise<Conversation | undefined> {
    const key = `${characterId}-${userId}`;
    const conversationId = this.charUserConversationIndex.get(key);
    if (conversationId) {
      return this.conversationCache.get(conversationId);
    }
    return undefined;
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversationCache.get(id);
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const conversation: Conversation = {
      id: this.conversationId++,
      userId: insertConversation.userId || null,
      characterId: insertConversation.characterId || null,
      title: insertConversation.title || "New Conversation",
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    // Update in-memory cache
    this.conversationCache.set(conversation.id, conversation);
    
    // Update user conversation index
    if (conversation.userId !== null) {
      if (!this.userConversationIndex.has(conversation.userId)) {
        this.userConversationIndex.set(conversation.userId, new Set());
      }
      this.userConversationIndex.get(conversation.userId)?.add(conversation.id);
    }
    
    // Update char-user conversation index
    if (conversation.characterId !== null && conversation.userId !== null) {
      const key = `${conversation.characterId}-${conversation.userId}`;
      this.charUserConversationIndex.set(key, conversation.id);
    }
    
    // Update persistent storage
    await this.saveConversations();
    
    return conversation;
  }

  // Message methods
  async getMessagesByConversationId(conversationId: number): Promise<Message[]> {
    const messageIds = this.conversationMessagesIndex.get(conversationId);
    if (!messageIds) return [];
    
    const messages: Message[] = [];
    // Use Array.from to handle Set iteration
    Array.from(messageIds).forEach(id => {
      const message = this.messageCache.get(id);
      if (message) {
        messages.push(message);
      }
    });
    
    // Sort by timestamp - handle null timestamps
    return messages.sort((a, b) => {
      const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
      const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
      return timeA - timeB;
    });
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const message: Message = {
      id: this.messageId++,
      role: insertMessage.role,
      content: insertMessage.content,
      conversationId: insertMessage.conversationId || null,
      timestamp: new Date()
    };
    
    // Update in-memory cache
    this.messageCache.set(message.id, message);
    
    // Update conversation messages index
    if (message.conversationId !== null) {
      if (!this.conversationMessagesIndex.has(message.conversationId)) {
        this.conversationMessagesIndex.set(message.conversationId, new Set());
      }
      this.conversationMessagesIndex.get(message.conversationId)?.add(message.id);
      
      // Update conversation's updatedAt timestamp
      const conversation = this.conversationCache.get(message.conversationId);
      if (conversation) {
        conversation.updatedAt = new Date();
        this.conversationCache.set(conversation.id, conversation);
        await this.saveConversations();
      }
    }
    
    // Update persistent storage
    await this.saveMessages();
    
    return message;
  }

  // Memory methods
  async getMemoriesByCharacterAndUser(characterId: number, userId: number): Promise<Memory[]> {
    const key = `${characterId}-${userId}`;
    const memoryIds = this.charUserMemoryIndex.get(key);
    if (!memoryIds) return [];
    
    const memories: Memory[] = [];
    // Use Array.from to handle Set iteration
    Array.from(memoryIds).forEach(id => {
      const memory = this.memoryCache.get(id);
      if (memory) {
        memories.push(memory);
      }
    });
    
    return memories;
  }

  async createMemory(insertMemory: InsertMemory): Promise<Memory> {
    const memory: Memory = {
      id: this.memoryId++,
      content: insertMemory.content,
      userId: insertMemory.userId || null,
      characterId: insertMemory.characterId || null,
      embedding: insertMemory.embedding || null,
      createdAt: new Date()
    };
    
    // Update in-memory cache
    this.memoryCache.set(memory.id, memory);
    
    // Update char-user memory index
    if (memory.characterId !== null && memory.userId !== null) {
      const key = `${memory.characterId}-${memory.userId}`;
      if (!this.charUserMemoryIndex.has(key)) {
        this.charUserMemoryIndex.set(key, new Set());
      }
      this.charUserMemoryIndex.get(key)?.add(memory.id);
    }
    
    // Update persistent storage
    await this.saveMemories();
    
    return memory;
  }

  // Persistence methods
  private async saveUsers() {
    try {
      const users = Array.from(this.userCache.values());
      fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
    } catch (error) {
      console.error('Error saving users:', error);
    }
  }

  private async saveCharacters() {
    try {
      const characters = Array.from(this.characterCache.values());
      fs.writeFileSync(CHARACTERS_FILE, JSON.stringify(characters, null, 2));
    } catch (error) {
      console.error('Error saving characters:', error);
    }
  }

  private async saveConversations() {
    try {
      const conversations = Array.from(this.conversationCache.values());
      fs.writeFileSync(CONVERSATIONS_FILE, JSON.stringify(conversations, null, 2));
    } catch (error) {
      console.error('Error saving conversations:', error);
    }
  }

  private async saveMessages() {
    try {
      const messages = Array.from(this.messageCache.values());
      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));
    } catch (error) {
      console.error('Error saving messages:', error);
    }
  }

  private async saveMemories() {
    try {
      const memories = Array.from(this.memoryCache.values());
      fs.writeFileSync(MEMORIES_FILE, JSON.stringify(memories, null, 2));
    } catch (error) {
      console.error('Error saving memories:', error);
    }
  }
}

// Create and export a singleton instance
export const storage = new HybridStorage();