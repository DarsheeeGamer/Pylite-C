import OpenAI from "openai";
import { ServerResponse } from "http";
import type { Character, Message, Memory } from "@shared/schema";
import { RESPONSE_LENGTH_OPTIONS, COMMUNICATION_STYLE_OPTIONS } from "../../client/src/lib/constants";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "sk-dummy-key-for-development" });

// Map to store client connections
const clients = new Map<number, ServerResponse>();

export async function chatWithCharacter(
  character: Character,
  conversationHistory: Message[],
  memories: Memory[],
  latestUserMessage: string
): Promise<string> {
  try {
    // Format conversation history
    const messages = conversationHistory.map((msg) => ({
      role: msg.role as "user" | "assistant" | "system",
      content: msg.content,
    }));
    
    // Add system message with character's personality
    const systemMessage = {
      role: "system" as const,
      content: generateSystemPrompt(character, memories),
    };
    
    // Prepare the API call
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [systemMessage, ...messages],
      temperature: 0.7,
      max_tokens: getMaxTokens(character),
      stream: true,
    });
    
    // Process the streamed response
    let fullResponse = "";
    const clientId = Date.now();
    
    // Send typing indicator to all clients
    for (const client of clients.values()) {
      client.write(`data: ${JSON.stringify({ type: "typing_start" })}\n\n`);
    }
    
    for await (const chunk of response) {
      const content = chunk.choices[0]?.delta?.content || "";
      if (content) {
        fullResponse += content;
        
        // Send content chunk to all clients
        for (const client of clients.values()) {
          client.write(`data: ${JSON.stringify({
            type: "content_chunk",
            messageId: Date.now(),
            conversationId: conversationHistory[0]?.conversationId || 0,
            chunk: content
          })}\n\n`);
        }
        
        // Add a small delay to simulate natural typing speed
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
    }
    
    // Send typing end indicator to all clients
    for (const client of clients.values()) {
      client.write(`data: ${JSON.stringify({ type: "typing_end" })}\n\n`);
    }
    
    return fullResponse;
  } catch (error) {
    console.error("Error in OpenAI API call:", error);
    return "I'm sorry, I'm having trouble connecting right now. Please try again in a moment.";
  }
}

function generateSystemPrompt(character: Character, memories: Memory[]): string {
  let prompt = character.systemPrompt || "";
  
  // Add customizations if available
  if (character.customizations) {
    const communicationStyle = character.customizations.communicationStyle;
    if (communicationStyle && COMMUNICATION_STYLE_OPTIONS[communicationStyle]) {
      prompt += `\n\n${COMMUNICATION_STYLE_OPTIONS[communicationStyle].prompt}`;
    }
  }
  
  // Add memories context if available
  if (memories && memories.length > 0) {
    prompt += "\n\nHere are some relevant memories from previous conversations:";
    memories.forEach((memory, index) => {
      prompt += `\n[Memory ${index + 1}]: ${memory.content}`;
    });
    prompt += "\n\nUse these memories when they are relevant to the current conversation, but don't explicitly mention that they are 'memories'.";
  }
  
  return prompt;
}

function getMaxTokens(character: Character): number {
  if (character.customizations?.responseLength) {
    const length = character.customizations.responseLength;
    return RESPONSE_LENGTH_OPTIONS[length]?.maxTokens || 400;
  }
  return 400; // Default to moderate
}

export function generateStreamResponse(clientId: number, res: ServerResponse): () => void {
  // Add this client to the clients map
  clients.set(clientId, res);
  
  // Return cleanup function
  return () => {
    clients.delete(clientId);
    res.end();
  };
}
