import { storage } from "../storage";
import type { Memory, InsertMemory } from "@shared/schema";

// Simple in-memory vector store for the MVP
// In a production environment, this would be replaced with a proper vector database
class SimpleMemoryStore {
  // Map to store embeddings by character and user
  private memoryStore: Map<string, Array<{ content: string, embedding: number[] }>>;
  
  constructor() {
    this.memoryStore = new Map();
  }
  
  // Add a memory with its embedding
  addMemory(characterId: number, userId: number, content: string, embedding: number[]): void {
    const key = `${characterId}-${userId}`;
    
    if (!this.memoryStore.has(key)) {
      this.memoryStore.set(key, []);
    }
    
    this.memoryStore.get(key)!.push({ content, embedding });
  }
  
  // Find similar memories based on cosine similarity
  findSimilarMemories(characterId: number, userId: number, queryEmbedding: number[], limit: number = 5): string[] {
    const key = `${characterId}-${userId}`;
    const memories = this.memoryStore.get(key) || [];
    
    // Calculate cosine similarity for each memory
    const similarities = memories.map((memory) => ({
      content: memory.content,
      similarity: this.cosineSimilarity(queryEmbedding, memory.embedding)
    }));
    
    // Sort by similarity (highest first) and return the top matches
    return similarities
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit)
      .map((item) => item.content);
  }
  
  // Cosine similarity calculation
  private cosineSimilarity(vecA: number[], vecB: number[]): number {
    const dotProduct = vecA.reduce((sum, a, i) => sum + a * vecB[i], 0);
    const magnitudeA = Math.sqrt(vecA.reduce((sum, a) => sum + a * a, 0));
    const magnitudeB = Math.sqrt(vecB.reduce((sum, b) => sum + b * b, 0));
    
    return dotProduct / (magnitudeA * magnitudeB);
  }
}

const memoryStore = new SimpleMemoryStore();

// For MVP, we'll fake the embeddings with a simple hash function
function generateFakeEmbedding(text: string): number[] {
  const embedding: number[] = [];
  const hash = hashCode(text);
  
  // Create a 10-dimensional "embedding" based on the hash
  for (let i = 0; i < 10; i++) {
    embedding.push(Math.sin(hash * (i + 1)) * 0.5 + 0.5); // Values between 0 and 1
  }
  
  return embedding;
}

function hashCode(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return hash;
}

// Store a memory with its embedding
export async function storeMemory(characterId: number, userId: number, content: string): Promise<Memory> {
  try {
    // Generate a fake embedding (in a real app, this would use an embedding model)
    const embedding = generateFakeEmbedding(content);
    
    // Store in our simple vector store
    memoryStore.addMemory(characterId, userId, content, embedding);
    
    // Store in the database
    const insertMemory: InsertMemory = {
      characterId,
      userId,
      content,
      embedding: JSON.stringify(embedding) // Store as string
    };
    
    return await storage.createMemory(insertMemory);
  } catch (error) {
    console.error("Error storing memory:", error);
    throw error;
  }
}

// Retrieve relevant memories for a given query
export async function getRelevantMemories(characterId: number, userId: number, query: string): Promise<Memory[]> {
  try {
    // Generate a fake embedding for the query
    const queryEmbedding = generateFakeEmbedding(query);
    
    // Retrieve similar memories from the vector store
    const similarContents = memoryStore.findSimilarMemories(characterId, userId, queryEmbedding);
    
    if (similarContents.length === 0) {
      return [];
    }
    
    // Get all memories for this character and user
    const allMemories = await storage.getMemoriesByCharacterAndUser(characterId, userId);
    
    // Filter to only include the ones we found similar
    return allMemories.filter(memory => similarContents.includes(memory.content));
  } catch (error) {
    console.error("Error retrieving memories:", error);
    return [];
  }
}
