import type { Character } from "@shared/schema";

/**
 * AI Model configuration interface
 */
export interface AIModelConfig {
  modelName: string;
  apiEndpoint: string;
  apiKey?: string;
  maxTokens?: number;
  defaultTemperature?: number;
}

/**
 * Default AI model configuration
 */
const DEFAULT_MODEL_CONFIG: AIModelConfig = {
  modelName: "llama3.2",
  apiEndpoint: "https://crisp-brightly-shiner.ngrok-free.app",
  maxTokens: 1000,
  defaultTemperature: 0.7
};

/**
 * Character Name to AI model mapping
 */
const AI_MODEL_MAPPING: Record<string, AIModelConfig> = {
  // Sophia - Philosophical, empathetic AI
  "Sophia": {
    ...DEFAULT_MODEL_CONFIG,
    modelName: "llama3.2",
    maxTokens: 1200,  // Give Sophia slightly longer responses
    defaultTemperature: 0.7  // Standard temperature for balanced responses
  },
  
  // Alex - Tech-savvy, factual AI
  "Alex": {
    ...DEFAULT_MODEL_CONFIG,
    modelName: "llama3.2",
    maxTokens: 800,  // Shorter, more concise responses
    defaultTemperature: 0.5  // Lower temperature for more factual responses
  },
  
  // Luna - Creative, imaginative AI
  "Luna": {
    ...DEFAULT_MODEL_CONFIG,
    modelName: "llama3.2",
    maxTokens: 1500,  // Longer, more detailed creative responses
    defaultTemperature: 0.8  // Higher temperature for more creative variety
  }
};

/**
 * Get AI model configuration for a specific character name
 * @param characterName The character name
 * @returns The AI model configuration
 */
export function getAIModelConfigByName(characterName: string): AIModelConfig {
  return AI_MODEL_MAPPING[characterName] || DEFAULT_MODEL_CONFIG;
}

/**
 * Get AI model configuration for a specific character object
 * @param character The character object
 * @returns The AI model configuration
 */
export function getAIModelConfigForCharacter(character: Character): AIModelConfig {
  return getAIModelConfigByName(character.name);
}

/**
 * Override settings with any character customizations
 * @param config Base AI model configuration
 * @param character Character with possible customizations
 * @returns Updated model configuration
 */
export function applyCharacterCustomizations(config: AIModelConfig, character: Character): AIModelConfig {
  const updatedConfig = { ...config };
  
  if (character.customizations) {
    // Apply temperature customization if available
    if (character.customizations.temperature) {
      if (typeof character.customizations.temperature === 'number') {
        updatedConfig.defaultTemperature = character.customizations.temperature;
      } else {
        const temp = parseFloat(character.customizations.temperature);
        if (!isNaN(temp)) {
          updatedConfig.defaultTemperature = temp;
        }
      }
    }
    
    // Apply max tokens customization based on response length preference
    if (character.customizations.responseLength) {
      switch (character.customizations.responseLength) {
        case 'brief':
        case 'Concise':
          updatedConfig.maxTokens = 200;
          break;
        case 'moderate':
        case 'Moderate':
          updatedConfig.maxTokens = 500;
          break;
        case 'detailed':
        case 'Detailed':
          updatedConfig.maxTokens = 1000;
          break;
        case 'extensive':
          updatedConfig.maxTokens = 2000;
          break;
      }
    }
  }
  
  return updatedConfig;
}

/**
 * Get the final AI model configuration for a character, applying any customizations
 * @param character The character
 * @returns Final AI model configuration
 */
export function getFinalAIModelConfig(character: Character): AIModelConfig {
  const baseConfig = getAIModelConfigForCharacter(character);
  return applyCharacterCustomizations(baseConfig, character);
}