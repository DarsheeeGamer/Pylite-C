import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Send, ArrowLeft, Settings, User, MessageSquare } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Character, Message } from "@shared/schema";

type ChatParams = {
  id: string;
};

const AiCharacterPage = () => {
  const { id } = useParams<ChatParams>();
  const characterId = parseInt(id);
  const { user } = useAuth();
  const { toast } = useToast();
  const [inputValue, setInputValue] = useState("");
  const [hasConnected, setHasConnected] = useState(false);
  const [typingIndicator, setTypingIndicator] = useState(false);
  const [streamedResponse, setStreamedResponse] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const eventSourceRef = useRef<EventSource | null>(null);

  // Fetch character details
  const { data: character, isLoading: characterLoading } = useQuery<Character>({
    queryKey: ["/api/characters", characterId],
    enabled: !!characterId,
  });

  // Fetch existing messages
  const { data: messages = [], isLoading: messagesLoading } = useQuery<Message[]>({
    queryKey: ["/api/messages", characterId],
    enabled: !!characterId,
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return await apiRequest("POST", "/api/messages", {
        characterId,
        content,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages", characterId] });
    },
    onError: (error) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Set up Server-Sent Events for streaming responses
  useEffect(() => {
    if (!characterId || !user || hasConnected) return;

    const connectToStream = () => {
      const eventSource = new EventSource(`/api/stream?characterId=${characterId}`);
      eventSourceRef.current = eventSource;
      setHasConnected(true);

      eventSource.onopen = () => {
        console.log("Connected to streaming API");
      };

      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log("Stream event:", data);

          if (data.type === "typing_start") {
            setTypingIndicator(true);
            setStreamedResponse("");
          } else if (data.type === "content_chunk") {
            if (data.chunk) {
              console.log("Received content chunk:", data.chunk);
              setStreamedResponse(prev => prev + data.chunk);
            } else {
              console.log("Empty chunk received");
            }
          } else if (data.type === "typing_end") {
            console.log("Typing ended, final response:", data.fullResponse?.length || 0, "characters");
            setTypingIndicator(false);
            // Keep the streamed response visible for a moment before refreshing
            setTimeout(() => {
              setStreamedResponse("");
              // Reload messages to get the full conversation
              queryClient.invalidateQueries({ queryKey: ["/api/messages", characterId] });
            }, 500);
          } else if (data.type === "error") {
            console.error("Stream error:", data.error);
            toast({
              title: "Connection Error",
              description: data.error,
              variant: "destructive",
            });
            setTypingIndicator(false);
          }
        } catch (error) {
          console.error("Error parsing stream data:", error, "Raw data:", event.data);
        }
      };

      eventSource.onerror = (error) => {
        console.error("Stream connection error:", error);
        eventSource.close();
        setHasConnected(false);

        // Try to reconnect after a short delay
        setTimeout(connectToStream, 3000);

        toast({
          title: "Connection Lost",
          description: "Trying to reconnect...",
          variant: "destructive",
        });
      };
    };

    connectToStream();

    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [characterId, user, hasConnected, toast]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, streamedResponse]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || sendMessageMutation.isPending) return;

    sendMessageMutation.mutate(inputValue.trim());
    setInputValue("");
  };

  // Update page title
  useEffect(() => {
    if (character) {
      document.title = `Caddy - Chat with ${character.name}`;
    } else {
      document.title = "Caddy - AI Companion Chat";
    }
    
    return () => {
      document.title = "Caddy - AI Companion Chat";
    };
  }, [character]);
  
  // Calculate gradient classes for character background
  const getGradientClass = () => {
    if (!character) return "bg-gradient-to-r from-purple-600 to-blue-600";
    
    return character.backgroundGradient || "bg-gradient-to-r from-purple-600 to-blue-600";
  };

  // Loading state
  if (characterLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Character not found
  if (!character) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <h1 className="text-2xl font-bold mb-4">Character Not Found</h1>
        <p className="text-gray-600 mb-6">The character you're looking for doesn't exist or has been removed.</p>
        <Link href="/marketplace/ai/characters">
          <Button>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Marketplace
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header with Character Info */}
      <header className={`${getGradientClass()} text-white shadow-md`}>
        <div className="container mx-auto px-4 py-4 flex items-center">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 mr-4">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          
          <Avatar className="h-10 w-10 border-2 border-white">
            {character?.imageUrl ? (
              <AvatarImage src={character.imageUrl} alt={character?.name || 'AI Character'} />
            ) : (
              <AvatarFallback className="bg-white/20 text-white">
                {character?.name ? character.name.substring(0, 2) : 'AI'}
              </AvatarFallback>
            )}
          </Avatar>
          
          <div className="ml-3">
            <h1 className="font-bold">{character?.name || 'AI Character'}</h1>
            <p className="text-sm text-white/80">{character?.description || 'An AI character you can chat with.'}</p>
          </div>

          <div className="ml-auto">
            <Link href={`/ai/${characterId}/settings`}>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <Settings className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Initial welcome message if no messages */}
        {messages.length === 0 && !messagesLoading && (
          <div className="flex justify-center my-8">
            <Card className="w-full max-w-md border-none shadow-md bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <Avatar className="h-16 w-16 mx-auto mb-4">
                  {character?.imageUrl ? (
                    <AvatarImage src={character.imageUrl} alt={character?.name || 'AI Character'} />
                  ) : (
                    <AvatarFallback className={`${getGradientClass()} text-white`}>
                      {character?.name ? character.name.substring(0, 2) : 'AI'}
                    </AvatarFallback>
                  )}
                </Avatar>
                <h3 className="text-xl font-bold mb-2">Meet {character?.name || 'AI Character'}</h3>
                <p className="text-gray-600 mb-4">{character?.description || 'An AI character you can chat with.'}</p>
                <p className="text-sm text-gray-500">Send a message to start chatting!</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Loading indicator */}
        {messagesLoading && (
          <div className="flex justify-center my-8">
            <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
          </div>
        )}

        {/* Render messages */}
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex gap-3 mb-4 ${message.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {message.role !== "user" && (
              <Avatar className="h-9 w-9 border shadow-sm">
                {character?.imageUrl ? (
                  <AvatarImage src={character.imageUrl} alt={character?.name || 'AI Character'} />
                ) : (
                  <AvatarFallback className={`${getGradientClass()} text-white`}>
                    {character?.name ? character.name.substring(0, 2).toUpperCase() : 'AI'}
                  </AvatarFallback>
                )}
              </Avatar>
            )}
            
            <div className="flex flex-col">
              <div className={`px-1 py-0.5 text-xs ${message.role === "user" ? "text-right text-muted-foreground" : "text-muted-foreground"}`}>
                {message.role === "user" ? user?.username || "You" : character?.name || "AI"}
              </div>
              
              <div
                className={`max-w-[320px] sm:max-w-[450px] rounded-2xl p-3 ${
                  message.role === "user"
                    ? "bg-primary text-white rounded-tr-none"
                    : "bg-gray-100 text-gray-800 rounded-tl-none"
                }`}
              >
                {message.content}
              </div>
            </div>
            
            {message.role === "user" && (
              <Avatar className="h-9 w-9 border shadow-sm">
                {user?.profilePicture ? (
                  <AvatarImage src={user.profilePicture} alt={user?.username || 'You'} />
                ) : (
                  <AvatarFallback className="bg-primary text-white">
                    {user?.username ? user.username.substring(0, 2).toUpperCase() : 'You'}
                  </AvatarFallback>
                )}
              </Avatar>
            )}
          </div>
        ))}

        {/* Streamed response in progress */}
        {streamedResponse && (
          <div className="flex gap-3 mb-4 justify-start">
            <Avatar className="h-9 w-9 border shadow-sm">
              {character?.imageUrl ? (
                <AvatarImage src={character.imageUrl} alt={character?.name || 'AI Character'} />
              ) : (
                <AvatarFallback className={`${getGradientClass()} text-white`}>
                  {character?.name ? character.name.substring(0, 2).toUpperCase() : 'AI'}
                </AvatarFallback>
              )}
            </Avatar>
            
            <div className="flex flex-col">
              <div className="px-1 py-0.5 text-xs text-muted-foreground">
                {character?.name || "AI"}
              </div>
              
              <div className="max-w-[320px] sm:max-w-[450px] rounded-2xl p-3 bg-gray-100 text-gray-800 rounded-tl-none">
                {streamedResponse}
              </div>
            </div>
          </div>
        )}

        {/* Typing indicator */}
        {typingIndicator && !streamedResponse && (
          <div className="flex gap-3 mb-4 justify-start">
            <Avatar className="h-9 w-9 border shadow-sm">
              {character?.imageUrl ? (
                <AvatarImage src={character.imageUrl} alt={character?.name || 'AI Character'} />
              ) : (
                <AvatarFallback className={`${getGradientClass()} text-white`}>
                  {character?.name ? character.name.substring(0, 2).toUpperCase() : 'AI'}
                </AvatarFallback>
              )}
            </Avatar>
            
            <div className="flex flex-col">
              <div className="px-1 py-0.5 text-xs text-muted-foreground">
                {character?.name || "AI"}
              </div>
              
              <div className="max-w-[320px] sm:max-w-[450px] rounded-2xl p-3 bg-gray-100 text-gray-800 rounded-tl-none">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "0ms" }}></div>
                  <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "300ms" }}></div>
                  <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "600ms" }}></div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Invisible element to scroll to */}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="px-4 py-3 bg-white border-t">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          <Input
            placeholder="Type a message..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            disabled={sendMessageMutation.isPending}
            className="flex-1"
          />
          <Button 
            type="submit" 
            size="icon" 
            disabled={sendMessageMutation.isPending || !inputValue.trim()}
            className="h-10 w-10 rounded-full"
          >
            {sendMessageMutation.isPending ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Send className="h-5 w-5" />
            )}
          </Button>
        </form>
      </div>
    </div>
  );
};

export default AiCharacterPage;