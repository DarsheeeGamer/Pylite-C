import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

const WelcomePage = () => {
  const { user, isLoading } = useAuth();
  const [isExploring, setIsExploring] = useState(false);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section with Gradient Background */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 text-white">
        <div className="container mx-auto px-4 py-12 md:py-24">
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-100">
              Welcome to Caddy
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-100">
              Connect with intelligent AI characters designed to understand, entertain, and assist - your personal AI companions for meaningful conversations.
            </p>
            <div className="flex gap-4 flex-wrap">
              {user ? (
                <Link href="/dashboard">
                  <Button
                    size="lg"
                    className="bg-white text-purple-700 hover:bg-gray-100 transition-all"
                    onClick={() => setIsExploring(true)}
                  >
                    {isExploring ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Loading...
                      </>
                    ) : (
                      "Go to Dashboard"
                    )}
                  </Button>
                </Link>
              ) : (
                <Link href="/auth">
                  <Button
                    size="lg"
                    className="bg-white text-purple-700 hover:bg-gray-100 transition-all"
                  >
                    Get Started
                  </Button>
                </Link>
              )}
              <Link href="/marketplace/ai/characters">
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-transparent border-white text-white hover:bg-white/10"
                >
                  Explore Characters
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Our AI Companions</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard
              title="Personalized Conversations"
              description="Our AI characters remember your interactions and adapt their responses to your unique preferences."
              icon="💬"
            />
            <FeatureCard
              title="Diverse Characters"
              description="Choose from a wide range of personalities, from supportive friends to intellectual mentors."
              icon="🌈"
            />
            <FeatureCard
              title="Private & Secure"
              description="Your conversations are private and secure. We prioritize your data privacy."
              icon="🔒"
            />
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <StepCard
              number={1}
              title="Create an Account"
              description="Sign up to get started with our AI companions."
            />
            <StepCard
              number={2}
              title="Choose a Character"
              description="Browse our marketplace and select a character that resonates with you."
            />
            <StepCard
              number={3}
              title="Start Chatting"
              description="Engage in meaningful conversations and build a connection."
            />
          </div>
        </div>
      </div>

      {/* Testimonials or Featured Characters Section */}
      <div className="py-16 bg-gradient-to-r from-purple-100 to-pink-100">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Characters</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Replace with actual featured characters from your database */}
            <CharacterCard
              id={1}
              name="Sophia"
              description="An empathetic companion who's always ready to listen and provide thoughtful advice."
              gradient="from-blue-500 to-purple-600"
            />
            <CharacterCard
              id={2}
              name="Alex"
              description="A witty intellectual who loves discussing philosophy, science, and the big questions of life."
              gradient="from-green-500 to-teal-600"
            />
            <CharacterCard
              id={3}
              name="Luna"
              description="A creative spirit who can inspire your artistic endeavors and help you think outside the box."
              gradient="from-red-500 to-orange-600"
            />
          </div>
        </div>
      </div>

      {/* Call-to-Action Section */}
      <div className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Meet Your AI Companion?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of users who have discovered meaningful connections with our AI characters.
          </p>
          {user ? (
            <Link href="/dashboard">
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                Go to Your Dashboard
              </Button>
            </Link>
          ) : (
            <Link href="/auth">
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                Get Started Now
              </Button>
            </Link>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold text-lg mb-4">Caddy</h3>
              <p className="text-gray-300">
                Creating meaningful AI connections for a more engaging digital experience.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-300 hover:text-white">Home</Link></li>
                <li><Link href="/marketplace/ai/characters" className="text-gray-300 hover:text-white">Marketplace</Link></li>
                <li><Link href="/dashboard" className="text-gray-300 hover:text-white">Dashboard</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white">Terms of Service</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Connect</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-white">Contact Us</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white">Support</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Caddy AI Companion. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

// Helper Components
const FeatureCard = ({ title, description, icon }: { title: string, description: string, icon: string }) => (
  <Card className="border-none shadow-md hover:shadow-lg transition-all">
    <CardContent className="p-6">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </CardContent>
  </Card>
);

const StepCard = ({ number, title, description }: { number: number, title: string, description: string }) => (
  <div className="text-center">
    <div className="w-16 h-16 bg-purple-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
      {number}
    </div>
    <h3 className="text-xl font-bold mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

const CharacterCard = ({ id, name, description, gradient }: { id: number, name: string, description: string, gradient: string }) => (
  <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-all">
    <div className={`h-24 bg-gradient-to-r ${gradient}`}></div>
    <CardContent className="p-6">
      <h3 className="text-xl font-bold mb-2">{name}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <Link href={`/ai/${id}`}>
        <Button variant="outline" className="w-full">Chat Now</Button>
      </Link>
    </CardContent>
  </Card>
);

export default WelcomePage;