import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, ArrowLeft, Upload, User, Mail, Lock } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";

// Extended types for user preferences
interface UserPreferences {
  darkMode?: boolean;
  notifications?: boolean;
  autoPlayAudio?: boolean;
}

// Form schema
const userProfileSchema = z.object({
  displayName: z.string().min(2, "Display name must be at least 2 characters").max(50),
  email: z.string().email("Please enter a valid email address"),
  profilePicture: z.string().optional(),
  preferences: z.object({
    darkMode: z.boolean().default(false),
    notifications: z.boolean().default(true),
    autoPlayAudio: z.boolean().default(false),
  }).optional(),
});

type UserProfileFormValues = z.infer<typeof userProfileSchema>;

const UserSettingsPage = () => {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(null);
  
  // Function to safely parse preferences
  const getPreferences = (prefs: unknown): UserPreferences => {
    if (!prefs || typeof prefs !== 'object') {
      return {
        darkMode: false,
        notifications: true,
        autoPlayAudio: false
      };
    }
    
    const p = prefs as Record<string, unknown>;
    return {
      darkMode: p.darkMode === true,
      notifications: p.notifications !== false, // default to true
      autoPlayAudio: p.autoPlayAudio === true
    };
  };
  
  // Form definition
  const form = useForm<UserProfileFormValues>({
    resolver: zodResolver(userProfileSchema),
    defaultValues: {
      displayName: user?.displayName || user?.username || "",
      email: user?.email || "",
      profilePicture: user?.profilePicture || "",
      preferences: getPreferences(user?.preferences),
    },
  });
  
  // Update form values when user data is loaded
  useEffect(() => {
    if (user) {
      form.reset({
        displayName: user.displayName || user.username || "",
        email: user.email || "",
        profilePicture: user.profilePicture || "",
        preferences: getPreferences(user.preferences),
      });
      
      if (user.profilePicture) {
        setProfileImagePreview(user.profilePicture);
      }
    }
  }, [user, form]);
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (values: UserProfileFormValues) => {
      return await apiRequest("PATCH", "/api/user/profile", values);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error updating profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle image upload
  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setProfileImagePreview(result);
        form.setValue("profilePicture", result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Handle form submission
  const onSubmit = (values: UserProfileFormValues) => {
    updateProfileMutation.mutate(values);
  };
  
  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Card className="w-full max-w-md p-6">
          <CardHeader className="text-center">
            <CardTitle>Not Authenticated</CardTitle>
            <CardDescription>Please log in to access your settings.</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button className="w-full" onClick={() => navigate("/auth")}>
              Go to Login
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container max-w-4xl py-8 mx-auto">
      <Button
        variant="ghost"
        className="mb-6"
        onClick={() => navigate("/")}
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back
      </Button>
      
      <div className="grid grid-cols-1 gap-6 md:grid-cols-4">
        <div className="md:col-span-1">
          <div className="space-y-4">
            <h2 className="text-xl font-bold">Settings</h2>
            <nav className="space-y-1">
              <Button variant="ghost" className="w-full justify-start" disabled>
                <User className="w-4 h-4 mr-2" />
                Profile
              </Button>
              <Button variant="ghost" className="w-full justify-start" disabled>
                <Lock className="w-4 h-4 mr-2" />
                Security
              </Button>
            </nav>
          </div>
        </div>
        
        <div className="md:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle>Profile Settings</CardTitle>
              <CardDescription>
                Update your profile information and preferences
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Profile Picture */}
                  <div className="flex flex-col items-center space-y-4">
                    <Avatar className="w-24 h-24">
                      {profileImagePreview ? (
                        <AvatarImage src={profileImagePreview} alt={form.getValues("displayName")} />
                      ) : (
                        <AvatarFallback className="bg-primary text-white text-xl">
                          {form.getValues("displayName").substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    
                    <div className="flex items-center space-x-2">
                      <label htmlFor="picture-upload" className="cursor-pointer">
                        <div className="flex items-center space-x-2 bg-muted hover:bg-muted/80 px-3 py-2 rounded-md text-sm">
                          <Upload className="w-4 h-4" />
                          <span>Upload</span>
                        </div>
                        <input
                          id="picture-upload"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleImageChange}
                        />
                      </label>
                      
                      {profileImagePreview && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setProfileImagePreview(null);
                            form.setValue("profilePicture", "");
                          }}
                        >
                          Remove
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  <Separator />
                  
                  {/* Basic Info */}
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="displayName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Display Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your display name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="your.email@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    

                  </div>
                  
                  <Separator />
                  
                  {/* Preferences */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Preferences</h3>
                    
                    <FormField
                      control={form.control}
                      name="preferences.darkMode"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                          <div className="space-y-0.5">
                            <FormLabel>Dark Mode</FormLabel>
                            <CardDescription>
                              Use dark theme for the application
                            </CardDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="preferences.notifications"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                          <div className="space-y-0.5">
                            <FormLabel>Notifications</FormLabel>
                            <CardDescription>
                              Receive notifications about new messages
                            </CardDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="preferences.autoPlayAudio"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                          <div className="space-y-0.5">
                            <FormLabel>Auto-play Audio</FormLabel>
                            <CardDescription>
                              Automatically play audio from AI characters
                            </CardDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="pt-4 flex justify-end">
                    <Button
                      type="submit"
                      disabled={updateProfileMutation.isPending}
                    >
                      {updateProfileMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        "Save Changes"
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default UserSettingsPage;