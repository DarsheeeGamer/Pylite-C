import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import AppHeader from "@/components/layout/AppHeader";
import Sidebar from "@/components/layout/Sidebar";
import ChatInterface from "@/components/chat/ChatInterface";
import CharacterDetailsPanel from "@/components/layout/CharacterDetailsPanel";
import CharacterSelectionModal from "@/components/modals/CharacterSelectionModal";
import { useCharacters } from "@/hooks/use-characters";
import type { Character } from "@shared/schema";

export default function Home() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isDetailsPanelOpen, setIsDetailsPanelOpen] = useState(false);
  const [showCharacterSelection, setShowCharacterSelection] = useState(false);
  const { characters, activeCharacter, setActiveCharacter } = useCharacters();
  
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };
  
  const toggleDetailsPanel = () => {
    setIsDetailsPanelOpen(!isDetailsPanelOpen);
  };
  
  const handleSelectCharacter = (character: Character) => {
    setActiveCharacter(character);
    setShowCharacterSelection(false);
  };
  
  const handleCreateCustomCharacter = () => {
    // Implementation for creating custom character
    setShowCharacterSelection(false);
    // Will be expanded later
  };
  
  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <AppHeader 
        toggleSidebar={toggleSidebar} 
        onOpenCharacterSelection={() => setShowCharacterSelection(true)}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          characters={characters}
          activeCharacter={activeCharacter}
          onSelectCharacter={setActiveCharacter}
          onAddCharacter={() => setShowCharacterSelection(true)}
        />
        
        <ChatInterface
          character={activeCharacter}
          onOpenSettings={toggleDetailsPanel}
        />
        
        {isDetailsPanelOpen && (
          <CharacterDetailsPanel
            character={activeCharacter}
            onClose={toggleDetailsPanel}
          />
        )}
      </div>
      
      {showCharacterSelection && (
        <CharacterSelectionModal
          characters={characters}
          onSelect={handleSelectCharacter}
          onClose={() => setShowCharacterSelection(false)}
          onCreateCustom={handleCreateCustomCharacter}
        />
      )}
    </div>
  );
}
