import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CodeIcon, BookIcon, DumbbellIcon, PaintbrushIcon } from "lucide-react";

interface OnboardingModalProps {
  onComplete: () => void;
  onSkip: () => void;
}

export default function OnboardingModal({ onComplete, onSkip }: OnboardingModalProps) {
  const [step, setStep] = useState(1);
  const [userData, setUserData] = useState({
    name: "",
    interests: [] as string[],
  });
  
  const steps = [
    {
      title: "Welcome to AI Companion!",
      description: "Let's find the perfect AI companion for you. Tell us a bit about yourself.",
      fields: (
        <div>
          <label className="text-sm font-medium text-gray-700 block mb-1">What's your name?</label>
          <Input
            value={userData.name}
            onChange={(e) => setUserData({ ...userData, name: e.target.value })}
            placeholder="Your name"
            className="mb-4"
          />
          
          <label className="text-sm font-medium text-gray-700 block mb-1">What are you interested in?</label>
          <div className="grid grid-cols-2 gap-2 mt-2">
            <InterestButton 
              icon={<CodeIcon className="mr-2 h-4 w-4 text-primary-500" />}
              label="Programming"
              selected={userData.interests.includes("Programming")}
              onClick={() => toggleInterest("Programming")}
            />
            <InterestButton 
              icon={<BookIcon className="mr-2 h-4 w-4 text-primary-500" />}
              label="Philosophy"
              selected={userData.interests.includes("Philosophy")}
              onClick={() => toggleInterest("Philosophy")}
            />
            <InterestButton 
              icon={<DumbbellIcon className="mr-2 h-4 w-4 text-primary-500" />}
              label="Fitness"
              selected={userData.interests.includes("Fitness")}
              onClick={() => toggleInterest("Fitness")}
            />
            <InterestButton 
              icon={<PaintbrushIcon className="mr-2 h-4 w-4 text-primary-500" />}
              label="Creativity"
              selected={userData.interests.includes("Creativity")}
              onClick={() => toggleInterest("Creativity")}
            />
          </div>
        </div>
      ),
    },
    {
      title: "Choose Your Conversation Style",
      description: "How would you like your AI companions to communicate with you?",
      fields: (
        <div className="grid grid-cols-1 gap-3">
          <StyleButton
            title="Professional"
            description="Clear, concise, and formal communication"
            onClick={() => finishOnboarding()}
          />
          <StyleButton
            title="Casual"
            description="Friendly, relaxed, and conversational"
            onClick={() => finishOnboarding()}
          />
          <StyleButton
            title="Educational"
            description="Informative with helpful explanations"
            onClick={() => finishOnboarding()}
          />
          <StyleButton
            title="Entertaining"
            description="Fun, engaging and witty dialogue"
            onClick={() => finishOnboarding()}
          />
        </div>
      ),
    },
  ];
  
  const currentStep = steps[step - 1];
  const progress = (step / steps.length) * 100;
  
  const toggleInterest = (interest: string) => {
    if (userData.interests.includes(interest)) {
      setUserData({
        ...userData,
        interests: userData.interests.filter((i) => i !== interest)
      });
    } else {
      setUserData({
        ...userData,
        interests: [...userData.interests, interest]
      });
    }
  };
  
  const nextStep = () => {
    if (step < steps.length) {
      setStep(step + 1);
    } else {
      finishOnboarding();
    }
  };
  
  const finishOnboarding = () => {
    // Save user data and complete onboarding
    localStorage.setItem("userData", JSON.stringify(userData));
    onComplete();
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-white rounded-xl shadow-2xl max-w-md w-full mx-4 overflow-hidden"
      >
        <div className="relative">
          {/* Progress bar */}
          <div className="h-1 bg-gray-200">
            <div 
              className="h-full bg-primary-500 transition-all duration-300 ease-in-out" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          
          {/* Content */}
          <div className="p-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-2">{currentStep.title}</h2>
            <p className="text-gray-600 mb-6">{currentStep.description}</p>
            
            <div className="space-y-4">
              {currentStep.fields}
            </div>
          </div>
          
          {/* Footer */}
          <div className="px-6 py-4 bg-gray-50 flex justify-between">
            <Button variant="ghost" onClick={onSkip}>
              Skip for now
            </Button>
            <Button 
              onClick={nextStep}
              disabled={step === 1 && userData.name.trim() === ""}
            >
              {step < steps.length ? "Continue" : "Finish"}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

interface InterestButtonProps {
  icon: React.ReactNode;
  label: string;
  selected: boolean;
  onClick: () => void;
}

function InterestButton({ icon, label, selected, onClick }: InterestButtonProps) {
  return (
    <button
      onClick={onClick}
      className={`py-2 px-3 border ${
        selected 
          ? "border-primary-500 bg-primary-50" 
          : "border-gray-300 hover:bg-primary-50 hover:border-primary-500"
      } rounded-lg text-sm font-medium transition text-left flex items-center`}
    >
      {icon}
      {label}
    </button>
  );
}

interface StyleButtonProps {
  title: string;
  description: string;
  onClick: () => void;
}

function StyleButton({ title, description, onClick }: StyleButtonProps) {
  return (
    <button
      onClick={onClick}
      className="p-4 border border-gray-300 rounded-lg text-left hover:border-primary-500 hover:bg-primary-50 transition"
    >
      <h3 className="font-medium text-gray-800">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </button>
  );
}
