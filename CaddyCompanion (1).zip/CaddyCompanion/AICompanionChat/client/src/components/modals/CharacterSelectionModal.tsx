import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Character } from "@shared/schema";

interface CharacterSelectionModalProps {
  characters: Character[];
  onSelect: (character: Character) => void;
  onClose: () => void;
  onCreateCustom: () => void;
}

export default function CharacterSelectionModal({ 
  characters, 
  onSelect, 
  onClose, 
  onCreateCustom 
}: CharacterSelectionModalProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All Categories");
  
  const filteredCharacters = characters.filter(character => {
    const matchesSearch = !searchQuery || 
      character.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      character.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (character.tags && character.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())));
      
    const matchesCategory = categoryFilter === "All Categories" || 
      character.category === categoryFilter;
      
    return matchesSearch && matchesCategory;
  });
  
  const categories = ["All Categories", ...new Set(characters.map(c => c.category).filter(Boolean))];
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="bg-white rounded-xl shadow-2xl max-w-4xl w-full mx-4 max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Choose Your AI Companion</h2>
          <button 
            className="text-gray-500 hover:text-gray-700" 
            onClick={onClose}
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        {/* Search and filters */}
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                className="pl-10"
                placeholder="Search by name or category..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select 
              value={categoryFilter} 
              onValueChange={setCategoryFilter}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Character grid */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence>
            {filteredCharacters.length > 0 ? (
              filteredCharacters.map((character) => (
                <motion.div
                  key={character.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  transition={{ duration: 0.3 }}
                  className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition cursor-pointer group"
                  onClick={() => onSelect(character)}
                >
                  <div 
                    className="h-32 relative"
                    style={{
                      background: character.backgroundGradient || "linear-gradient(to right, #6366f1, #8b5cf6)"
                    }}
                  >
                    <img
                      src={character.imageUrl}
                      alt={character.name}
                      className="w-20 h-20 rounded-full absolute -bottom-10 left-6 border-4 border-white object-cover"
                    />
                  </div>
                  <div className="pt-12 px-6 pb-6">
                    <h3 className="font-semibold text-gray-800 mb-1">{character.name}</h3>
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">{character.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {character.tags?.slice(0, 2).map((tag, index) => (
                        <span key={index} className="px-2 py-1 bg-primary-100 text-primary-800 rounded-full text-xs">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <Button 
                      variant="ghost"
                      className="w-full py-2 group-hover:bg-primary-500 group-hover:text-white transition"
                    >
                      Chat Now
                    </Button>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full flex flex-col items-center justify-center py-8 text-gray-500">
                <p className="mb-2">No characters found matching your criteria.</p>
                <Button onClick={() => {
                  setSearchQuery("");
                  setCategoryFilter("All Categories");
                }}>
                  Clear Filters
                </Button>
              </div>
            )}
          </AnimatePresence>
        </div>
        
        {/* Footer */}
        <div className="p-6 border-t border-gray-200 flex justify-between">
          <Button variant="ghost" className="flex items-center" onClick={onCreateCustom}>
            <Plus className="h-4 w-4 mr-1" /> Create Custom
          </Button>
          <Button onClick={onClose}>
            Done
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
