import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import ChatMessage from "./ChatMessage";
import MessageInput from "./MessageInput";
import TypingIndicator from "./TypingIndicator";
import { useChat } from "@/hooks/use-chat";
import type { Character, Message } from "@shared/schema";

interface ChatInterfaceProps {
  character: Character;
  onOpenSettings: () => void;
}

export default function ChatInterface({ character, onOpenSettings }: ChatInterfaceProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { messages, sendMessage, isTyping } = useChat(character?.id);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);
  
  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;
    await sendMessage(content);
  };
  
  if (!character) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-gray-50">
        <div className="text-center p-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-2">Select a Character</h2>
          <p className="text-gray-600">Choose an AI companion from the sidebar to start chatting.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-gray-50">
      {/* Character info header */}
      <div className="flex items-center p-4 bg-white border-b border-gray-200">
        <img 
          src={character.imageUrl} 
          alt={character.name} 
          className="w-10 h-10 rounded-full object-cover"
        />
        <div className="ml-3 flex-1">
          <h3 className="font-semibold text-gray-800">{character.name}</h3>
          <p className="text-xs text-green-500 flex items-center">
            <span className="w-2 h-2 rounded-full bg-green-500 inline-block mr-1"></span>
            Online
          </p>
        </div>
        <div className="flex space-x-3">
          <button className="text-gray-500 hover:text-primary-600 transition">
            <i className="fas fa-info-circle"></i>
          </button>
          <button 
            className="text-gray-500 hover:text-primary-600 transition"
            onClick={onOpenSettings}
          >
            <i className="fas fa-cog"></i>
          </button>
        </div>
      </div>
      
      {/* Chat messages container */}
      <div className="flex-1 overflow-y-auto p-4 scrollbar-hide" id="chat-messages">
        {messages.length === 0 ? (
          <div className="max-w-xs sm:max-w-md md:max-w-lg flex flex-col mb-8 mx-auto">
            <div className="flex items-center justify-center mb-3">
              <img
                src={character.imageUrl}
                alt={character.name}
                className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-lg"
              />
            </div>
            <div className="text-center">
              <h2 className="text-xl font-semibold text-gray-800">{character.name}</h2>
              <p className="text-gray-600 mt-1">{character.description}</p>
            </div>
            <div className="mt-4 text-center text-sm text-gray-500">
              <p>Tap the input below to start chatting with {character.name.split(" ")[0]}!</p>
            </div>
          </div>
        ) : (
          <div>
            <AnimatePresence initial={false}>
              {messages.map((message, index) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ChatMessage message={message} character={character} />
                </motion.div>
              ))}
            </AnimatePresence>
            
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <TypingIndicator character={character} />
              </motion.div>
            )}
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Input area */}
      <MessageInput onSendMessage={handleSendMessage} isDisabled={isTyping} />
    </div>
  );
}
