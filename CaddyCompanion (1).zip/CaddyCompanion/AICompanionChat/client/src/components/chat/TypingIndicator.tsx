import { Character } from "@shared/schema";

interface TypingIndicatorProps {
  character: Character;
}

export default function TypingIndicator({ character }: TypingIndicatorProps) {
  return (
    <div className="flex mb-4">
      <img
        src={character.imageUrl}
        alt={character.name}
        className="w-8 h-8 rounded-full mr-2 mt-1"
      />
      <div className="max-w-[85%]">
        <div className="bg-white p-3 rounded-lg chat-bubble-ai shadow-sm flex items-center space-x-1">
          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
          <div
            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
            style={{ animationDelay: "0.2s" }}
          ></div>
          <div
            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
            style={{ animationDelay: "0.4s" }}
          ></div>
        </div>
      </div>
    </div>
  );
}
