import { format } from "date-fns";
import type { Message, Character } from "@shared/schema";

interface ChatMessageProps {
  message: Message;
  character: Character;
}

export default function ChatMessage({ message, character }: ChatMessageProps) {
  const isUser = message.role === "user";
  const formattedTime = format(new Date(message.timestamp), "h:mm a");
  
  const formatMessageContent = (content: string) => {
    return content.split("\n").map((line, i) => <p key={i}>{line}</p>);
  };
  
  if (isUser) {
    return (
      <div className="flex mb-4 justify-end">
        <div className="max-w-[85%]">
          <div className="bg-primary-500 p-3 rounded-lg chat-bubble-user shadow-sm">
            <div className="text-white">{formatMessageContent(message.content)}</div>
          </div>
          <div className="text-xs text-gray-500 mt-1 mr-1 text-right">{formattedTime}</div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex mb-4">
      <img 
        src={character.imageUrl} 
        alt={character.name} 
        className="w-8 h-8 rounded-full mr-2 mt-1" 
      />
      <div className="max-w-[85%]">
        <div className="bg-white p-3 rounded-lg chat-bubble-ai shadow-sm">
          <div className="text-gray-800 whitespace-pre-wrap">
            {message.content.includes("1.") ? (
              <div>
                {message.content.split(/(\d+\.\s)/).map((part, i) => {
                  if (/^\d+\.\s/.test(part)) {
                    return <strong key={i} className="block mt-1">{part}</strong>;
                  } else if (part.trim()) {
                    return <span key={i}>{part}</span>;
                  }
                  return null;
                })}
              </div>
            ) : (
              formatMessageContent(message.content)
            )}
          </div>
        </div>
        <div className="text-xs text-gray-500 mt-1 ml-1">{formattedTime}</div>
      </div>
    </div>
  );
}
