import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Menu, Bell, LogOut, Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { generateAvatarFallback } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface AppHeaderProps {
  toggleSidebar: () => void;
  onOpenCharacterSelection: () => void;
}

export default function AppHeader({ toggleSidebar, onOpenCharacterSelection }: AppHeaderProps) {
  const { user, logoutMutation } = useAuth();
  
  // Generate user initials
  const userDisplayName = user?.displayName || user?.username || "";
  const userInitials = generateAvatarFallback(userDisplayName);
  
  return (
    <header className="bg-white border-b border-gray-200 py-3 px-4 sm:px-6 flex justify-between items-center">
      <div className="flex items-center">
        <button 
          onClick={toggleSidebar}
          className="mr-4 text-gray-600 hover:text-primary-600 md:hidden"
          aria-label="Toggle menu"
        >
          <Menu className="h-6 w-6" />
        </button>
        <h1 className="text-xl font-semibold text-primary-600">
          <span className="hidden sm:inline">AI</span> Companion
        </h1>
      </div>
      <div className="flex items-center space-x-3">
        <button className="text-gray-600 hover:text-primary-600">
          <Bell className="h-5 w-5" />
        </button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Avatar className="h-8 w-8 bg-primary-100 text-primary-600 cursor-pointer hover:opacity-90">
              <AvatarFallback>{userInitials}</AvatarFallback>
            </Avatar>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>{userDisplayName}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onOpenCharacterSelection()}>
              Select Character
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
              className="text-red-500 focus:text-red-500"
            >
              {logoutMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Logging out...
                </>
              ) : (
                <>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </>
              )}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
