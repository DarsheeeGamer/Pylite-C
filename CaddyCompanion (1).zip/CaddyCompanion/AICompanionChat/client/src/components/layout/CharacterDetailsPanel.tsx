import { useState } from "react";
import { motion } from "framer-motion";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Character } from "@shared/schema";

interface CharacterDetailsPanelProps {
  character: Character | null;
  onClose: () => void;
}

export default function CharacterDetailsPanel({ character, onClose }: CharacterDetailsPanelProps) {
  const { toast } = useToast();
  
  const [customizations, setCustomizations] = useState({
    communicationStyle: "Professional",
    responseLength: "Moderate",
    memoryStrength: 7
  });
  
  const updateCustomizationsMutation = useMutation({
    mutationFn: async (data: any) => {
      if (!character) return null;
      const res = await apiRequest('PATCH', `/api/characters/${character.id}/customizations`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/characters'] });
      toast({
        title: "Customizations saved",
        description: "Your character preferences have been updated."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to save",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  if (!character) return null;
  
  const handleSaveChanges = () => {
    updateCustomizationsMutation.mutate(customizations);
  };
  
  return (
    <motion.div
      initial={{ width: 0, opacity: 0 }}
      animate={{ width: "auto", opacity: 1 }}
      exit={{ width: 0, opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="md:w-72 lg:w-96 border-l border-gray-200 bg-white overflow-y-auto"
    >
      {/* Character profile */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-lg font-semibold text-gray-800">Character Details</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
            aria-label="Close details panel"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex flex-col items-center">
          <img
            src={character.imageUrl}
            alt={character.name}
            className="w-32 h-32 rounded-full object-cover mb-4"
          />
          <h3 className="text-xl font-semibold text-gray-800">{character.name}</h3>
          <p className="text-gray-600 text-sm text-center mt-2">{character.description}</p>
        </div>
      </div>
      
      {/* Character details */}
      <div className="p-6 border-b border-gray-200">
        <h3 className="font-medium text-gray-800 mb-3">About {character.name.split(" ")[0]}</h3>
        <div className="space-y-3">
          <div>
            <h4 className="text-sm font-medium text-gray-600">Background</h4>
            <p className="text-sm text-gray-800">
              {character.customizations?.background || "Senior software engineer with 10+ years of experience in various programming languages and technologies."}
            </p>
          </div>
          <div>
            <h4 className="text-sm font-medium text-gray-600">Personality</h4>
            <p className="text-sm text-gray-800">
              {character.customizations?.personality || "Patient, analytical, encouraging, and occasionally uses programming humor."}
            </p>
          </div>
          <div>
            <h4 className="text-sm font-medium text-gray-600">Special Skills</h4>
            <div className="flex flex-wrap gap-2 mt-1">
              {character.tags?.map((tag, index) => (
                <span key={index} className="px-2 py-1 bg-primary-100 text-primary-800 rounded-full text-xs">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {/* Customization options */}
      <div className="p-6">
        <h3 className="font-medium text-gray-800 mb-3">Customize {character.name.split(" ")[0]}</h3>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-600 block mb-1">Communication Style</label>
            <Select 
              value={customizations.communicationStyle}
              onValueChange={(value) => setCustomizations({...customizations, communicationStyle: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a communication style" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Professional">Professional</SelectItem>
                <SelectItem value="Casual">Casual</SelectItem>
                <SelectItem value="Technical">Technical</SelectItem>
                <SelectItem value="Beginner-friendly">Beginner-friendly</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600 block mb-1">Response Length</label>
            <Select 
              value={customizations.responseLength}
              onValueChange={(value) => setCustomizations({...customizations, responseLength: value})}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a response length" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Concise">Concise</SelectItem>
                <SelectItem value="Moderate">Moderate</SelectItem>
                <SelectItem value="Detailed">Detailed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium text-gray-600 block mb-1">Memory Strength</label>
            <div className="flex items-center space-x-2">
              <Slider 
                value={[customizations.memoryStrength]}
                onValueChange={(value) => setCustomizations({...customizations, memoryStrength: value[0]})}
                max={10}
                min={1}
                step={1}
                className="w-full"
              />
              <span className="text-sm font-medium text-gray-800">{customizations.memoryStrength}</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Higher values mean {character.name.split(" ")[0]} will remember more from past conversations.
            </p>
          </div>
          <Button 
            onClick={handleSaveChanges} 
            className="w-full"
            disabled={updateCustomizationsMutation.isPending}
          >
            {updateCustomizationsMutation.isPending ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
