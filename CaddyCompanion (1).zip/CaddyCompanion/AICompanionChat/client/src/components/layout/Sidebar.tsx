import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Plus, X } from "lucide-react";
import type { Character } from "@shared/schema";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  characters: Character[];
  activeCharacter: Character | null;
  onSelectCharacter: (character: Character) => void;
  onAddCharacter: () => void;
}

export default function Sidebar({
  isOpen,
  onClose,
  characters,
  activeCharacter,
  onSelectCharacter,
  onAddCharacter
}: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  
  const filteredCharacters = searchQuery
    ? characters.filter(
        (char) =>
          char.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          char.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (char.tags && char.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase())))
      )
    : characters;
    
  const sidebarClasses = isOpen
    ? "fixed inset-0 z-40 md:relative md:flex md:w-64 lg:w-80 flex-col bg-white border-r border-gray-200 overflow-y-auto"
    : "hidden md:flex md:w-64 lg:w-80 flex-col bg-white border-r border-gray-200 overflow-y-auto";
    
  return (
    <div className={sidebarClasses}>
      {isOpen && (
        <div className="md:hidden absolute top-4 right-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onClose}
            aria-label="Close sidebar"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
      )}
    
      {/* Sidebar header */}
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold text-gray-800">My Companions</h2>
      </div>
      
      {/* Search bar */}
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            className="pl-10"
            placeholder="Search companions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      
      {/* Character list */}
      <div className="flex-1 overflow-y-auto pb-20">
        <AnimatePresence initial={false}>
          {filteredCharacters.map((character) => {
            const isActive = activeCharacter?.id === character.id;
            return (
              <motion.div
                key={character.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, height: 0, transition: { duration: 0.2 } }}
                transition={{ duration: 0.2 }}
                className={`flex items-center p-4 cursor-pointer ${
                  isActive
                    ? "bg-primary-50 border-l-4 border-primary-500"
                    : "hover:bg-gray-50 transition"
                }`}
                onClick={() => onSelectCharacter(character)}
              >
                <img
                  src={character.imageUrl}
                  alt={character.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="ml-3 flex-1">
                  <h3 className="font-medium text-gray-800">{character.name}</h3>
                  <p className="text-sm text-gray-500 truncate">
                    {character.description}
                  </p>
                </div>
                {isActive && <div className="w-3 h-3 rounded-full bg-green-500"></div>}
              </motion.div>
            );
          })}
        </AnimatePresence>
        
        {/* Add new character button */}
        <div className="p-4">
          <Button
            onClick={onAddCharacter}
            variant="outline"
            className="w-full py-3 px-4 text-primary-600 font-medium hover:bg-gray-50 flex items-center justify-center space-x-2 transition"
          >
            <Plus className="h-4 w-4" />
            <span>Add New Companion</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
