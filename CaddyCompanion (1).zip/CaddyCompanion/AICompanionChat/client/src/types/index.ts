export interface ChatSettings {
  communicationStyle: "Professional" | "Casual" | "Technical" | "Beginner-friendly";
  responseLength: "Concise" | "Moderate" | "Detailed";
  memoryStrength: number;
}

export interface UserData {
  name: string;
  interests: string[];
  preferredStyle?: string;
}

export interface StreamResponse {
  type: 'typing_start' | 'typing_end' | 'content_chunk';
  messageId?: number;
  conversationId?: number;
  chunk?: string;
}
