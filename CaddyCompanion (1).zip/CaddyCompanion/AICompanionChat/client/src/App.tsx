import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import WelcomePage from "@/pages/welcome-page";
import AuthPage from "@/pages/auth-page";
import AiCharacterPage from "@/pages/ai-character-page";
import MarketplacePage from "@/pages/marketplace-page";
import OnboardingModal from "@/components/modals/OnboardingModal";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";

function Router() {
  return (
    <Switch>
      <Route path="/" component={WelcomePage} />
      <ProtectedRoute path="/dashboard" component={Home} />
      <ProtectedRoute path="/ai/:id" component={AiCharacterPage} />
      <Route path="/marketplace/ai/characters" component={MarketplacePage} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const hasVisitedBefore = localStorage.getItem("hasVisitedBefore");
    if (!hasVisitedBefore) {
      setShowOnboarding(true);
    }
  }, []);

  const handleOnboardingComplete = () => {
    localStorage.setItem("hasVisitedBefore", "true");
    setShowOnboarding(false);
    toast({
      title: "Welcome to AI Companion!",
      description: "Your AI companions are ready to chat with you.",
    });
  };

  const handleOnboardingSkip = () => {
    localStorage.setItem("hasVisitedBefore", "true");
    setShowOnboarding(false);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        {showOnboarding && (
          <OnboardingModal
            onComplete={handleOnboardingComplete}
            onSkip={handleOnboardingSkip}
          />
        )}
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
