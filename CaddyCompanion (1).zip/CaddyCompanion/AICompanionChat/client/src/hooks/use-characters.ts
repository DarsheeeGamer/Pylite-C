import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { Character } from '@shared/schema';
import { DEFAULT_CHARACTERS } from '@/lib/constants';

export function useCharacters() {
  const [activeCharacter, setActiveCharacter] = useState<Character | null>(null);

  const { data: characters = DEFAULT_CHARACTERS, isLoading, error } = useQuery({
    queryKey: ['/api/characters'],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  useEffect(() => {
    // Set default active character if none is selected and data is loaded
    if (!activeCharacter && characters.length > 0) {
      setActiveCharacter(characters[0]);
    }
  }, [characters, activeCharacter]);

  return {
    characters,
    activeCharacter,
    setActiveCharacter,
    isLoading,
    error
  };
}
