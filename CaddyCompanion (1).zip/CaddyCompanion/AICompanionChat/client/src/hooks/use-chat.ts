import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { Message } from '@shared/schema';

export function useChat(characterId: number | undefined) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch messages for this character/conversation
  const { data, isLoading, error } = useQuery({
    queryKey: characterId ? ['/api/messages', characterId] : null,
    enabled: !!characterId,
  });

  useEffect(() => {
    if (data) {
      setMessages(data);
    }
  }, [data]);

  // Set up EventSource for streaming responses when characterId changes
  useEffect(() => {
    let eventSource: EventSource | null = null;
    
    if (characterId) {
      eventSource = new EventSource(`/api/stream?characterId=${characterId}`);
      
      eventSource.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        if (data.type === 'typing_start') {
          setIsTyping(true);
        }
        else if (data.type === 'typing_end') {
          setIsTyping(false);
          queryClient.invalidateQueries({ queryKey: ['/api/messages', characterId] });
        }
        else if (data.type === 'content_chunk') {
          // Handle streaming content chunks
          setMessages(prev => {
            const newMessages = [...prev];
            const lastMessage = newMessages[newMessages.length - 1];
            
            if (lastMessage && lastMessage.role === 'assistant' && lastMessage.id === data.messageId) {
              lastMessage.content += data.chunk;
              return newMessages;
            } else {
              return [
                ...prev,
                {
                  id: data.messageId,
                  conversationId: data.conversationId,
                  content: data.chunk,
                  role: 'assistant',
                  timestamp: new Date().toISOString()
                }
              ];
            }
          });
        }
      };
      
      eventSource.onerror = () => {
        eventSource?.close();
        setIsTyping(false);
      };
    }
    
    return () => {
      eventSource?.close();
    };
  }, [characterId, queryClient]);

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!characterId) throw new Error("No character selected");
      
      // Optimistically add user message to UI
      const tempUserMessage: Message = {
        id: Date.now(), // Temporary ID
        conversationId: 0, // Will be set by the server
        content,
        role: 'user',
        timestamp: new Date().toISOString()
      };
      
      setMessages(prev => [...prev, tempUserMessage]);
      setIsTyping(true);
      
      const res = await apiRequest('POST', '/api/messages', {
        characterId,
        content,
      });
      
      return await res.json();
    },
    onError: (error) => {
      setIsTyping(false);
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const sendMessage = async (content: string) => {
    await sendMessageMutation.mutateAsync(content);
  };

  return {
    messages,
    sendMessage,
    isLoading,
    isTyping,
    error
  };
}
