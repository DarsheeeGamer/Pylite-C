# Character AI Platform

An advanced AI character interaction platform that provides dynamic, personalized conversational experiences with intelligent model management and adaptive communication interfaces.

## Features

- **AI Character Personalities**: Create and interact with AI characters that have unique personalities, backstories, and communication styles.
- **Name-Based Routing**: Access characters via "/AI/AINAME" instead of numeric IDs for more intuitive API design.
- **Enhanced System Prompts**: Characters use structured system prompts with backstory and personality integration.
- **Streaming Responses**: Real-time character responses with typing indicators for a natural conversation experience.
- **Memory Management**: Characters remember important details from previous conversations.
- **Customization**: Adjust character parameters (temperature, response length, etc.) to match desired personality traits.
- **Hybrid Storage System**: Fast in-memory caching with persistent file storage for reliable data management.

## Technical Stack

- **Frontend**: React with TailwindCSS
- **Backend**: Node.js with Express
- **Database**: Hybrid storage with in-memory cache and file persistence
- **API Integration**: Ollama API support for LLM interactions
- **Authentication**: JWT-based authentication system
- **Security**: bcrypt for password hashing, helmet for HTTP headers protection

## System Prompts

Each character uses a structured system prompt format:

```
# System Message for {character_name}

## Character Identity
You are {character_name}, {description}

## Character Backstory
{backstory text}

## Core Instructions
{system prompt}

## Behavior Guidelines
1. Always remain in character as {character_name}.
2. Never break the fourth wall or acknowledge you're an AI.
3. Respond naturally as if this is a real conversation.
4. Show authentic emotions and personality consistent with your backstory.
5. Remember details the user shares about themselves.
6. Don't overly explain your thought process - respond naturally.
7. If appropriate for your character, use emojis and expressions.
8. Incorporate your backstory into responses when relevant.

## Communication Style
{communication style instructions}

## Response Length
{response length preferences}

## Personality Traits
{personality traits}

## Interests and Knowledge Areas
{interests and knowledge}

## Relevant Past Interactions
1. {memory 1}
2. {memory 2}
...

Incorporate these past interactions naturally when relevant, but never refer to them as 'memories' or state that you're 'remembering' something. Simply respond as if you naturally recall these interactions.
```

## API Endpoints

### Character Endpoints

- `GET /api/characters` - Get all available characters
- `GET /api/characters/:id` - Get a character by ID
- `GET /api/characters/name/:name` - Get a character by name
- `POST /api/characters` - Create a new character
- `PATCH /api/characters/:id` - Update an existing character

### Conversation Endpoints

- `GET /api/AI/:characterName/messages` - Get conversation history with a specific character
- `POST /api/AI/:characterName/messages` - Send a message to a specific character
- `GET /api/AI/:characterName/stream` - Stream real-time responses from a character

### User Endpoints

- `POST /api/register` - Register a new user
- `POST /api/login` - Log in and receive authentication token
- `POST /api/logout` - Log out the current user
- `GET /api/user` - Get current user information
- `PATCH /api/user/profile` - Update user profile information

## Python Client Examples

The project includes several Python clients to demonstrate API usage:

1. `examples/python_client.py` - Basic client demonstrating core API functionality
2. `examples/ollama_python_client.py` - Client that works with the Ollama API integration
3. `examples/advanced_ollama_client.py` - Advanced client showcasing system prompts and character backstories
4. `examples/name_based_api_client.py` - Client demonstrating name-based routing (/AI/AINAME)

## Getting Started

1. Clone the repository
2. Install dependencies with `npm install`
3. Start the development server with `npm run dev`
4. Access the web interface at `http://localhost:5000`

## Default Characters

The system comes with several pre-configured characters:

1. **Sophia**: A balanced, helpful AI assistant (temperature: 0.7, token limit: 1200)
2. **Alex**: A factual, information-focused AI (temperature: 0.3, token limit: 800)
3. **Luna**: A creative, imaginative storytelling AI (temperature: 0.9, token limit: 1500)

## Customization Options

Each character can be customized with:

- **Communication Style**: Professional, Casual, Technical, or Beginner-friendly
- **Response Length**: Concise, Moderate, or Detailed
- **Personality Traits**: Custom traits affecting character behavior
- **Interests**: Areas of knowledge the character specializes in
- **Backstory**: Detailed background story influencing responses and personality
- **Model Parameters**: Temperature, token limits, and other LLM parameters