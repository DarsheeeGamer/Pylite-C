/**
 * Embedding Service
 * 
 * Handles text embeddings for semantic search in memory retrieval.
 * Uses Google's Generative AI API for generating embeddings.
 */

import { GoogleGenerativeAI } from '@google/generative-ai';
import { Memory } from '@shared/schema';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Check if Gemini API key is available
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
let geminiApi: GoogleGenerativeAI | null = null;

// Initialize Gemini API if API key is available
if (GEMINI_API_KEY) {
  try {
    geminiApi = new GoogleGenerativeAI(GEMINI_API_KEY);
    console.log("✅ Google Gemini Embedding API initialized successfully");
  } catch (error) {
    console.error("❌ Failed to initialize Google Gemini Embedding API:", error);
    geminiApi = null;
  }
} else {
  console.warn("⚠️ GEMINI_API_KEY not found in environment variables. Semantic search disabled.");
}

/**
 * Generate text embedding using Google's Generative AI
 * 
 * @param text Text to embed
 * @returns Vector embedding array or null if unavailable
 */
export async function generateEmbedding(text: string): Promise<number[] | null> {
  if (!geminiApi) {
    return null;
  }

  try {
    // Get the embedding model
    const embeddingModel = geminiApi.getGenerativeModel({ model: "embedding-001" });
    
    // Generate embedding
    const result = await embeddingModel.embedContent({ content: { role: "user", parts: [{ text }] } });
    const embedding = result.embedding.values;
    
    return embedding;
  } catch (error) {
    console.error("Error generating embedding:", error);
    return null;
  }
}

/**
 * Calculate cosine similarity between two vectors
 * 
 * @param vecA First vector
 * @param vecB Second vector
 * @returns Similarity score between 0 and 1
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error("Vectors must be of same length");
  }
  
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  
  normA = Math.sqrt(normA);
  normB = Math.sqrt(normB);
  
  if (normA === 0 || normB === 0) {
    return 0;
  }
  
  return dotProduct / (normA * normB);
}

/**
 * Search memories using embedding similarity
 * 
 * @param memories Array of memories to search through
 * @param query Query text to match
 * @param limit Maximum number of memories to return
 * @returns Array of memories sorted by relevance
 */
export async function searchMemoriesByEmbedding(
  memories: Memory[], 
  query: string, 
  limit: number
): Promise<Memory[]> {
  // Generate embedding for the query
  const queryEmbedding = await generateEmbedding(query);
  
  if (!queryEmbedding) {
    throw new Error("Failed to generate embedding for query");
  }
  
  // Filter memories that have embeddings
  const memoriesWithEmbeddings = memories.filter(
    memory => memory.embedding !== null && memory.embedding !== undefined
  );
  
  if (memoriesWithEmbeddings.length === 0) {
    throw new Error("No memories with embeddings found");
  }
  
  // Calculate similarity scores
  const scoredMemories = memoriesWithEmbeddings.map(memory => {
    // Parse the embedding from string to number array if it's stored as a string
    const embedding = typeof memory.embedding === 'string' 
      ? JSON.parse(memory.embedding) 
      : memory.embedding as number[];
    
    const similarityScore = cosineSimilarity(queryEmbedding, embedding);
    
    // Combine with importance for final score
    const finalScore = similarityScore * 0.7 + (memory.importance || 0) * 0.3;
    
    return {
      memory,
      score: finalScore
    };
  });
  
  // Sort by score and return top results
  return scoredMemories
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(item => item.memory);
}

export default {
  generateEmbedding,
  searchMemoriesByEmbedding
};