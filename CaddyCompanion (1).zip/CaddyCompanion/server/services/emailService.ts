import nodemailer from 'nodemailer';
import crypto from 'crypto';

// Create nodemailer transporter
const createTransporter = () => {
  return nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER || 'verify@cadi.social',
      pass: process.env.EMAIL_PASSWORD
    }
  });
};

// Generate verification token
export const generateToken = (): string => {
  return crypto.randomBytes(32).toString('hex');
};

// Generate expiry date (24 hours from now)
export const generateTokenExpiry = (): Date => {
  const expiryDate = new Date();
  expiryDate.setHours(expiryDate.getHours() + 24);
  return expiryDate;
};

// Send verification email
export const sendVerificationEmail = async (
  email: string, 
  token: string,
  username: string
): Promise<boolean> => {
  try {
    const transporter = createTransporter();
    
    // Create verification URL
    const verificationUrl = `${process.env.APP_URL || 'http://localhost:5000'}/api/verify-email?token=${token}`;
    
    // Email content
    const mailOptions = {
      from: process.env.EMAIL_USER || 'verify@cadi.social',
      to: email,
      subject: 'Verify Your Cady.social Account',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <div style="text-align: center; margin-bottom: 20px;">
            <h1 style="color: #6366f1;">Cady.social</h1>
          </div>
          <div style="padding: 20px; background-color: #f9fafb; border-radius: 5px;">
            <h2 style="margin-top: 0;">Verify Your Email Address</h2>
            <p>Hi ${username},</p>
            <p>Thank you for signing up for Cady.social! Please verify your email address by clicking the button below.</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${verificationUrl}" style="background-color: #6366f1; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">Verify Email</a>
            </div>
            <p>If the button doesn't work, you can also copy and paste the following link into your browser:</p>
            <p style="word-break: break-all; background-color: #e5e7eb; padding: 10px; border-radius: 5px; font-size: 14px;">${verificationUrl}</p>
            <p>This link will expire in 24 hours.</p>
            <p>If you didn't create an account with us, you can safely ignore this email.</p>
          </div>
          <div style="margin-top: 20px; text-align: center; color: #6b7280; font-size: 14px;">
            <p>© ${new Date().getFullYear()} Cady.social. All rights reserved.</p>
          </div>
        </div>
      `
    };
    
    // Send email
    await transporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Error sending verification email:', error);
    return false;
  }
};

// Send password reset email
export const sendPasswordResetEmail = async (
  email: string, 
  token: string,
  username: string
): Promise<boolean> => {
  try {
    const transporter = createTransporter();
    
    // Create reset password URL
    const resetUrl = `${process.env.APP_URL || 'http://localhost:5000'}/reset-password?token=${token}`;
    
    // Email content
    const mailOptions = {
      from: process.env.EMAIL_USER || 'verify@cadi.social',
      to: email,
      subject: 'Reset Your Cady.social Password',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <div style="text-align: center; margin-bottom: 20px;">
            <h1 style="color: #6366f1;">Cady.social</h1>
          </div>
          <div style="padding: 20px; background-color: #f9fafb; border-radius: 5px;">
            <h2 style="margin-top: 0;">Reset Your Password</h2>
            <p>Hi ${username},</p>
            <p>We received a request to reset your password. Click the button below to create a new password:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetUrl}" style="background-color: #6366f1; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">Reset Password</a>
            </div>
            <p>If the button doesn't work, you can also copy and paste the following link into your browser:</p>
            <p style="word-break: break-all; background-color: #e5e7eb; padding: 10px; border-radius: 5px; font-size: 14px;">${resetUrl}</p>
            <p>This link will expire in 24 hours.</p>
            <p>If you didn't request a password reset, you can safely ignore this email.</p>
          </div>
          <div style="margin-top: 20px; text-align: center; color: #6b7280; font-size: 14px;">
            <p>© ${new Date().getFullYear()} Cady.social. All rights reserved.</p>
          </div>
        </div>
      `
    };
    
    // Send email
    await transporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Error sending password reset email:', error);
    return false;
  }
};