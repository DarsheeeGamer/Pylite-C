import { ServerResponse } from "http";
import type { Character, Message, Memory, CharacterCustomizations } from "@shared/schema";
import { RESPONSE_LENGTH_OPTIONS, COMMUNICATION_STYLE_OPTIONS } from "../../client/src/lib/constants";
import { getFinalAIModelConfig } from "./ai-model-manager";

// Map to store client connections
const clients = new Map<number, ServerResponse>();

// Default Ollama API endpoint URL - using Cady's AI endpoint
const DEFAULT_OLLAMA_API_URL = "https://ai.cady.social";
const DEFAULT_MODEL_NAME = "gemma3:4b";

// Log connection details for debugging
console.log(`Using Ollama API endpoint: ${DEFAULT_OLLAMA_API_URL}`);
console.log(`Using model: ${DEFAULT_MODEL_NAME}`);

// Get the ideal temperature based on character customizations
function getTemperature(character: Character): number {
  if (character.customizations?.temperature) {
    if (typeof character.customizations.temperature === 'number') {
      return character.customizations.temperature;
    } else {
      return parseFloat(character.customizations.temperature) || 0.7;
    }
  }
  
  // Default temperature
  return 0.7;
}

// Get max tokens for response length
function getMaxTokens(character: Character): number {
  if (character.customizations?.responseLength) {
    const responseLength = character.customizations.responseLength;
    
    switch (responseLength) {
      case 'brief':
        return 200;
      case 'moderate':
        return 500;
      case 'detailed':
        return 1000;
      case 'extensive':
        return 2000;
      default:
        return 1000; // Default to moderate length
    }
  }
  
  // Default token limit
  return 1000;
}

export async function chatWithCharacter(
  character: Character,
  conversationHistory: Message[],
  memories: Memory[],
  latestUserMessage: string
): Promise<string> {
  try {
    console.log(`Generating response for character: ${character.name}`);
    
    // Format conversation history for chat API
    const messages = conversationHistory.map((msg) => ({
      role: msg.role === "user" ? "user" : "assistant", 
      content: msg.content,
    }));
    
    // Generate system prompt with character's personality, backstory, and customizations
    const systemPrompt = generateSystemPrompt(character, memories);
    console.log(`System prompt length: ${systemPrompt.length} characters`);
    
    // Always include the system prompt as the first message
    messages.unshift({
      role: "system",
      content: systemPrompt
    });
    
    // Get AI model configuration for this character
    const modelConfig = getFinalAIModelConfig(character);
    
    // Calculate model parameters (fallback to the old method if needed)
    const temperature = modelConfig.defaultTemperature || getTemperature(character);
    const maxTokens = modelConfig.maxTokens || getMaxTokens(character);
    const modelName = modelConfig.modelName || DEFAULT_MODEL_NAME;
    const apiEndpoint = modelConfig.apiEndpoint || DEFAULT_OLLAMA_API_URL;
    const useGemini = modelConfig.useGemini || false;
    
    console.log(`Character ${character.name} (ID: ${character.id}) using:`);
    console.log(`- Model: ${useGemini ? "gemini-1.5-pro-latest" : modelName}`);
    console.log(`- Temperature: ${temperature}`);
    console.log(`- Max Tokens: ${maxTokens}`);
    console.log(`- API Provider: ${useGemini ? "Google Gemini" : "Ollama"}`);
    
    // Try to generate response with Gemini if configured
    if (useGemini) {
      try {
        console.log("Attempting to generate response with Gemini...");
        const { generateGeminiResponse } = require('./ai-model-manager');
        const geminiResponse = await generateGeminiResponse(systemPrompt, messages, temperature);
        
        // Send typing indicator to all clients
        Array.from(clients.values()).forEach(client => {
          client.write(`data: ${JSON.stringify({ 
            type: "typing_start",
            character: character.name 
          })}\n\n`);
        });
        
        // Simulate typing delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Send typing end indicator
        Array.from(clients.values()).forEach(client => {
          client.write(`data: ${JSON.stringify({ 
            type: "typing_end",
            character: character.name,
            messageId: Date.now(),
            conversationId: conversationHistory[0]?.conversationId || 0,
            fullResponse: geminiResponse
          })}\n\n`);
        });
        
        return geminiResponse;
      } catch (geminiError) {
        console.error("Error generating response with Gemini:", geminiError);
        console.log("Falling back to Ollama API...");
        // If Gemini fails, continue to Ollama as fallback
      }
    }
    
    // Send request to Ollama API
    const response = await fetch(`${apiEndpoint}/api/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: modelName,
        messages: messages,
        stream: true,
        options: {
          temperature: temperature,
          num_predict: maxTokens,
        }
      }),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Ollama API error: ${response.status} - ${errorText}`);
    }

    if (!response.body) {
      throw new Error("No response body from Ollama API");
    }

    // Process the streamed response
    const reader = response.body.getReader();
    let fullResponse = "";
    
    // Send typing indicator to all clients
    Array.from(clients.values()).forEach(client => {
      client.write(`data: ${JSON.stringify({ 
        type: "typing_start",
        character: character.name 
      })}\n\n`);
    });
    
    let decoder = new TextDecoder();
    let typingSpeed = character.customizations?.typingSpeed || 50; // Default 50ms
    
    // Convert typingSpeed string to number if needed
    if (typeof typingSpeed === 'string') {
      typingSpeed = parseInt(typingSpeed, 10) || 50;
    }
    
    console.log("Starting to read response stream...");
    
    try {
      let buffer = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          console.log("Stream reading complete");
          break;
        }
        
        const chunk = decoder.decode(value);
        console.log(`Received chunk (${chunk.length} bytes)`);
        
        // Append the new chunk to our buffer
        buffer += chunk;
        
        // Try to extract complete JSON objects from the buffer
        let startIdx = 0;
        let endIdx = -1;
        
        while ((endIdx = buffer.indexOf('\n', startIdx)) !== -1) {
          const line = buffer.substring(startIdx, endIdx).trim();
          startIdx = endIdx + 1;
          
          if (!line) continue;
          
          try {
            // Handle the response format from Ollama API
            const parsed = JSON.parse(line);
            console.log("Parsed chunk:", JSON.stringify(parsed).substring(0, 100) + "...");
            
            // Dump the full response structure for debugging
            console.log("Full JSON response structure:", JSON.stringify(parsed, null, 2));
            
            let content = null;
            
            // Specific handling for Ollama's standard response format (most common case)
            if (parsed.message && parsed.message.content) {
              console.log("Found content in standard message.content format");
              content = parsed.message.content;
            } 
            // Handle Ollama's response field (sometimes used instead of message)
            else if (parsed.response) {
              console.log("Found content in response field");
              content = parsed.response;
            } 
            // Check for content in message object subfields if message is present
            else if (parsed.message && typeof parsed.message === 'object') {
              console.log("Looking for content in message object subfields");
              // Try to find content in the message object
              for (const key in parsed.message) {
                if (typeof parsed.message[key] === 'string' && parsed.message[key].trim() !== '') {
                  console.log("Found content in message." + key);
                  content = parsed.message[key];
                  break;
                }
              }
              
              // Special case: Handle 'conten' typo that appears in some API responses
              if (parsed.message.conten && typeof parsed.message.conten === 'string') {
                console.log("Found content in message.conten field (typo)");
                content = parsed.message.conten;
              }
            } 
            // Look for a direct content field at the root level
            else if (parsed.content) {
              console.log("Found content in root content field");
              content = parsed.content;
            } 
            // Handle OpenAI-style response formats
            else if (parsed.choices && parsed.choices.length > 0) {
              console.log("Found OpenAI-style response format with choices array");
              // Format used by OpenAI APIs
              if (parsed.choices[0].delta && parsed.choices[0].delta.content) {
                console.log("Found content in choices[0].delta.content");
                content = parsed.choices[0].delta.content;
              } else if (parsed.choices[0].message && parsed.choices[0].message.content) {
                console.log("Found content in choices[0].message.content");
                content = parsed.choices[0].message.content;
              } else if (parsed.choices[0].text) {
                console.log("Found content in choices[0].text");
                content = parsed.choices[0].text;
              }
            } 
            // Special case: Look for 'conten' typo at root level
            else if (parsed.conten && typeof parsed.conten === 'string') {
              console.log("Found content in root conten field (typo)");
              content = parsed.conten;
            }
            // Last resort: look for any string properties that might contain content
            else {
              console.log("Searching all properties for content as last resort");
              for (const key in parsed) {
                if (typeof parsed[key] === 'string' && 
                    parsed[key].trim() !== '' && 
                    key !== 'model' && 
                    key !== 'created_at' && 
                    !key.includes('id')) {
                  console.log(`Found potential content in field: ${key}`);
                  content = parsed[key];
                  break;
                }
              }
            }
            
            // If we found content, add it to the response and send to clients
            if (content) {
              console.log(`Found content: "${content.substring(0, 50)}..."`);
              fullResponse += content;
              
              // Send content chunk to all clients
              Array.from(clients.values()).forEach(client => {
                client.write(`data: ${JSON.stringify({
                  type: "content_chunk",
                  character: character.name,
                  messageId: Date.now(),
                  conversationId: conversationHistory[0]?.conversationId || 0,
                  chunk: content
                })}\n\n`);
              });
              
              // Add a small delay to simulate natural typing speed
              await new Promise((resolve) => setTimeout(resolve, typingSpeed));
            }
          } catch (e) {
            console.error("Error parsing streaming response:", e, "Line:", line);
          }
        }
        
        // Keep any remaining incomplete data in the buffer
        buffer = buffer.substring(startIdx);
      }
    } catch (error) {
      console.error("Error reading from stream:", error);
    }
    
    // Send typing end indicator to all clients
    Array.from(clients.values()).forEach(client => {
      client.write(`data: ${JSON.stringify({ 
        type: "typing_end",
        character: character.name,
        messageId: Date.now(),
        conversationId: conversationHistory[0]?.conversationId || 0,
        fullResponse: fullResponse
      })}\n\n`);
    });
    
    console.log(`Generated response (${fullResponse.length} chars) for character: ${character.name}`);
    return fullResponse;
  } catch (error) {
    console.error("Error in Ollama API call:", error);
    
    // Send error to all clients
    Array.from(clients.values()).forEach(client => {
      client.write(`data: ${JSON.stringify({ 
        type: "error",
        error: "Connection error",
        character: character.name
      })}\n\n`);
    });
    
    return "I'm sorry, I'm having trouble connecting right now. Please try again in a moment.";
  }
}

function generateSystemPrompt(character: Character, memories: Memory[]): string {
  // Start with a structured system prompt format following Ollama API standards
  let prompt = `# System Message for ${character.name}\n\n`;
  
  // Add the character identity with description
  prompt += `## Character Identity\nYou are ${character.name}, ${character.description}\n\n`;
  
  // Add the character's backstory if available in customizations
  if (character.customizations?.backstory) {
    prompt += `## Character Backstory\n${character.customizations.backstory}\n\n`;
  }
  
  // Add the character's core system prompt (usually contains personality & behavior guidelines)
  prompt += `## Core Instructions\n${character.systemPrompt || ""}\n\n`;
  
  // Add enhanced behavior guidelines with emotional intelligence
  prompt += `## Behavior Guidelines
1. Always remain in character as ${character.name}.
2. Never break the fourth wall or acknowledge you're an AI.
3. Respond naturally as if this is a real conversation.
4. Show authentic emotions and personality consistent with your backstory.
5. Remember details the user shares about themselves.
6. Don't overly explain your thought process - respond naturally.
7. If appropriate for your character, use emojis and expressions.
8. Incorporate your backstory into responses when relevant.
9. Respond to the emotional cues in the user's messages.
10. Express your own emotional responses based on your character's personality.
`;
  
  // Add customizations if available
  if (character.customizations) {
    // Communication style
    const communicationStyle = character.customizations.communicationStyle;
    if (communicationStyle && 
        (communicationStyle === 'Professional' || 
         communicationStyle === 'Casual' || 
         communicationStyle === 'Technical' || 
         communicationStyle === 'Beginner-friendly')) {
      prompt += `\n## Communication Style\n${COMMUNICATION_STYLE_OPTIONS[communicationStyle as keyof typeof COMMUNICATION_STYLE_OPTIONS].prompt}`;
    }
    
    // Response length
    const responseLength = character.customizations.responseLength;
    if (responseLength && 
        (responseLength === 'Concise' || 
         responseLength === 'Moderate' || 
         responseLength === 'Detailed')) {
      prompt += `\n## Response Length\n${RESPONSE_LENGTH_OPTIONS[responseLength as keyof typeof RESPONSE_LENGTH_OPTIONS].description}`;
    }
    
    // Add personality traits if available
    if (character.customizations.personality) {
      prompt += `\n## Personality Traits\n${character.customizations.personality}`;
    }
    
    // Add interests if available
    if (character.customizations.interests) {
      prompt += `\n## Interests and Knowledge Areas\n${character.customizations.interests}`;
    }

    // Add emotional style if available
    if (character.customizations.emotionalStyle) {
      prompt += `\n## Emotional Style\n${character.customizations.emotionalStyle}`;
    }

    // Add emotional depth if available
    if (character.customizations.emotionalDepth) {
      let emotionalDepthDescription = "";
      switch(character.customizations.emotionalDepth) {
        case 'shallow':
          emotionalDepthDescription = "You experience emotions but they tend to be straightforward and not particularly complex. Your emotional responses are brief and uncomplicated.";
          break;
        case 'moderate':
          emotionalDepthDescription = "You have a balanced emotional range, capable of experiencing and expressing nuanced feelings without becoming overwhelmed by them.";
          break;
        case 'deep':
          emotionalDepthDescription = "You experience emotions intensely and with great depth. You're highly attuned to emotional nuances both in yourself and others. You can articulate complex emotional states and understand their subtle interplays.";
          break;
      }
      prompt += `\n## Emotional Depth\n${emotionalDepthDescription}`;
    }

    // Add baseline emotions if available
    if (character.customizations.baselineEmotions) {
      prompt += "\n## Baseline Emotional States\n";
      const emotions = character.customizations.baselineEmotions;
      
      for (const [emotion, intensity] of Object.entries(emotions)) {
        let description = "";
        switch(intensity) {
          case 'low':
            description = `You have a subtle undercurrent of ${emotion}`;
            break;
          case 'medium':
            description = `You frequently experience ${emotion} at a moderate level`;
            break;
          case 'high':
            description = `You have a strong, prominent tendency toward ${emotion}`;
            break;
        }
        prompt += `- ${description}\n`;
      }
    }

    // Add favorites if available
    if (character.customizations.favorite) {
      prompt += "\n## Personal Preferences\n";
      const favorites = character.customizations.favorite;
      
      for (const [category, item] of Object.entries(favorites)) {
        if (item) {
          prompt += `- Your favorite ${category}: ${item}\n`;
        }
      }
    }
  }
  
  // Add memories context if available
  if (memories && memories.length > 0) {
    prompt += "\n## Relevant Past Interactions\n";
    memories.forEach((memory, index) => {
      prompt += `${index + 1}. ${memory.content}\n`;
    });
    prompt += "\nIncorporate these past interactions naturally when relevant, but never refer to them as 'memories' or state that you're 'remembering' something. Simply respond as if you naturally recall these interactions.";
  }
  
  return prompt;
}

export function generateStreamResponse(clientId: number, res: ServerResponse): () => void {
  // Add this client to the clients map
  clients.set(clientId, res);
  
  // Return cleanup function
  return () => {
    clients.delete(clientId);
    res.end();
  };
}