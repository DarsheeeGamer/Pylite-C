/**
 * AI Model Manager Service
 * 
 * Manages different AI model integrations, currently supporting:
 * - Google Gemini API
 * - Ollama (as fallback)
 */

import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from '@google/generative-ai';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Check if Gemini API key is available
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
let geminiApi: GoogleGenerativeAI | null = null;

// Initialize Gemini API if API key is available
if (GEMINI_API_KEY) {
  try {
    geminiApi = new GoogleGenerativeAI(GEMINI_API_KEY);
    console.log("✅ Google Gemini API initialized successfully");
  } catch (error) {
    console.error("❌ Failed to initialize Google Gemini API:", error);
    geminiApi = null;
  }
} else {
  console.warn("⚠️ GEMINI_API_KEY not found in environment variables. Gemini integration disabled.");
}

// Safety settings to ensure appropriate content
const safetySettings = [
  {
    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
  {
    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
  {
    category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
  {
    category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
];

/**
 * Generate a response using Google's Gemini AI
 * 
 * @param systemPrompt The system prompt providing character context
 * @param messages Array of conversation messages
 * @param temperature Temperature setting for response generation
 * @returns Generated AI response as a string
 */
export async function generateGeminiResponse(
  systemPrompt: string,
  messages: { role: string; content: string }[],
  temperature: number = 0.7
): Promise<string> {
  if (!geminiApi) {
    throw new Error("Gemini API not initialized. Please check your API key.");
  }

  try {
    // Use the most capable Gemini model
    const model = geminiApi.getGenerativeModel({
      model: "gemini-1.5-pro-latest",
      safetySettings,
      generationConfig: {
        temperature: temperature,
        topP: 0.9,
        topK: 40,
        maxOutputTokens: 1024,
      }
    });
    
    // Format history for Gemini's chat API
    const chatHistory = messages.map(msg => {
      return {
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: msg.content }]
      };
    });
    
    // Add system prompt as the first message from the model
    chatHistory.unshift({
      role: "model",
      parts: [{ text: `[Character System Information]\n${systemPrompt}\n[End Character System Information]
Remember, the above is just your configuration. Don't mention it in your responses. Just be ${messages[0]?.content.split(',')[0] || 'the character'} naturally.` }]
    });
    
    console.log(`Sending request to Gemini with ${chatHistory.length} messages`);
    
    // Start a chat session
    const chat = model.startChat({
      history: chatHistory.slice(0, chatHistory.length - 1),
      generationConfig: {
        temperature: temperature,
        maxOutputTokens: 1024,
      }
    });
    
    // Get the last user message
    const lastUserMessage = chatHistory[chatHistory.length - 1];
    
    // Send message and get response
    const result = await chat.sendMessage(lastUserMessage.parts[0].text);
    const response = result.response.text();
    
    console.log(`Received ${response.length} character response from Gemini`);
    return response;
  } catch (error) {
    console.error("Error generating response with Gemini:", error);
    throw error;
  }
}

/**
 * Check if Gemini API is available
 * 
 * @returns Boolean indicating if Gemini API is ready to use
 */
export function isGeminiAvailable(): boolean {
  return geminiApi !== null;
}

/**
 * Get AI model configuration for a character
 * Configures which AI model to use, fallbacks, and parameters
 */
export function getFinalAIModelConfig(character: any): {
  modelName: string;
  apiEndpoint: string;
  defaultTemperature: number;
  maxTokens: number;
  useGemini: boolean;
} {
  // Default configuration
  const config = {
    modelName: "gemma:7b",
    apiEndpoint: "https://ai.cady.social",
    defaultTemperature: 0.7,
    maxTokens: 1000,
    useGemini: false
  };

  // Check for Gemini availability - use it as primary if available
  if (isGeminiAvailable()) {
    config.useGemini = true;
  }
  
  // Override with character-specific config if needed
  if (character.customizations?.aiModelConfig) {
    return {
      ...config,
      ...character.customizations.aiModelConfig
    };
  }
  
  return config;
}