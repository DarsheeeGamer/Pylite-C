/**
 * Memory Service
 * 
 * Handles memory creation, retrieval, and relevance scoring for AI companions
 * to provide more personalized and context-aware conversations.
 */

import { Memory } from '@shared/schema';
import { storage } from '../custom-storage';
import { generateEmbedding } from './embedding';

/**
 * Maximum number of memories to retrieve for a conversation
 */
const MAX_MEMORIES = 10;

/**
 * Create a new memory from a conversation
 * 
 * @param characterId Character's ID
 * @param userId User's ID
 * @param content Memory content
 * @param importance Importance score (0-1), auto-calculated if not provided
 * @param tags Optional tags for categorization
 * @returns The created memory
 */
export async function createMemory(
  characterId: number,
  userId: number,
  content: string,
  importance?: number,
  tags?: string[]
): Promise<Memory> {
  // Auto-calculate importance if not provided
  let calculatedImportance = importance;
  
  if (calculatedImportance === undefined) {
    calculatedImportance = calculateMemoryImportance(content);
  }
  
  // Validate parameters
  if (calculatedImportance < 0 || calculatedImportance > 1) {
    throw new Error("Importance must be between 0 and 1");
  }
  
  // Generate tags if not provided
  const memoryTags = tags || generateTagsFromContent(content);
  
  // Create the memory object
  const memory = await storage.createMemory({
    characterId,
    userId,
    content,
    importance: calculatedImportance,
    tags: memoryTags,
    embedding: null,  // Will be generated separately if embedding service is available
    updatedAt: new Date()
  });
  
  console.log(`Created memory ID ${memory.id} for character ${characterId} and user ${userId} with importance ${calculatedImportance.toFixed(2)}`);
  
  // Generate embedding for the memory (non-blocking)
  generateMemoryEmbedding(memory.id, content)
    .catch(error => console.error('Failed to generate embedding for memory:', error));
  
  return memory;
}

/**
 * Automatically calculate memory importance based on content
 * 
 * @param content Memory content text
 * @returns Importance score between 0-1
 */
function calculateMemoryImportance(content: string): number {
  const lowerContent = content.toLowerCase();
  let score = 0.5; // Default medium importance
  
  // Emotional indicators (high importance)
  const emotionalKeywords = [
    'love', 'hate', 'afraid', 'scared', 'anxious', 'happy', 'sad', 'angry', 'excited',
    'depressed', 'traumatic', 'amazing', 'terrible', 'wonderful', 'awful', 'passionate'
  ];
  
  // Personal identity indicators (high importance)
  const identityKeywords = [
    'i am', 'my name is', 'i identify as', 'i work as', 'my job', 'my career', 
    'my passion', 'my family', 'my partner', 'my spouse', 'my child', 'my children',
    'my parents'
  ];
  
  // Life events (high importance)
  const lifeEventKeywords = [
    'married', 'divorced', 'graduated', 'degree', 'moved', 'relocated', 'born in', 
    'grew up', 'died', 'passed away', 'diagnosed', 'lost my', 'anniversary'
  ];
  
  // Preferences (medium importance)
  const preferenceKeywords = [
    'i like', 'i enjoy', 'i prefer', 'favorite', 'i dislike', 'i don\'t like',
    'hobby', 'interest', 'passion', 'free time'
  ];
  
  // Count keyword matches
  let emotionalCount = 0;
  let identityCount = 0;
  let lifeEventCount = 0;
  let preferenceCount = 0;
  
  emotionalKeywords.forEach(keyword => {
    if (lowerContent.includes(keyword)) emotionalCount++;
  });
  
  identityKeywords.forEach(keyword => {
    if (lowerContent.includes(keyword)) identityCount++;
  });
  
  lifeEventKeywords.forEach(keyword => {
    if (lowerContent.includes(keyword)) lifeEventCount++;
  });
  
  preferenceKeywords.forEach(keyword => {
    if (lowerContent.includes(keyword)) preferenceCount++;
  });
  
  // Calculate importance score based on keyword counts
  const totalCount = emotionalCount + identityCount + lifeEventCount + preferenceCount;
  
  if (totalCount > 0) {
    // Weighted calculation - emotional and identity factors weigh more
    score = Math.min(
      0.9, // Cap at 0.9 to avoid always assigning maximum importance
      0.5 + // Start from neutral
      (emotionalCount * 0.1) + // Emotional keywords add more weight
      (identityCount * 0.1) +  // Identity keywords add more weight
      (lifeEventCount * 0.08) + // Life events add significant weight
      (preferenceCount * 0.05)  // Preferences add moderate weight
    );
  }
  
  // Longer content may indicate more detailed/important information
  if (content.length > 200) score = Math.min(0.95, score + 0.05);
  
  return score;
}

/**
 * Generate tags based on the content
 * 
 * @param content The memory content
 * @returns Array of relevant tags
 */
function generateTagsFromContent(content: string): string[] {
  const lowerContent = content.toLowerCase();
  const tags: string[] = [];
  
  // Categories to check
  const categoryTags: Record<string, string[]> = {
    personal: ['i am', 'my name', 'myself', 'personally'],
    work: ['job', 'career', 'work', 'profession', 'office', 'business'],
    family: ['family', 'parent', 'child', 'sister', 'brother', 'mother', 'father', 'partner', 'spouse', 'wife', 'husband'],
    hobby: ['hobby', 'interest', 'passion', 'enjoy', 'free time', 'weekend', 'game', 'sport', 'read', 'watch', 'play'],
    education: ['school', 'college', 'university', 'degree', 'study', 'learn', 'education', 'student', 'teacher', 'professor'],
    health: ['health', 'doctor', 'hospital', 'sick', 'illness', 'disease', 'diet', 'exercise', 'fitness'],
    emotion: ['feel', 'emotion', 'happy', 'sad', 'angry', 'anxious', 'excited', 'worried', 'scared', 'proud', 'nervous'],
    preference: ['like', 'love', 'hate', 'dislike', 'prefer', 'favorite', 'rather', 'choose'],
    location: ['live in', 'moved to', 'city', 'country', 'town', 'area', 'region', 'neighborhood']
  };
  
  // Check for category matches
  Object.entries(categoryTags).forEach(([category, keywords]) => {
    for (const keyword of keywords) {
      if (lowerContent.includes(keyword)) {
        tags.push(category);
        break; // Only add each category once
      }
    }
  });
  
  return tags;
}

/**
 * Get all memories for a character-user pair
 * 
 * @param characterId Character's ID
 * @param userId User's ID
 * @returns Array of memories
 */
export async function getMemories(characterId: number, userId: number): Promise<Memory[]> {
  return storage.getMemoriesByCharacterAndUser(characterId, userId);
}

/**
 * Get relevant memories based on the current conversation
 * 
 * @param characterId Character's ID
 * @param userId User's ID
 * @param currentMessage The current message to find relevant memories for
 * @returns Array of relevant memories, sorted by relevance
 */
export async function getRelevantMemories(
  characterId: number,
  userId: number,
  currentMessage: string
): Promise<Memory[]> {
  const allMemories = await getMemories(characterId, userId);
  
  if (allMemories.length === 0) {
    return [];
  }
  
  // If we have embeddings, use them for semantic search
  if (allMemories.some(memory => memory.embedding)) {
    try {
      // Attempt to use embedding-based search if available
      const { searchMemoriesByEmbedding } = require('./embedding');
      return await searchMemoriesByEmbedding(allMemories, currentMessage, MAX_MEMORIES);
    } catch (error) {
      console.warn("Embedding search failed, falling back to keyword search", error);
      // Fall back to keyword-based search
    }
  }
  
  // Fallback: keyword-based relevance scoring
  return keywordBasedMemorySearch(allMemories, currentMessage, MAX_MEMORIES);
}

/**
 * Enhanced keyword-based memory search with emotional intelligence
 * 
 * @param memories Array of all memories
 * @param query The query text to match against
 * @param limit Maximum number of memories to return
 * @returns Array of memories sorted by relevance
 */
function keywordBasedMemorySearch(
  memories: Memory[],
  query: string,
  limit: number
): Memory[] {
  const lowerQuery = query.toLowerCase();
  
  // Extract keywords from the query (improved tokenization)
  const keywords = lowerQuery
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter(word => word.length > 2);  // Keep more words for better matching
  
  if (keywords.length === 0) {
    // If no meaningful keywords, return most important memories
    return [...memories]
      .sort((a, b) => (b.importance || 0) - (a.importance || 0))
      .slice(0, limit);
  }
  
  // Emotional intelligence: identify emotional content in the query
  const emotionalKeywords = [
    'happy', 'sad', 'angry', 'upset', 'excited', 'worried', 'anxious', 
    'scared', 'afraid', 'love', 'hate', 'like', 'dislike', 'feel',
    'glad', 'proud', 'guilty', 'ashamed', 'confused', 'lonely'
  ];
  
  // Identify topics in the query
  const topicKeywords = {
    'family': ['family', 'mother', 'father', 'parent', 'sister', 'brother', 'child', 'wife', 'husband', 'spouse', 'partner'],
    'work': ['work', 'job', 'career', 'office', 'colleague', 'boss', 'professional', 'business'],
    'education': ['school', 'university', 'college', 'study', 'learn', 'education', 'class', 'course', 'degree'],
    'health': ['health', 'sick', 'ill', 'doctor', 'hospital', 'pain', 'medicine', 'disease', 'condition'],
    'hobby': ['hobby', 'interest', 'game', 'sport', 'play', 'music', 'art', 'book', 'movie', 'travel'],
    'relationship': ['relationship', 'friend', 'dating', 'girlfriend', 'boyfriend', 'love', 'breakup', 'divorce', 'marriage']
  };
  
  // Check if query contains emotional content
  const queryEmotions = emotionalKeywords.filter(emotion => lowerQuery.includes(emotion));
  const hasEmotionalContent = queryEmotions.length > 0;
  
  // Identify topics in the query
  const queryTopics: string[] = [];
  Object.entries(topicKeywords).forEach(([topic, words]) => {
    if (words.some(word => lowerQuery.includes(word))) {
      queryTopics.push(topic);
    }
  });
  
  // Score each memory with enhanced emotional intelligence
  const scoredMemories = memories.map(memory => {
    const content = memory.content.toLowerCase();
    const memoryTags = memory.tags || [];
    
    // Basic keyword matching score
    let keywordMatchScore = 0;
    for (const keyword of keywords) {
      if (content.includes(keyword)) {
        keywordMatchScore += 1;
      }
    }
    const normalizedKeywordScore = keywords.length > 0 ? keywordMatchScore / keywords.length : 0;
    
    // Enhanced scoring: Emotional content matching
    let emotionalMatchScore = 0;
    if (hasEmotionalContent) {
      for (const emotion of queryEmotions) {
        if (content.includes(emotion)) {
          emotionalMatchScore += 0.2; // Boost for matching emotions
        }
      }
      // Check if memory has emotion tag
      if (memoryTags.includes('emotion')) {
        emotionalMatchScore += 0.2;
      }
    }
    
    // Topic matching
    let topicMatchScore = 0;
    if (queryTopics.length > 0) {
      for (const topic of queryTopics) {
        if (memoryTags.includes(topic)) {
          topicMatchScore += 0.2; // Boost for matching topics in tags
        }
        
        // Check if memory content contains topic keywords
        const topicWords = topicKeywords[topic as keyof typeof topicKeywords];
        if (topicWords && topicWords.some(word => content.includes(word))) {
          topicMatchScore += 0.1;
        }
      }
    }
    
    // Recency and importance boosting
    const importanceScore = memory.importance || 0.5;
    
    // Combined score with emotional intelligence weighting
    // Keyword matching: 50%, Emotional matching: 20%, Topic matching: 15%, Importance: 15%
    const finalScore = 
      normalizedKeywordScore * 0.5 + 
      emotionalMatchScore * 0.2 + 
      topicMatchScore * 0.15 + 
      importanceScore * 0.15;
    
    return {
      memory,
      score: finalScore
    };
  });
  
  // Sort by score and return top memories
  return scoredMemories
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(item => item.memory);
}

/**
 * Analyze the conversation context to extract memory-worthy information
 * 
 * @param conversation Recent conversation messages
 * @returns Extracted information worthy of remembering
 */
export function extractMemoryWorthy(conversation: {role: string, content: string}[]): string[] {
  // Enhanced memory extraction based on patterns for emotional intelligence
  const memoryWorthy: string[] = [];
  
  for (const message of conversation) {
    if (message.role !== 'user') continue;
    
    const content = message.content;
    
    // Personal identity and characteristics
    const selfStatements = content.match(/I am [^.!?]+(\.|\!|\?|$)/gi) || [];
    const myNameStatements = content.match(/My name is [^.!?]+(\.|\!|\?|$)/gi) || [];
    const workStatements = content.match(/I work (?:as|at|for) [^.!?]+(\.|\!|\?|$)/gi) || [];
    
    // Preferences and opinions
    const likeStatements = content.match(/I like [^.!?]+(\.|\!|\?|$)/gi) || [];
    const dislikeStatements = content.match(/I (?:don'?t like|dislike) [^.!?]+(\.|\!|\?|$)/gi) || [];
    const loveStatements = content.match(/I love [^.!?]+(\.|\!|\?|$)/gi) || [];
    const hateStatements = content.match(/I hate [^.!?]+(\.|\!|\?|$)/gi) || [];
    const preferStatements = content.match(/I prefer [^.!?]+(\.|\!|\?|$)/gi) || [];
    
    // Emotional states
    const feelStatements = content.match(/I feel [^.!?]+(\.|\!|\?|$)/gi) || [];
    const emotionalStatements = content.match(/I (?:am|got|feel|became) (?:sad|happy|angry|excited|nervous|anxious|depressed|thrilled|worried) [^.!?]*(\.|\!|\?|$)/gi) || [];
    
    // Personal life context
    const familyStatements = content.match(/My (?:mom|mother|dad|father|sister|brother|partner|spouse|wife|husband|child|son|daughter) [^.!?]+(\.|\!|\?|$)/gi) || [];
    const lifeEventStatements = content.match(/I (?:recently|just) (?:moved|started|finished|graduated|got|lost|found|experienced) [^.!?]+(\.|\!|\?|$)/gi) || [];
    const locationStatements = content.match(/I (?:live|stay|work) in [^.!?]+(\.|\!|\?|$)/gi) || [];
    
    // Memories and past experiences
    const pastStatements = content.match(/I (?:remember|recall|used to|have) [^.!?]+(\.|\!|\?|$)/gi) || [];
    const experienceStatements = content.match(/I experienced [^.!?]+(\.|\!|\?|$)/gi) || [];
    
    // Add all relevant matches with importance weights
    // Higher importance for emotional, identity and significant life events
    memoryWorthy.push(
      ...selfStatements, 
      ...myNameStatements,
      ...workStatements,
      ...likeStatements, 
      ...dislikeStatements, 
      ...loveStatements, 
      ...hateStatements,
      ...preferStatements,
      ...feelStatements,
      ...emotionalStatements,
      ...familyStatements,
      ...lifeEventStatements,
      ...locationStatements,
      ...pastStatements,
      ...experienceStatements
    );
  }
  
  // Filter out duplicate or very similar statements
  const uniqueMemories = Array.from(new Set(memoryWorthy));
  
  return uniqueMemories;
}

/**
 * Generate embedding for a memory and update it in the database
 * 
 * @param memoryId ID of the memory to update
 * @param content Text content to generate embedding for
 */
export async function generateMemoryEmbedding(memoryId: number, content: string): Promise<void> {
  try {
    // Generate embedding
    const embedding = await generateEmbedding(content);
    
    if (!embedding) {
      console.log("Embedding generation not available, skipping memory embedding update");
      return;
    }
    
    // Get the memory
    const memory = await storage.getMemory(memoryId);
    if (!memory) {
      console.error(`Memory ${memoryId} not found, cannot update embedding`);
      return;
    }
    
    // Update the memory with embedding
    await storage.updateMemory(memoryId, {
      ...memory,
      embedding: JSON.stringify(embedding)
    });
    
    console.log(`Updated embedding for memory ID ${memoryId}`);
  } catch (error) {
    console.error(`Failed to generate embedding for memory ID ${memoryId}:`, error);
  }
}

export default {
  createMemory,
  getMemories,
  getRelevantMemories,
  extractMemoryWorthy,
  generateMemoryEmbedding
};