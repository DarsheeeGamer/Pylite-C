import { Express, Request, Response, NextFunction } from "express";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { storage } from "./storage";
import { User, InsertUser } from "@shared/schema";
import * as bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import session from "express-session";
import crypto from "crypto";
import { generateToken, generateTokenExpiry, sendVerificationEmail, sendPasswordResetEmail } from "./services/emailService";

declare global {
  namespace Express {
    // Extend Express.User with our User type without circular reference
    interface User {
      id: number;
      username: string;
      password?: string;
      displayName?: string;
      email: string;
      role?: string;
      profilePicture?: string;
      preferences?: any;
      lastActive?: Date;
      isVerified?: boolean;
      verificationToken?: string;
      verificationTokenExpiry?: Date;
      resetPasswordToken?: string;
      resetPasswordTokenExpiry?: Date;
      createdAt?: Date;
      updatedAt?: Date;
    }
  }
}

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const JWT_EXPIRY = "7d"; // Token expiry time

// Create authentication middleware
export function setupAuth(app: Express) {
  // Configure session
  app.use(session({
    secret: process.env.SESSION_SECRET || "session-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 7 // 1 week
    }
  }));

  // Initialize Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure Passport Local Strategy for username/password auth
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // Get user from storage
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Incorrect username or password" });
        }

        // Verify password directly from DB
        const isValid = await bcrypt.compare(password, user.password as string);
        if (!isValid) {
          return done(null, false, { message: "Incorrect username or password" });
        }

        // Update last active in database
        try {
          await storage.updateUserLastActive(user.id, new Date());
        } catch (err) {
          // Just log the error but continue authentication
          console.error("Failed to update last active timestamp:", err);
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );

  // Serialize and deserialize user
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Generate JWT token
  const generateToken = (user: User): string => {
    return jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRY }
    );
  };

  // Helper function to generate verification token
  const generateVerificationToken = (): string => {
    return crypto.randomBytes(32).toString('hex');
  };

  // Authentication routes
  app.post("/api/register", async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Check if email already exists
      const existingEmailUser = await storage.getUserByEmail(req.body.email);
      if (existingEmailUser) {
        return res.status(400).json({ message: "Email address already in use" });
      }

      // Generate verification token
      const verificationToken = generateVerificationToken();
      const tokenExpiry = new Date();
      tokenExpiry.setHours(tokenExpiry.getHours() + 24); // Token valid for 24 hours

      // Create user with verification token
      const userData = {
        ...req.body as InsertUser,
        isVerified: false,
        verificationToken,
        verificationTokenExpiry: tokenExpiry
      };
      
      const user = await storage.createUser(userData);

      try {
        // Send verification email
        await sendVerificationEmail(user.email, verificationToken, user.username);
      } catch (emailError) {
        console.error("Failed to send verification email:", emailError);
        // Continue with registration even if email sending fails
      }

      // Generate JWT token
      const token = generateToken(user);

      // Login user
      req.login(user, (err) => {
        if (err) return next(err);
        
        // Return user info and token
        return res.status(201).json({
          message: "User registered successfully. Please check your email to verify your account.",
          user: {
            id: user.id,
            username: user.username,
            displayName: user.displayName,
            email: user.email,
            role: user.role,
            isVerified: user.isVerified
          },
          token
        });
      });
    } catch (error: any) { // Type annotation to address the unknown error type
      return res.status(500).json({ message: "Error registering user", error: error.message });
    }
  });

  app.post("/api/login", (req: Request, res: Response, next: NextFunction) => {
    passport.authenticate("local", (err: any, user: User, info: any) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ message: info?.message || "Authentication failed" });

      // Optional: Check if user is verified before allowing login
      // Uncomment this if you want to enforce email verification before login
      /*
      if (!user.isVerified) {
        return res.status(403).json({ 
          message: "Email not verified. Please check your email for verification link.",
          needsVerification: true 
        });
      }
      */

      req.login(user, (err) => {
        if (err) return next(err);

        // Generate token
        const token = generateToken(user);

        return res.json({
          message: "Login successful",
          user: {
            id: user.id,
            username: user.username,
            displayName: user.displayName,
            email: user.email,
            role: user.role,
            isVerified: user.isVerified
          },
          token
        });
      });
    })(req, res, next);
  });
  
  // Email verification endpoint
  app.get("/api/verify-email", async (req: Request, res: Response) => {
    const token = req.query.token as string;
    
    if (!token) {
      return res.status(400).json({ message: "Missing verification token" });
    }
    
    try {
      // Find user with this verification token
      const user = await storage.getUserByVerificationToken(token);
      
      if (!user) {
        return res.status(400).json({ message: "Invalid verification token" });
      }
      
      // Check if token is expired
      if (user.verificationTokenExpiry && new Date() > user.verificationTokenExpiry) {
        return res.status(400).json({ message: "Verification token has expired. Please request a new one." });
      }
      
      // Update user's verification status
      await storage.verifyUserEmail(user.id);
      
      // Redirect to a verification success page
      return res.redirect('/email-verified?success=true');
    } catch (error: any) {
      console.error("Email verification error:", error);
      return res.status(500).json({ message: "Error verifying email", error: error.message });
    }
  });
  
  // Resend verification email endpoint
  app.post("/api/resend-verification", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = req.user as User;
    
    if (user.isVerified) {
      return res.status(400).json({ message: "Email already verified" });
    }
    
    try {
      // Generate new verification token
      const verificationToken = generateVerificationToken();
      const tokenExpiry = new Date();
      tokenExpiry.setHours(tokenExpiry.getHours() + 24); // Token valid for 24 hours
      
      // Update user's verification token
      await storage.updateUserVerificationToken(user.id, verificationToken, tokenExpiry);
      
      // Send verification email
      await sendVerificationEmail(user.email, verificationToken, user.username);
      
      return res.json({ message: "Verification email sent" });
    } catch (error: any) {
      console.error("Error resending verification email:", error);
      return res.status(500).json({ message: "Error resending verification email", error: error.message });
    }
  });

  app.post("/api/logout", (req: Request, res: Response) => {
    req.logout((err) => {
      if (err) return res.status(500).json({ message: "Error logging out" });
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/user", (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = req.user as User;
    return res.json({
      id: user.id,
      username: user.username,
      displayName: user.displayName,
      email: user.email,
      role: user.role
    });
  });

  // JWT Verification middleware
  const verifyJWT = (req: Request, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.split(" ")[1]; // Extract token from "Bearer TOKEN"
    if (!token) {
      return res.status(401).json({ message: "Invalid token format" });
    }

    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded as Express.User;
      next();
    } catch (error) {
      return res.status(401).json({ message: "Invalid token" });
    }
  };

  // Role-based auth middleware
  const requireRole = (role: string) => {
    return (req: Request, res: Response, next: NextFunction) => {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      if ((req.user as User).role !== role) {
        return res.status(403).json({ message: "Access denied" });
      }

      next();
    };
  };

  return {
    verifyJWT,
    requireRole
  };
}