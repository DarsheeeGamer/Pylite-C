import { 
  User, 
  InsertUser, 
  Character, 
  InsertCharacter, 
  Conversation, 
  InsertConversation, 
  Message, 
  InsertMessage, 
  Memory, 
  InsertMemory,
  users,
  characters,
  conversations,
  messages,
  memories
} from "@shared/schema";
import { DEFAULT_CHARACTERS } from "../client/src/lib/constants";
import * as bcrypt from "bcrypt";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPgSimple from 'connect-pg-simple';
import pg from "pg";

const { Pool } = pg;

// Memory store for sessions (simpler for development)
const MemoryStore = createMemoryStore(session);

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // Session management
  sessionStore: session.Store;
  
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByVerificationToken(token: string): Promise<User | undefined>;
  getUserByResetPasswordToken(token: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLastActive(id: number, date: Date): Promise<void>;
  updateUser(id: number, userData: Partial<User>): Promise<User>;
  verifyUserEmail(id: number): Promise<User>;
  updateUserVerificationToken(id: number, token: string, expiry: Date): Promise<User>;
  updateUserResetPasswordToken(id: number, token: string, expiry: Date): Promise<User>;
  
  // Characters
  getAllCharacters(): Promise<Character[]>;
  getCharacter(id: number): Promise<Character | undefined>;
  getCharacterByName(name: string): Promise<Character | undefined>;
  createCharacter(character: InsertCharacter): Promise<Character>;
  updateCharacterCustomizations(id: number, customizations: any): Promise<Character>;
  
  // Conversations
  getConversationsByUserId(userId: number): Promise<Conversation[]>;
  getConversationByUserAndCharacter(userId: number, characterId: number): Promise<Conversation | undefined>;
  getConversation(id: number): Promise<Conversation | undefined>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  
  // Messages
  getMessagesByConversationId(conversationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Memories
  getMemoriesByCharacterAndUser(characterId: number, userId: number): Promise<Memory[]>;
  createMemory(memory: InsertMemory): Promise<Memory>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private characters: Map<number, Character>;
  private conversations: Map<number, Conversation>;
  private messages: Map<number, Message>;
  private memories: Map<number, Memory>;
  
  sessionStore: session.Store;
  currentUserId: number;
  currentCharacterId: number;
  currentConversationId: number;
  currentMessageId: number;
  currentMemoryId: number;

  constructor() {
    this.users = new Map();
    this.characters = new Map();
    this.conversations = new Map();
    this.messages = new Map();
    this.memories = new Map();
    
    // Set up memory session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });
    
    this.currentUserId = 1;
    this.currentCharacterId = 5; // Start after default characters
    this.currentConversationId = 1;
    this.currentMessageId = 1;
    this.currentMemoryId = 1;
    
    // Initialize with default characters
    DEFAULT_CHARACTERS.forEach(character => {
      this.characters.set(character.id, character);
    });
    
    // Create a default user
    this.users.set(1, {
      id: 1,
      username: "user",
      password: "password",
      displayName: "Default User",
      createdAt: new Date().toISOString()
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }
  
  async getUserByVerificationToken(token: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.verificationToken === token,
    );
  }
  
  async getUserByResetPasswordToken(token: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.resetPasswordToken === token,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser,
      id,
      createdAt: new Date().toISOString()
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserLastActive(id: number, date: Date): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      user.lastActive = date;
      this.users.set(id, user);
    }
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    // Update user data
    const updatedUser = {
      ...user,
      ...userData,
      updatedAt: new Date().toISOString()
    };
    
    // Save to storage
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async verifyUserEmail(id: number): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      isVerified: true,
      verificationToken: null,  // Clear verification token
      verificationTokenExpiry: null,
      updatedAt: new Date().toISOString()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserVerificationToken(id: number, token: string, expiry: Date): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      verificationToken: token,
      verificationTokenExpiry: expiry,
      updatedAt: new Date().toISOString()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserResetPasswordToken(id: number, token: string, expiry: Date): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      resetPasswordToken: token,
      resetPasswordTokenExpiry: expiry,
      updatedAt: new Date().toISOString()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  

  // Character methods
  async getAllCharacters(): Promise<Character[]> {
    return Array.from(this.characters.values());
  }
  
  async getCharacter(id: number): Promise<Character | undefined> {
    return this.characters.get(id);
  }
  
  async getCharacterByName(name: string): Promise<Character | undefined> {
    // Case-insensitive search for character by name
    return Array.from(this.characters.values()).find(
      (character) => character.name.toLowerCase() === name.toLowerCase()
    );
  }
  
  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const id = this.currentCharacterId++;
    const character: Character = {
      ...insertCharacter,
      id
    };
    this.characters.set(id, character);
    return character;
  }
  
  async updateCharacterCustomizations(id: number, customizations: any): Promise<Character> {
    const character = this.characters.get(id);
    
    if (!character) {
      throw new Error("Character not found");
    }
    
    const updatedCharacter: Character = {
      ...character,
      customizations: {
        ...character.customizations,
        ...customizations
      }
    };
    
    this.characters.set(id, updatedCharacter);
    return updatedCharacter;
  }
  

  // Conversation methods
  async getConversationsByUserId(userId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      (conversation) => conversation.userId === userId
    );
  }
  
  async getConversationByUserAndCharacter(
    userId: number,
    characterId: number
  ): Promise<Conversation | undefined> {
    return Array.from(this.conversations.values()).find(
      (conversation) => 
        conversation.userId === userId && 
        conversation.characterId === characterId
    );
  }
  
  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }
  
  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = this.currentConversationId++;
    const now = new Date().toISOString();
    
    const conversation: Conversation = {
      ...insertConversation,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.conversations.set(id, conversation);
    return conversation;
  }
  

  // Message methods
  async getMessagesByConversationId(conversationId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter((message) => message.conversationId === conversationId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }
  
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    
    const message: Message = {
      ...insertMessage,
      id,
      timestamp: new Date().toISOString()
    };
    
    this.messages.set(id, message);
    
    // Update conversation's updatedAt timestamp
    const conversation = this.conversations.get(insertMessage.conversationId);
    if (conversation) {
      conversation.updatedAt = new Date().toISOString();
      this.conversations.set(conversation.id, conversation);
    }
    
    return message;
  }
  

  // Memory methods
  async getMemoriesByCharacterAndUser(characterId: number, userId: number): Promise<Memory[]> {
    return Array.from(this.memories.values()).filter(
      (memory) => memory.characterId === characterId && memory.userId === userId
    );
  }
  
  async createMemory(insertMemory: InsertMemory): Promise<Memory> {
    const id = this.currentMemoryId++;
    
    const memory: Memory = {
      ...insertMemory,
      id,
      createdAt: new Date().toISOString()
    };
    
    this.memories.set(id, memory);
    return memory;
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });

    // Initialize database with default characters
    this.initDefaultCharacters();
  }

  private async initDefaultCharacters() {
    try {
      const existingCharacters = await this.getAllCharacters();

      if (existingCharacters.length === 0) {
        for (const character of DEFAULT_CHARACTERS) {
          await this.createCharacter({
            ...character,
            isDefault: true,
            isPremium: false
          });
        }
        console.log("Default characters initialized");
      }
    } catch (error) {
      console.error("Error initializing default characters:", error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const result = await usersCollection.get({ ids: [id.toString()] });
    return result.metadatas[0] as User;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await usersCollection.get({ where: { username: username } });
    return result.metadatas[0] as User;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await usersCollection.get({ where: { email: email } });
    return result.metadatas[0] as User;
  }
  
  async getUserByVerificationToken(token: string): Promise<User | undefined> {
    const result = await usersCollection.get({ where: { verificationToken: token } });
    return result.metadatas[0] as User;
  }
  
  async getUserByResetPasswordToken(token: string): Promise<User | undefined> {
    const result = await usersCollection.get({ where: { resetPasswordToken: token } });
    return result.metadatas[0] as User;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const now = new Date();

    const user = {
      ...insertUser,
      id: Date.now(),
      password: hashedPassword,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString()
    };

    await usersCollection.add({
      ids: [user.id.toString()],
      metadatas: [user]
    });

    return user;
  }

  async updateUserLastActive(id: number, date: Date): Promise<void> {
    const user = await this.getUser(id);
    if (user) {
      await usersCollection.update({
        ids: [id.toString()],
        metadatas: [{ ...user, lastActive: date }]
      });
    }
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const existingUser = await this.getUser(id);
    if (!existingUser) {
      throw new Error("User not found");
    }

    const updatedUser = {
      ...existingUser,
      ...userData,
      updatedAt: new Date().toISOString()
    };

    await usersCollection.update({
      ids: [id.toString()],
      metadatas: [updatedUser]
    });

    return updatedUser;
  }
  
  async verifyUserEmail(id: number): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      isVerified: true,
      verificationToken: null,
      verificationTokenExpiry: null,
      updatedAt: new Date().toISOString()
    };
    
    await usersCollection.update({
      ids: [id.toString()],
      metadatas: [updatedUser]
    });
    
    return updatedUser;
  }
  
  async updateUserVerificationToken(id: number, token: string, expiry: Date): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      verificationToken: token,
      verificationTokenExpiry: expiry.toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    await usersCollection.update({
      ids: [id.toString()],
      metadatas: [updatedUser]
    });
    
    return updatedUser;
  }
  
  async updateUserResetPasswordToken(id: number, token: string, expiry: Date): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser = {
      ...user,
      resetPasswordToken: token,
      resetPasswordTokenExpiry: expiry.toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    await usersCollection.update({
      ids: [id.toString()],
      metadatas: [updatedUser]
    });
    
    return updatedUser;
  }

  async getAllCharacters(): Promise<Character[]> {
    const result = await charactersCollection.get();
    return result.metadatas as Character[];
  }

  async getCharacter(id: number): Promise<Character | undefined> {
    const result = await charactersCollection.get({ ids: [id.toString()] });
    return result.metadatas[0] as Character;
  }

  async getCharacterByName(name: string): Promise<Character | undefined> {
    const result = await charactersCollection.get({ where: { name: name } });
    return result.metadatas[0] as Character;
  }

  async createCharacter(insertCharacter: InsertCharacter): Promise<Character> {
    const now = new Date();
    const character = {
      ...insertCharacter,
      id: Date.now(),
      createdAt: now.toISOString(),
      updatedAt: now.toISOString()
    };

    await charactersCollection.add({
      ids: [character.id.toString()],
      metadatas: [character]
    });

    return character;
  }

  async updateCharacterCustomizations(id: number, customizations: any): Promise<Character> {
    const existingCharacter = await this.getCharacter(id);
    if (!existingCharacter) {
      throw new Error("Character not found");
    }

    const updatedCharacter = {
      ...existingCharacter,
      customizations: {
        ...existingCharacter.customizations,
        ...customizations
      }
    };

    await charactersCollection.update({
      ids: [id.toString()],
      metadatas: [updatedCharacter]
    });

    return updatedCharacter;
  }

  async getConversationsByUserId(userId: number): Promise<Conversation[]> {
    const result = await conversationsCollection.get({ where: { userId: userId } });
    return result.metadatas as Conversation[];
  }

  async getConversationByUserAndCharacter(userId: number, characterId: number): Promise<Conversation | undefined> {
    const result = await conversationsCollection.get({ 
      where: { 
        userId: userId,
        characterId: characterId 
      } 
    });
    return result.metadatas[0] as Conversation;
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    const result = await conversationsCollection.get({ ids: [id.toString()] });
    return result.metadatas[0] as Conversation;
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const now = new Date();
    const conversation = {
      ...insertConversation,
      id: Date.now(),
      createdAt: now.toISOString(),
      updatedAt: now.toISOString()
    };

    await conversationsCollection.add({
      ids: [conversation.id.toString()],
      metadatas: [conversation]
    });

    return conversation;
  }

  async getMessagesByConversationId(conversationId: number): Promise<Message[]> {
    const result = await messagesCollection.get({ where: { conversationId: conversationId } });
    return result.metadatas as Message[];
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const message = {
      ...insertMessage,
      id: Date.now(),
      timestamp: new Date().toISOString()
    };

    await messagesCollection.add({
      ids: [message.id.toString()],
      metadatas: [message]
    });

    return message;
  }

  async getMemoriesByCharacterAndUser(characterId: number, userId: number): Promise<Memory[]> {
    const result = await memoriesCollection.get({ 
      where: { 
        characterId: characterId,
        userId: userId 
      } 
    });
    return result.metadatas as Memory[];
  }

  async createMemory(insertMemory: InsertMemory): Promise<Memory> {
    const memory = {
      ...insertMemory,
      id: Date.now(),
      createdAt: new Date().toISOString()
    };

    await memoriesCollection.add({
      ids: [memory.id.toString()],
      metadatas: [memory]
    });

    return memory;
  }
}

// Export an instance of MemStorage instead of DatabaseStorage since we're now using custom-storage.ts
export const storage = new MemStorage();