#pragma once

#include <string>

void compile_pylite_code(const std::string& source_code, const std::string& output_file_path);