// pylite/include/lexer.h
#pragma once
#include <vector>
#include <string>
#include "../include/token.h"
#include <stdexcept>

// Custom exception class with error code and line number
class LexerError : public std::runtime_error {
public:
    int code;
    int line;
    LexerError(int code, const std::string& message, int line)
        : std::runtime_error(message), code(code), line(line) {}
};


class PyLiteLexer {
public:
    PyLiteLexer(const std::string& source_code);
    std::vector<Token> tokenize();

private:
    const std::string& source_code;
    size_t pos;
    std::vector<Token> tokens;
    int line; // Track line numbers

    char peek(size_t offset) const;
    Token tokenize_number();
    Token tokenize_identifier();
    Token tokenize_string(char quote_char);
    Token tokenize_operator();
};